package com.example.data.model

import java.util.UUID

enum class AspectRatio(val labelAr: String, val ratioFloat: Float, val iconLabel: String) {
    RATIO_16_9("16:9 شاشة تلفزيون وعرض", 16f / 9f, "16:9"),
    RATIO_9_16("9:16 ريلز وتيك توك", 9f / 16f, "9:16"),
    RATIO_1_1("1:1 منشورات مربعة", 1f, "1:1")
}

enum class TransitionType(val titleAr: String) {
    FADE("تلاشي سينمائي"),
    SLIDE("انزلاق تلفزيوني"),
    ZOOM("تكبير ديناميكي"),
    WIPE("مسح استوديو")
}

enum class TemplateCategory(val titleAr: String, val iconDescription: String) {
    TV_NEWS("تقرير إخباري تلفزيوني", "قوالب عواجل وشارات إخبارية"),
    HISTORICAL_DOC("وثائقي وسرد تاريخي", "قوالب سردية وخرائط توضيحية"),
    ECONOMIC("اقتصادي ومؤشرات وأرقام", "نسب بيانية وإحصائيات مالية"),
    EDUCATIONAL("عرض تدريبي وتعليمي", "محاور رئيسية ونقاط استعراض")
}

data class Slide(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val subtitle: String = "",
    val bodyText: String = "",
    val bulletPoints: List<String> = emptyList(),
    val templateCategory: TemplateCategory = TemplateCategory.TV_NEWS,
    val bgPresetIndex: Int = 0,
    val imageUri: String? = null,
    val imagePosition: String = "SPLIT", // SPLIT, CENTER, FULL_BG, RIGHT, LEFT
    val durationSeconds: Int = 5,
    val transition: TransitionType = TransitionType.FADE,
    val lowerThirdName: String = "",
    val lowerThirdRole: String = "",
    val showLowerThird: Boolean = false,
    val showLiveBadge: Boolean = true,
    val breakingNewsText: String = "",
    val showBreakingBanner: Boolean = false,
    val statValue: String = "",
    val statLabel: String = "",
    val showStatCard: Boolean = false
)

data class BroadcastSettings(
    val channelLogoText: String = "KHALED SOOT TV",
    val channelSubText: String = "صوت الخبر والتحليل",
    val tickerText: String = "استوديو خالد صوت: استمرار البث المباشر لأحدث التقارير الوثائقية والتحليلات المتخصصة على مدار الساعة...",
    val showTicker: Boolean = true,
    val tickerSpeed: Float = 1.0f,
    val studioLocation: String = "الرياض - الاستوديو الرئيسي",
    val presenterName: String = "خالد صوت"
)

data class AudioConfig(
    val voiceoverPath: String? = null,
    val voiceoverDurationMs: Long = 0L,
    val selectedMusicPreset: String = "BREAKING_NEWS", // NONE, BREAKING_NEWS, DOCUMENTARY, ECONOMIC_BEAT, CALM_PIANO
    val voiceVolume: Float = 1.0f,
    val musicVolume: Float = 0.45f,
    val autoDucking: Boolean = true
)

data class Project(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "مشروع تقرير جديد",
    val description: String = "",
    val aspectRatio: AspectRatio = AspectRatio.RATIO_16_9,
    val slides: List<Slide> = emptyList(),
    val broadcastSettings: BroadcastSettings = BroadcastSettings(),
    val audioConfig: AudioConfig = AudioConfig(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
