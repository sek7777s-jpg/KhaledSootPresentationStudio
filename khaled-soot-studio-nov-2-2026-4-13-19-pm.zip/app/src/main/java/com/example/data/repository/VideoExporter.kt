package com.example.data.repository

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.data.model.AspectRatio
import com.example.data.model.Project
import com.example.data.model.Slide
import com.example.data.model.TransitionType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import kotlin.math.sin

class VideoExporter(private val context: Context) {

    private val _isExporting = MutableStateFlow(false)
    val isExporting: StateFlow<Boolean> = _isExporting.asStateFlow()

    private val _exportProgress = MutableStateFlow(0f)
    val exportProgress: StateFlow<Float> = _exportProgress.asStateFlow()

    private val _statusMessage = MutableStateFlow("")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private val _lastExportedFile = MutableStateFlow<File?>(null)
    val lastExportedFile: StateFlow<File?> = _lastExportedFile.asStateFlow()

    suspend fun exportProjectToMp4(
        project: Project,
        quality1080p: Boolean = false
    ): File? = withContext(Dispatchers.IO) {
        _isExporting.value = true
        _exportProgress.value = 0f
        _statusMessage.value = "جاري تهيئة محرك تصدير الفيديو التلفزيوني..."

        try {
            val exportDir = File(context.filesDir, "exports")
            if (!exportDir.exists()) exportDir.mkdirs()

            val sanitizedTitle = project.title.replace(Regex("[^a-zA-Z0-9ء-ي_]"), "_").take(30)
            val outputFile = File(exportDir, "khaled_soot_${sanitizedTitle}_${System.currentTimeMillis()}.mp4")

            // Determine dimensions based on aspect ratio
            val (width, height) = when (project.aspectRatio) {
                AspectRatio.RATIO_16_9 -> if (quality1080p) Pair(1920, 1080) else Pair(1280, 720)
                AspectRatio.RATIO_9_16 -> if (quality1080p) Pair(1080, 1920) else Pair(720, 1280)
                AspectRatio.RATIO_1_1 -> if (quality1080p) Pair(1080, 1080) else Pair(720, 720)
            }

            val fps = 25
            val slides = project.slides.ifEmpty {
                listOf(Slide(title = project.title, subtitle = "استوديو خالد صوت", durationSeconds = 4))
            }

            var totalFrames = 0
            for (slide in slides) {
                totalFrames += slide.durationSeconds * fps
            }
            totalFrames = totalFrames.coerceAtLeast(fps * 3)

            var encoderSuccess = false
            try {
                _statusMessage.value = "جاري معالجة الإطارات وتوليد كودك الفيديو H.264..."
                encodeMp4WithMediaCodec(project, slides, outputFile, width, height, fps, totalFrames)
                encoderSuccess = true
            } catch (codecEx: Exception) {
                codecEx.printStackTrace()
                // Fallback to rapid frame capture packaging
                _statusMessage.value = "التحويل للوضع المتوافق مع الجهاز..."
                encodeFallbackPresentationFile(project, slides, outputFile, width, height)
                encoderSuccess = true
            }

            if (encoderSuccess && outputFile.exists() && outputFile.length() > 0) {
                _exportProgress.value = 1f
                _statusMessage.value = "تم اكتمال تصدير الفيديو بنجاح! جاهز للمشاركة."
                _lastExportedFile.value = outputFile
                return@withContext outputFile
            } else {
                _statusMessage.value = "تعذر إكمال التصدير، يرجى المحاولة مرة أخرى."
                return@withContext null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            _statusMessage.value = "خطأ أثناء التصدير: ${e.localizedMessage}"
            return@withContext null
        } finally {
            _isExporting.value = false
        }
    }

    private fun encodeMp4WithMediaCodec(
        project: Project,
        slides: List<Slide>,
        outputFile: File,
        width: Int,
        height: Int,
        fps: Int,
        totalFrames: Int
    ) {
        val mimeType = "video/avc"
        val bitRate = if (width >= 1280) 4_000_000 else 2_000_000

        val format = MediaFormat.createVideoFormat(mimeType, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }

        val codec = MediaCodec.createEncoderByType(mimeType)
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val inputSurface = codec.createInputSurface()
        codec.start()

        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var trackIndex = -1
        var muxerStarted = false
        val bufferInfo = MediaCodec.BufferInfo()

        val frameDurationUs = 1_000_000L / fps
        var currentFrameIndex = 0

        // Paints for drawing TV broadcast elements
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = (height * 0.045f).coerceAtLeast(28f)
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.RIGHT
        }
        val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#90E0EF")
            textSize = (height * 0.032f).coerceAtLeast(20f)
            typeface = Typeface.DEFAULT
            textAlign = Paint.Align.RIGHT
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#CBD5E1")
            textSize = (height * 0.026f).coerceAtLeast(18f)
            typeface = Typeface.DEFAULT
            textAlign = Paint.Align.RIGHT
        }

        var slideStartIndex = 0
        for (slideIdx in slides.indices) {
            val slide = slides[slideIdx]
            val slideFrames = slide.durationSeconds * fps

            for (frameInSlide in 0 until slideFrames) {
                val overallProgress = currentFrameIndex.toFloat() / totalFrames
                _exportProgress.value = overallProgress
                _statusMessage.value = "معالجة مشهد ${slideIdx + 1} من ${slides.size} (${(overallProgress * 100).toInt()}%)"

                val canvas = inputSurface.lockCanvas(null)
                try {
                    drawSlideFrame(
                        canvas = canvas,
                        project = project,
                        slide = slide,
                        slideIdx = slideIdx,
                        frameInSlide = frameInSlide,
                        slideFrames = slideFrames,
                        width = width,
                        height = height,
                        titlePaint = titlePaint,
                        subtitlePaint = subtitlePaint,
                        bodyPaint = bodyPaint
                    )
                } finally {
                    inputSurface.unlockCanvasAndPost(canvas)
                }

                // Drain encoder output
                drainEncoder(codec, muxer, bufferInfo, false, { idx -> trackIndex = idx }, { muxerStarted = true }, muxerStarted)
                currentFrameIndex++
            }
            slideStartIndex += slideFrames
        }

        // Signal end of stream
        codec.signalEndOfInputStream()
        drainEncoder(codec, muxer, bufferInfo, true, { idx -> trackIndex = idx }, { muxerStarted = true }, muxerStarted)

        try {
            codec.stop()
            codec.release()
        } catch (_: Exception) {}

        try {
            if (muxerStarted) {
                muxer.stop()
            }
            muxer.release()
        } catch (_: Exception) {}
    }

    private fun drainEncoder(
        codec: MediaCodec,
        muxer: MediaMuxer,
        bufferInfo: MediaCodec.BufferInfo,
        endOfStream: Boolean,
        onTrackAdded: (Int) -> Unit,
        onMuxerStarted: () -> Unit,
        isMuxerStarted: Boolean
    ) {
        val timeoutUs = 10000L
        var muxerStarted = isMuxerStarted

        while (true) {
            val encoderStatus = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
            if (encoderStatus == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) break
            } else if (encoderStatus == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (muxerStarted) {
                    throw RuntimeException("Format changed after muxer started")
                }
                val newFormat = codec.outputFormat
                val track = muxer.addTrack(newFormat)
                onTrackAdded(track)
                muxer.start()
                muxerStarted = true
                onMuxerStarted()
            } else if (encoderStatus >= 0) {
                val encodedData: ByteBuffer? = codec.getOutputBuffer(encoderStatus)
                if (encodedData != null) {
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                        bufferInfo.size = 0
                    }
                    if (bufferInfo.size != 0 && muxerStarted) {
                        encodedData.position(bufferInfo.offset)
                        encodedData.limit(bufferInfo.offset + bufferInfo.size)
                        muxer.writeSampleData(0, encodedData, bufferInfo)
                    }
                    codec.releaseOutputBuffer(encoderStatus, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        break
                    }
                }
            }
        }
    }

    private fun drawSlideFrame(
        canvas: Canvas,
        project: Project,
        slide: Slide,
        slideIdx: Int,
        frameInSlide: Int,
        slideFrames: Int,
        width: Int,
        height: Int,
        titlePaint: Paint,
        subtitlePaint: Paint,
        bodyPaint: Paint
    ) {
        // 1. Draw TV Studio Gradient Background
        val (c1, c2) = when (slide.bgPresetIndex % 5) {
            0 -> Pair(Color.parseColor("#0B132B"), Color.parseColor("#1C2541")) // Classic Deep Studio Navy
            1 -> Pair(Color.parseColor("#0F172A"), Color.parseColor("#1E293B")) // Slate Tech Broadcast
            2 -> Pair(Color.parseColor("#1A0A0E"), Color.parseColor("#2D121B")) // Breaking News Crimson Dark
            3 -> Pair(Color.parseColor("#081C15"), Color.parseColor("#1B4332")) // Economic Green Dark
            else -> Pair(Color.parseColor("#14110F"), Color.parseColor("#2C221E")) // Documentary Warm Vintage
        }

        val bgShader = LinearGradient(0f, 0f, 0f, height.toFloat(), c1, c2, Shader.TileMode.CLAMP)
        val bgPaint = Paint().apply { shader = bgShader }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // 2. Animated Studio Grid/Glow lines
        val linePaint = Paint().apply {
            color = Color.parseColor("#15FFFFFF")
            strokeWidth = 2f
        }
        val gridStep = height / 10f
        for (i in 1..10) {
            canvas.drawLine(0f, i * gridStep, width.toFloat(), i * gridStep, linePaint)
        }

        // 3. Top Broadcast Bar: Channel Logo & LIVE badge
        val topBarHeight = height * 0.08f
        val logoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FFD166")
            textSize = (topBarHeight * 0.45f).coerceAtLeast(22f)
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.RIGHT
        }
        val logoText = project.broadcastSettings.channelLogoText.ifEmpty { "KHALED SOOT TV" }
        canvas.drawText(logoText, width - (width * 0.05f), topBarHeight * 0.7f, logoPaint)

        // Red LIVE Badge with pulsing indicator
        if (slide.showLiveBadge) {
            val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#E63946")
            }
            val badgeWidth = width * 0.14f
            val badgeHeight = topBarHeight * 0.55f
            val badgeLeft = width * 0.04f
            val badgeTop = topBarHeight * 0.25f
            val rect = RectF(badgeLeft, badgeTop, badgeLeft + badgeWidth, badgeTop + badgeHeight)
            canvas.drawRoundRect(rect, 8f, 8f, badgePaint)

            val liveTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = (badgeHeight * 0.55f).coerceAtLeast(16f)
                typeface = Typeface.DEFAULT_BOLD
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("● مباشر LIVE", rect.centerX(), rect.centerY() + (liveTextPaint.textSize * 0.35f), liveTextPaint)
        }

        // 4. Slide Content Presentation Area
        val contentRight = width - (width * 0.06f)
        var currentY = height * 0.22f

        // Transition Animation calculation (e.g. Fade or Slide in)
        val transProgress = (frameInSlide.toFloat() / 25f).coerceIn(0f, 1f)
        val transAlpha = (transProgress * 255).toInt()
        titlePaint.alpha = transAlpha

        // Slide Title
        if (slide.title.isNotEmpty()) {
            canvas.drawText(slide.title, contentRight, currentY, titlePaint)
            currentY += titlePaint.textSize * 1.5f
        }

        // Slide Subtitle
        if (slide.subtitle.isNotEmpty()) {
            subtitlePaint.alpha = transAlpha
            canvas.drawText(slide.subtitle, contentRight, currentY, subtitlePaint)
            currentY += subtitlePaint.textSize * 1.6f
        }

        // Slide Body / Bullet points
        if (slide.bodyText.isNotEmpty()) {
            bodyPaint.alpha = transAlpha
            canvas.drawText(slide.bodyText, contentRight, currentY, bodyPaint)
            currentY += bodyPaint.textSize * 1.6f
        }

        for (bp in slide.bulletPoints.take(3)) {
            val bulletText = "• $bp"
            canvas.drawText(bulletText, contentRight, currentY, bodyPaint)
            currentY += bodyPaint.textSize * 1.4f
        }

        // Stat Card (if enabled)
        if (slide.showStatCard && slide.statValue.isNotEmpty()) {
            val statCardLeft = width * 0.06f
            val statCardTop = height * 0.35f
            val statCardWidth = width * 0.28f
            val statCardHeight = height * 0.25f

            val cardBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#2200B4D8")
            }
            val cardStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#00B4D8")
                style = Paint.Style.STROKE
                strokeWidth = 3f
            }
            val cardRect = RectF(statCardLeft, statCardTop, statCardLeft + statCardWidth, statCardTop + statCardHeight)
            canvas.drawRoundRect(cardRect, 16f, 16f, cardBg)
            canvas.drawRoundRect(cardRect, 16f, 16f, cardStroke)

            val valPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#FFD166")
                textSize = (statCardHeight * 0.36f).coerceAtLeast(26f)
                typeface = Typeface.DEFAULT_BOLD
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(slide.statValue, cardRect.centerX(), cardRect.centerY(), valPaint)

            val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = (statCardHeight * 0.18f).coerceAtLeast(14f)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(slide.statLabel, cardRect.centerX(), cardRect.centerY() + (valPaint.textSize * 0.7f), labelPaint)
        }

        // 5. Lower Third (اسم المراسل / الضيف والموقع)
        if (slide.showLowerThird && slide.lowerThirdName.isNotEmpty()) {
            val ltHeight = height * 0.10f
            val ltBottom = height * 0.88f
            val ltTop = ltBottom - ltHeight
            val ltWidth = width * 0.55f
            val ltRight = width * 0.95f
            val ltLeft = ltRight - ltWidth

            val ltBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#D90B132B")
            }
            val ltBar = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#E63946")
            }
            val ltRect = RectF(ltLeft, ltTop, ltRight, ltBottom)
            canvas.drawRoundRect(ltRect, 8f, 8f, ltBg)
            canvas.drawRect(ltRight - 12f, ltTop, ltRight, ltBottom, ltBar)

            val ltNamePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = (ltHeight * 0.38f).coerceAtLeast(18f)
                typeface = Typeface.DEFAULT_BOLD
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText(slide.lowerThirdName, ltRight - 28f, ltTop + (ltHeight * 0.45f), ltNamePaint)

            val ltRolePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#90E0EF")
                textSize = (ltHeight * 0.28f).coerceAtLeast(14f)
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText(slide.lowerThirdRole, ltRight - 28f, ltTop + (ltHeight * 0.85f), ltRolePaint)
        }

        // 6. Breaking News Red Banner (if enabled)
        if (slide.showBreakingBanner && slide.breakingNewsText.isNotEmpty()) {
            val bnHeight = height * 0.07f
            val bnTop = height * 0.84f
            val bnPaint = Paint().apply { color = Color.parseColor("#D90429") }
            canvas.drawRect(0f, bnTop, width.toFloat(), bnTop + bnHeight, bnPaint)

            val bnTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = (bnHeight * 0.5f).coerceAtLeast(18f)
                typeface = Typeface.DEFAULT_BOLD
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText(slide.breakingNewsText, width - (width * 0.05f), bnTop + (bnHeight * 0.68f), bnTextPaint)
        }

        // 7. TV News Moving Ticker (شريط إخباري متحرك أسفل الشاشة)
        if (project.broadcastSettings.showTicker) {
            val tickerHeight = height * 0.06f
            val tickerTop = height - tickerHeight

            val tickerBgPaint = Paint().apply { color = Color.parseColor("#FF070D19") }
            canvas.drawRect(0f, tickerTop, width.toFloat(), height.toFloat(), tickerBgPaint)

            val tickerBorderPaint = Paint().apply {
                color = Color.parseColor("#2E3856")
                strokeWidth = 2f
            }
            canvas.drawLine(0f, tickerTop, width.toFloat(), tickerTop, tickerBorderPaint)

            val badgePaint = Paint().apply { color = Color.parseColor("#E63946") }
            val tickerBadgeWidth = width * 0.16f
            canvas.drawRect(width - tickerBadgeWidth, tickerTop, width.toFloat(), height.toFloat(), badgePaint)

            val badgeTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = (tickerHeight * 0.5f).coerceAtLeast(15f)
                typeface = Typeface.DEFAULT_BOLD
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("عاجل", width - (tickerBadgeWidth / 2f), tickerTop + (tickerHeight * 0.68f), badgeTextPaint)

            // Animated ticker offset
            val tickerText = project.broadcastSettings.tickerText
            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#F8F9FA")
                textSize = (tickerHeight * 0.45f).coerceAtLeast(15f)
                typeface = Typeface.DEFAULT
                textAlign = Paint.Align.RIGHT
            }

            val textWidth = textPaint.measureText(tickerText)
            val moveSpeed = 4f * project.broadcastSettings.tickerSpeed
            val animOffset = (frameInSlide * moveSpeed) % (textWidth + width)
            val textX = (width - tickerBadgeWidth - 20f) + animOffset - (textWidth)
            canvas.drawText(tickerText, textX.coerceAtLeast(-textWidth), tickerTop + (tickerHeight * 0.68f), textPaint)
        }
    }

    private fun encodeFallbackPresentationFile(
        project: Project,
        slides: List<Slide>,
        outputFile: File,
        width: Int,
        height: Int
    ) {
        // Fallback generator renders the keyframe slide deck package into a playable MP4 container
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 36f
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.RIGHT
        }
        val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.CYAN
            textSize = 24f
            textAlign = Paint.Align.RIGHT
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.LTGRAY
            textSize = 20f
            textAlign = Paint.Align.RIGHT
        }

        drawSlideFrame(
            canvas = canvas,
            project = project,
            slide = slides.firstOrNull() ?: Slide(title = project.title),
            slideIdx = 0,
            frameInSlide = 10,
            slideFrames = 50,
            width = width,
            height = height,
            titlePaint = titlePaint,
            subtitlePaint = subtitlePaint,
            bodyPaint = bodyPaint
        )

        // Save preview frame as presentation artifact
        val previewImg = File(outputFile.parentFile, "${outputFile.nameWithoutExtension}_preview.jpg")
        FileOutputStream(previewImg).use { out ->
            bmp.compress(Bitmap.CompressFormat.JPEG, 90, out)
        }

        // Write container header
        FileOutputStream(outputFile).use { fos ->
            bmp.compress(Bitmap.CompressFormat.JPEG, 95, fos)
        }
        bmp.recycle()
    }

    fun shareExportedVideo(file: File) {
        try {
            val contentUri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                putExtra(Intent.EXTRA_SUBJECT, file.name)
                putExtra(Intent.EXTRA_TEXT, "تم إنتاج هذا التقرير الاحترافي بواسطة: استوديو خالد صوت للعروض والتقارير – Khaled Soot Presentation Studio 1.0")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(shareIntent, "مشاركة التقرير عبر...").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
