package com.example.data.repository

import android.content.Context
import com.example.data.model.AspectRatio
import com.example.data.model.AudioConfig
import com.example.data.model.BroadcastSettings
import com.example.data.model.Project
import com.example.data.model.Slide
import com.example.data.model.TemplateCategory
import com.example.data.model.TransitionType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class ProjectRepository(private val context: Context) {

    private val storageFile = File(context.filesDir, "khaled_soot_projects.json")
    private val _projects = MutableStateFlow<List<Project>>(emptyList())
    val projects: StateFlow<List<Project>> = _projects.asStateFlow()

    suspend fun initialize() {
        withContext(Dispatchers.IO) {
            val list = loadFromDisk()
            if (list.isEmpty()) {
                val samples = createSampleProjects()
                saveToDisk(samples)
                _projects.value = samples
            } else {
                _projects.value = list
            }
        }
    }

    suspend fun saveProject(project: Project) {
        withContext(Dispatchers.IO) {
            val currentList = _projects.value.toMutableList()
            val index = currentList.indexOfFirst { it.id == project.id }
            val updatedProject = project.copy(updatedAt = System.currentTimeMillis())
            if (index >= 0) {
                currentList[index] = updatedProject
            } else {
                currentList.add(0, updatedProject)
            }
            saveToDisk(currentList)
            _projects.value = currentList
        }
    }

    suspend fun deleteProject(projectId: String) {
        withContext(Dispatchers.IO) {
            val currentList = _projects.value.filter { it.id != projectId }
            saveToDisk(currentList)
            _projects.value = currentList
        }
    }

    suspend fun duplicateProject(source: Project): Project {
        return withContext(Dispatchers.IO) {
            val duplicated = source.copy(
                id = UUID.randomUUID().toString(),
                title = "${source.title} (نسخة)",
                slides = source.slides.map { it.copy(id = UUID.randomUUID().toString()) },
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            saveProject(duplicated)
            duplicated
        }
    }

    fun getProjectById(id: String): Project? {
        return _projects.value.firstOrNull { it.id == id }
    }

    private fun loadFromDisk(): List<Project> {
        return try {
            if (!storageFile.exists()) return emptyList()
            val text = storageFile.readText()
            if (text.isBlank()) return emptyList()
            val jsonArray = JSONArray(text)
            val list = mutableListOf<Project>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(deserializeProject(obj))
            }
            list
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    private fun saveToDisk(list: List<Project>) {
        try {
            val jsonArray = JSONArray()
            for (p in list) {
                jsonArray.put(serializeProject(p))
            }
            storageFile.writeText(jsonArray.toString(2))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun serializeProject(p: Project): JSONObject {
        val root = JSONObject()
        root.put("id", p.id)
        root.put("title", p.title)
        root.put("description", p.description)
        root.put("aspectRatio", p.aspectRatio.name)
        root.put("createdAt", p.createdAt)
        root.put("updatedAt", p.updatedAt)

        // BroadcastSettings
        val bs = JSONObject()
        bs.put("channelLogoText", p.broadcastSettings.channelLogoText)
        bs.put("channelSubText", p.broadcastSettings.channelSubText)
        bs.put("tickerText", p.broadcastSettings.tickerText)
        bs.put("showTicker", p.broadcastSettings.showTicker)
        bs.put("tickerSpeed", p.broadcastSettings.tickerSpeed.toDouble())
        bs.put("studioLocation", p.broadcastSettings.studioLocation)
        bs.put("presenterName", p.broadcastSettings.presenterName)
        root.put("broadcastSettings", bs)

        // AudioConfig
        val ac = JSONObject()
        ac.put("voiceoverPath", p.audioConfig.voiceoverPath ?: "")
        ac.put("voiceoverDurationMs", p.audioConfig.voiceoverDurationMs)
        ac.put("selectedMusicPreset", p.audioConfig.selectedMusicPreset)
        ac.put("voiceVolume", p.audioConfig.voiceVolume.toDouble())
        ac.put("musicVolume", p.audioConfig.musicVolume.toDouble())
        ac.put("autoDucking", p.audioConfig.autoDucking)
        root.put("audioConfig", ac)

        // Slides
        val slidesArray = JSONArray()
        for (s in p.slides) {
            val so = JSONObject()
            so.put("id", s.id)
            so.put("title", s.title)
            so.put("subtitle", s.subtitle)
            so.put("bodyText", s.bodyText)
            val bp = JSONArray()
            s.bulletPoints.forEach { bp.put(it) }
            so.put("bulletPoints", bp)
            so.put("templateCategory", s.templateCategory.name)
            so.put("bgPresetIndex", s.bgPresetIndex)
            so.put("imageUri", s.imageUri ?: "")
            so.put("imagePosition", s.imagePosition)
            so.put("durationSeconds", s.durationSeconds)
            so.put("transition", s.transition.name)
            so.put("lowerThirdName", s.lowerThirdName)
            so.put("lowerThirdRole", s.lowerThirdRole)
            so.put("showLowerThird", s.showLowerThird)
            so.put("showLiveBadge", s.showLiveBadge)
            so.put("breakingNewsText", s.breakingNewsText)
            so.put("showBreakingBanner", s.showBreakingBanner)
            so.put("statValue", s.statValue)
            so.put("statLabel", s.statLabel)
            so.put("showStatCard", s.showStatCard)
            slidesArray.put(so)
        }
        root.put("slides", slidesArray)
        return root
    }

    private fun deserializeProject(root: JSONObject): Project {
        val id = root.optString("id", UUID.randomUUID().toString())
        val title = root.optString("title", "مشروع جديد")
        val description = root.optString("description", "")
        val aspectRatio = try {
            AspectRatio.valueOf(root.optString("aspectRatio", AspectRatio.RATIO_16_9.name))
        } catch (_: Exception) {
            AspectRatio.RATIO_16_9
        }
        val createdAt = root.optLong("createdAt", System.currentTimeMillis())
        val updatedAt = root.optLong("updatedAt", System.currentTimeMillis())

        val bsObj = root.optJSONObject("broadcastSettings")
        val broadcastSettings = if (bsObj != null) {
            BroadcastSettings(
                channelLogoText = bsObj.optString("channelLogoText", "KHALED SOOT TV"),
                channelSubText = bsObj.optString("channelSubText", "صوت الخبر والتحليل"),
                tickerText = bsObj.optString("tickerText", "استوديو خالد صوت: التغطية مستمرة..."),
                showTicker = bsObj.optBoolean("showTicker", true),
                tickerSpeed = bsObj.optDouble("tickerSpeed", 1.0).toFloat(),
                studioLocation = bsObj.optString("studioLocation", "الرياض - الاستوديو الرئيسي"),
                presenterName = bsObj.optString("presenterName", "خالد صوت")
            )
        } else BroadcastSettings()

        val acObj = root.optJSONObject("audioConfig")
        val audioConfig = if (acObj != null) {
            val vPath = acObj.optString("voiceoverPath", "")
            AudioConfig(
                voiceoverPath = if (vPath.isNotEmpty()) vPath else null,
                voiceoverDurationMs = acObj.optLong("voiceoverDurationMs", 0L),
                selectedMusicPreset = acObj.optString("selectedMusicPreset", "BREAKING_NEWS"),
                voiceVolume = acObj.optDouble("voiceVolume", 1.0).toFloat(),
                musicVolume = acObj.optDouble("musicVolume", 0.45).toFloat(),
                autoDucking = acObj.optBoolean("autoDucking", true)
            )
        } else AudioConfig()

        val slides = mutableListOf<Slide>()
        val slidesArray = root.optJSONArray("slides")
        if (slidesArray != null) {
            for (i in 0 until slidesArray.length()) {
                val so = slidesArray.getJSONObject(i)
                val bpList = mutableListOf<String>()
                val bpArray = so.optJSONArray("bulletPoints")
                if (bpArray != null) {
                    for (j in 0 until bpArray.length()) {
                        bpList.add(bpArray.getString(j))
                    }
                }
                val cat = try {
                    TemplateCategory.valueOf(so.optString("templateCategory", TemplateCategory.TV_NEWS.name))
                } catch (_: Exception) {
                    TemplateCategory.TV_NEWS
                }
                val trans = try {
                    TransitionType.valueOf(so.optString("transition", TransitionType.FADE.name))
                } catch (_: Exception) {
                    TransitionType.FADE
                }
                val imgUri = so.optString("imageUri", "")
                slides.add(
                    Slide(
                        id = so.optString("id", UUID.randomUUID().toString()),
                        title = so.optString("title", ""),
                        subtitle = so.optString("subtitle", ""),
                        bodyText = so.optString("bodyText", ""),
                        bulletPoints = bpList,
                        templateCategory = cat,
                        bgPresetIndex = so.optInt("bgPresetIndex", 0),
                        imageUri = if (imgUri.isNotEmpty()) imgUri else null,
                        imagePosition = so.optString("imagePosition", "SPLIT"),
                        durationSeconds = so.optInt("durationSeconds", 5),
                        transition = trans,
                        lowerThirdName = so.optString("lowerThirdName", ""),
                        lowerThirdRole = so.optString("lowerThirdRole", ""),
                        showLowerThird = so.optBoolean("showLowerThird", false),
                        showLiveBadge = so.optBoolean("showLiveBadge", true),
                        breakingNewsText = so.optString("breakingNewsText", ""),
                        showBreakingBanner = so.optBoolean("showBreakingBanner", false),
                        statValue = so.optString("statValue", ""),
                        statLabel = so.optString("statLabel", ""),
                        showStatCard = so.optBoolean("showStatCard", false)
                    )
                )
            }
        }

        return Project(
            id = id,
            title = title,
            description = description,
            aspectRatio = aspectRatio,
            slides = slides,
            broadcastSettings = broadcastSettings,
            audioConfig = audioConfig,
            createdAt = createdAt,
            updatedAt = updatedAt
        )
    }

    private fun createSampleProjects(): List<Project> {
        val proj1 = Project(
            id = "proj_tv_broadcast_sample",
            title = "تقرير تلفزيوني: ثورة الذكاء الاصطناعي والإعلام الجديد",
            description = "قالب إخباري متكامل مع شريط عاجل وشارات استوديو خالد صوت ومؤشرات بيانية",
            aspectRatio = AspectRatio.RATIO_16_9,
            broadcastSettings = BroadcastSettings(
                channelLogoText = "KHALED SOOT NEWS",
                channelSubText = "تغطية مباشرة وحصرية",
                tickerText = "عاجل: استوديو خالد صوت يدشن أحدث تقنيات الإنتاج التلفزيوني والمونتاج السحابي الذكي...",
                showTicker = true,
                studioLocation = "الرياض - الاستوديو 1",
                presenterName = "خالد صوت"
            ),
            audioConfig = AudioConfig(
                selectedMusicPreset = "BREAKING_NEWS",
                musicVolume = 0.4f,
                autoDucking = true
            ),
            slides = listOf(
                Slide(
                    id = "s1",
                    title = "عاجل: ثورة التحول الرقمي تكتسح الاستوديوهات التلفزيونية",
                    subtitle = "نشرة الرابعة التفاعلية - استوديو خالد صوت",
                    bodyText = "تشهد منصات الإنتاج الرقمي نقلة تاريخية مع دمج تقنيات البث التلفزيوني الفوري ومحررات العروض التفاعلية.",
                    templateCategory = TemplateCategory.TV_NEWS,
                    bgPresetIndex = 0,
                    showBreakingBanner = true,
                    breakingNewsText = "عاجل | إطلاق استوديو خالد صوت للتقارير والعروض التلفزيونية الاحترافية 1.0",
                    lowerThirdName = "خالد صوت",
                    lowerThirdRole = "معد ومقدم التقرير الرئيسي",
                    showLowerThird = true,
                    showLiveBadge = true,
                    durationSeconds = 6,
                    transition = TransitionType.FADE
                ),
                Slide(
                    id = "s2",
                    title = "مؤشرات نمو المشاهدات وصناعة المحتوى الرقمي",
                    subtitle = "إحصائيات استثنائية لمنصات الفيديو التفاعلي خلال العام الجاري",
                    bodyText = "أظهرت بيانات استوديو التحليلات ارتفاع استهلاك التقارير الرقمية السريعة والوثائقيات القصيرة.",
                    bulletPoints = listOf(
                        "ارتفاع نسبة التفاعل مع التقارير المصورة بنسبة 140%",
                        "اعتماد كبرى المحطات الفضائية على أشرطة الأخبار الذكية",
                        "دمج التعليق الصوتي المباشر مع خلفيات الموسيقى التصويرية"
                    ),
                    templateCategory = TemplateCategory.ECONOMIC,
                    bgPresetIndex = 1,
                    showStatCard = true,
                    statValue = "+140%",
                    statLabel = "نمو التفاعل مع تقارير الفيديو التلفزيونية",
                    lowerThirdName = "مركز الرصد الإعلامي",
                    lowerThirdRole = "استوديو التحليل البياني",
                    showLowerThird = true,
                    durationSeconds = 7,
                    transition = TransitionType.SLIDE
                ),
                Slide(
                    id = "s3",
                    title = "خاتمة التقرير: مستقبل الإنتاج الإعلامي عبر الهواتف الذكية",
                    subtitle = "استوديو خالد صوت للعروض والتقارير - الإصدار 1.0",
                    bodyText = "يقدم استوديو خالد صوت حلاً شاملاً يغني عن البرمجيات المعقدة، ويمنح صناع المحتوى قوة استوديوهات البث التلفزيوني في راحة اليد.",
                    templateCategory = TemplateCategory.TV_NEWS,
                    bgPresetIndex = 2,
                    showBreakingBanner = false,
                    showLiveBadge = false,
                    durationSeconds = 5,
                    transition = TransitionType.ZOOM
                )
            )
        )

        val proj2 = Project(
            id = "proj_doc_sample",
            title = "وثائقي: أسرار الحضارات القديمة وطرق القوافل",
            description = "سرد وثائقي تاريخي بنمط كلاسيكي وانتقالات سينمائية",
            aspectRatio = AspectRatio.RATIO_16_9,
            broadcastSettings = BroadcastSettings(
                channelLogoText = "KHALED SOOT DOCS",
                channelSubText = "الوثائقية العالمية",
                tickerText = "استوديو الوثائقيات: رحلة استكشافية عبر آلاف السنين في أعماق التاريخ...",
                showTicker = true,
                studioLocation = "استوديو الوثائقيات التاريخية",
                presenterName = "صوت الراوي"
            ),
            audioConfig = AudioConfig(
                selectedMusicPreset = "DOCUMENTARY",
                musicVolume = 0.5f,
                autoDucking = true
            ),
            slides = listOf(
                Slide(
                    id = "s_doc_1",
                    title = "بين رمال الزمان: عندما رسم الأجداد طرق التجارة العالمية",
                    subtitle = "الفصل الأول - درب البخور وحضارات الجزيرة العربية",
                    bodyText = "منذ فجر التاريخ، شقت القوافل دروباً أضاءت مسار التجارة القديمة وربطت بين موانئ الشرق وأسواق الغرب.",
                    bulletPoints = listOf(
                        "أكثر من 3000 عام من التبادل الحضاري والتجاري",
                        "نقوش أثرية تؤرخ لأعظم الرحلات الاستكشافية",
                        "محطات استراحة تحولت إلى مدن عامرة بالتجارة"
                    ),
                    templateCategory = TemplateCategory.HISTORICAL_DOC,
                    bgPresetIndex = 3,
                    showLowerThird = true,
                    lowerThirdName = "د. المؤرخ عبد الرحمن",
                    lowerThirdRole = "باحث في الآثار والحضارات القديمة",
                    durationSeconds = 8,
                    transition = TransitionType.FADE
                ),
                Slide(
                    id = "s_doc_2",
                    title = "العمارة الحجرية: معجزات هندسية تحدت القرون",
                    subtitle = "الفصل الثاني - الهندسة والابتكار المائي",
                    bodyText = "ابتكر المعماريون القدماء أنظمة قنوات وسدود مائية أبقت الواحات حية وسط الصحاري القاسية.",
                    templateCategory = TemplateCategory.HISTORICAL_DOC,
                    bgPresetIndex = 4,
                    showStatCard = true,
                    statValue = "3,200",
                    statLabel = "عام على بناء أولى السدود الحجرية المنظمة",
                    durationSeconds = 7,
                    transition = TransitionType.ZOOM
                )
            )
        )

        val proj3 = Project(
            id = "proj_edu_sample",
            title = "عرض تدريبي: فن الإلقاء والتأثير التلفزيوني",
            description = "حقيبة تدريبية تعليمية متكاملة لمهارات الصوت والإلقاء الإخباري",
            aspectRatio = AspectRatio.RATIO_16_9,
            broadcastSettings = BroadcastSettings(
                channelLogoText = "KHALED SOOT ACADEMY",
                channelSubText = "أكاديمية التدريب الإعلامي",
                tickerText = "دورة الإلقاء الإخباري وصناعة التقارير الاحترافية - مع المدرب خالد صوت",
                showTicker = false
            ),
            audioConfig = AudioConfig(
                selectedMusicPreset = "CALM_PIANO",
                musicVolume = 0.3f,
                autoDucking = false
            ),
            slides = listOf(
                Slide(
                    id = "s_edu_1",
                    title = "قواعد الصوت الذهبي أمام الميكروفون",
                    subtitle = "المحور الأول: التنفس العميق والوقفات المعبرة",
                    bodyText = "الصوت ليس مجرد نبرة، بل هو أداة نقل المشاعر وإبراز قوة الفكرة أمام الجمهور.",
                    bulletPoints = listOf(
                        "التنفس البطني لتوليد نبرة صوتية مستقرة ورنانة",
                        "الوقفات الذكية عند علامات الترقيم لمنح المعنى حقه",
                        "تلوين الصوت بين الخبر العاجل والتحليل المتأني"
                    ),
                    templateCategory = TemplateCategory.EDUCATIONAL,
                    bgPresetIndex = 0,
                    lowerThirdName = "خالد صوت",
                    lowerThirdRole = "مدرب مهارات الصوت والإلقاء التلفزيوني",
                    showLowerThird = true,
                    durationSeconds = 6,
                    transition = TransitionType.WIPE
                )
            )
        )

        return listOf(proj1, proj2, proj3)
    }
}
