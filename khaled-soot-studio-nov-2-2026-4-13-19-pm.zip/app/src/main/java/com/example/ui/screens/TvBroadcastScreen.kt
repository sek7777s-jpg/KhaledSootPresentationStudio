package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VideoLabel
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SlideCanvasView
import com.example.ui.theme.StudioBlue
import com.example.ui.theme.StudioBlueGlow
import com.example.ui.theme.StudioGold
import com.example.ui.theme.StudioGoldLight
import com.example.ui.theme.StudioNavyBorder
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.StudioRed
import com.example.ui.theme.StudioRedDark
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.viewmodel.StudioViewModel

@Composable
fun TvBroadcastScreen(viewModel: StudioViewModel) {
    val project by viewModel.currentProject.collectAsState()
    val currentSlideIndex by viewModel.currentSlideIndex.collectAsState()

    if (project == null || project!!.slides.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("الرجاء اختيار مشروع نشط لتفعيل استوديو التقارير التلفزيونية", color = StudioTextMuted)
        }
        return
    }

    val activeProject = project!!
    val currentSlide = activeProject.slides.getOrNull(currentSlideIndex) ?: activeProject.slides.first()
    val broadcastSettings = activeProject.broadcastSettings

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Live Preview with Ticker & Graphics
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioRed.copy(alpha = 0.6f), RoundedCornerShape(10.dp)),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.LiveTv,
                                contentDescription = "TV",
                                tint = StudioRed,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "مخرج البث التلفزيوني الحي",
                                color = StudioGold,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            text = "شريحة ${currentSlideIndex + 1} من ${activeProject.slides.size}",
                            color = StudioBlueGlow,
                            fontSize = 11.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    SlideCanvasView(
                        slide = currentSlide,
                        broadcastSettings = broadcastSettings,
                        aspectRatio = activeProject.aspectRatio,
                        isLiveAnimated = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Quick Broadcast Layout Presets
            Text(
                text = "قوالب الشارات التلفزيونية الجاهزة:",
                color = StudioTextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Button(
                    onClick = {
                        viewModel.updateCurrentSlide(
                            currentSlide.copy(
                                showBreakingBanner = true,
                                breakingNewsText = "عاجل | تغطية حصرية ومباشرة عبر استوديو خالد صوت",
                                showLowerThird = true,
                                lowerThirdName = "خالد صوت",
                                lowerThirdRole = "مراسل الاستوديو الميداني",
                                showLiveBadge = true
                            )
                        )
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = StudioRed),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text("عاجل إخباري", fontSize = 10.5.sp, color = Color.White, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        viewModel.updateCurrentSlide(
                            currentSlide.copy(
                                showStatCard = true,
                                statValue = "+88.5%",
                                statLabel = "نمو مؤشرات التداول والاستثمار",
                                showLowerThird = true,
                                lowerThirdName = "قسم الاقتصاد والأسواق",
                                lowerThirdRole = "التحليل المالي اليومي",
                                showBreakingBanner = false
                            )
                        )
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = StudioBlue),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text("إحصائيات ورسوم", fontSize = 10.5.sp, color = StudioNavyDark, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        viewModel.updateCurrentSlide(
                            currentSlide.copy(
                                showLowerThird = true,
                                lowerThirdName = "ضيف الاستوديو الخاص",
                                lowerThirdRole = "خبير الاستراتيجيات الإعلامية",
                                showBreakingBanner = false,
                                showStatCard = false
                            )
                        )
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = StudioNavySurface),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text("مقابلة وضيف", fontSize = 10.5.sp, color = StudioTextPrimary, fontWeight = FontWeight.Bold)
                }
            }

            // Channel Branding Settings
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Tv,
                            contentDescription = "Logo",
                            tint = StudioGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "هوية وشعار القناة الفضائية",
                            color = StudioGold,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedTextField(
                        value = broadcastSettings.channelLogoText,
                        onValueChange = {
                            viewModel.updateBroadcastSettings(broadcastSettings.copy(channelLogoText = it))
                        },
                        label = { Text("شعار القناة (أعلى الشاشة)", color = StudioTextSecondary) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = StudioNavyDark,
                            unfocusedContainerColor = StudioNavyDark,
                            focusedTextColor = StudioTextPrimary,
                            unfocusedTextColor = StudioTextPrimary,
                            focusedIndicatorColor = StudioBlue,
                            unfocusedIndicatorColor = StudioNavyBorder
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "إظهار شارة البث الحي (مباشر LIVE):",
                            color = StudioTextPrimary,
                            fontSize = 12.sp
                        )
                        Switch(
                            checked = currentSlide.showLiveBadge,
                            onCheckedChange = {
                                viewModel.updateCurrentSlide(currentSlide.copy(showLiveBadge = it))
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = StudioRed, checkedTrackColor = StudioRedDark)
                        )
                    }
                }
            }

            // Moving Ticker Tape Settings (شريط الأخبار المتحرك)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Campaign,
                                contentDescription = "Ticker",
                                tint = StudioRed,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "شريط الأخبار المتحرك أسفل الشاشة",
                                color = StudioTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Switch(
                            checked = broadcastSettings.showTicker,
                            onCheckedChange = {
                                viewModel.updateBroadcastSettings(broadcastSettings.copy(showTicker = it))
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = StudioBlue, checkedTrackColor = StudioNavySurface)
                        )
                    }

                    if (broadcastSettings.showTicker) {
                        OutlinedTextField(
                            value = broadcastSettings.tickerText,
                            onValueChange = {
                                viewModel.updateBroadcastSettings(broadcastSettings.copy(tickerText = it))
                            },
                            label = { Text("نص شريط الأخبار", color = StudioTextSecondary) },
                            maxLines = 2,
                            modifier = Modifier.fillMaxWidth(),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = StudioNavyDark,
                                unfocusedContainerColor = StudioNavyDark,
                                focusedTextColor = StudioTextPrimary,
                                unfocusedTextColor = StudioTextPrimary,
                                focusedIndicatorColor = StudioBlue,
                                unfocusedIndicatorColor = StudioNavyBorder
                            )
                        )

                        Text(
                            text = "سرعة حركة الشريط الإخباري:",
                            color = StudioTextSecondary,
                            fontSize = 11.sp
                        )

                        Slider(
                            value = broadcastSettings.tickerSpeed,
                            onValueChange = {
                                viewModel.updateBroadcastSettings(broadcastSettings.copy(tickerSpeed = it))
                            },
                            valueRange = 0.5f..2.5f,
                            colors = SliderDefaults.colors(thumbColor = StudioGold, activeTrackColor = StudioGold)
                        )
                    }
                }
            }

            // Lower Third Settings (شارة اسم المراسل / الضيف)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = "LowerThird",
                                tint = StudioBlue,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "شارة التعريف (Lower Third)",
                                color = StudioTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Switch(
                            checked = currentSlide.showLowerThird,
                            onCheckedChange = {
                                viewModel.updateCurrentSlide(currentSlide.copy(showLowerThird = it))
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = StudioBlue, checkedTrackColor = StudioNavySurface)
                        )
                    }

                    if (currentSlide.showLowerThird) {
                        OutlinedTextField(
                            value = currentSlide.lowerThirdName,
                            onValueChange = {
                                viewModel.updateCurrentSlide(currentSlide.copy(lowerThirdName = it))
                            },
                            label = { Text("اسم المتحدث أو الضيف أو المراسل", color = StudioTextSecondary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = StudioNavyDark,
                                unfocusedContainerColor = StudioNavyDark,
                                focusedTextColor = StudioTextPrimary,
                                unfocusedTextColor = StudioTextPrimary,
                                focusedIndicatorColor = StudioBlue,
                                unfocusedIndicatorColor = StudioNavyBorder
                            )
                        )

                        OutlinedTextField(
                            value = currentSlide.lowerThirdRole,
                            onValueChange = {
                                viewModel.updateCurrentSlide(currentSlide.copy(lowerThirdRole = it))
                            },
                            label = { Text("الصفة، التخصص، أو الموقع الميداني", color = StudioTextSecondary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = StudioNavyDark,
                                unfocusedContainerColor = StudioNavyDark,
                                focusedTextColor = StudioTextPrimary,
                                unfocusedTextColor = StudioTextPrimary,
                                focusedIndicatorColor = StudioBlue,
                                unfocusedIndicatorColor = StudioNavyBorder
                            )
                        )
                    }
                }
            }

            // Stat Card Settings
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Analytics,
                                contentDescription = "Stats",
                                tint = StudioGold,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "بطاقة الأرقام والرسوم البيانية التوضيحية",
                                color = StudioTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Switch(
                            checked = currentSlide.showStatCard,
                            onCheckedChange = {
                                viewModel.updateCurrentSlide(currentSlide.copy(showStatCard = it))
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = StudioGold, checkedTrackColor = StudioNavySurface)
                        )
                    }

                    if (currentSlide.showStatCard) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = currentSlide.statValue,
                                onValueChange = {
                                    viewModel.updateCurrentSlide(currentSlide.copy(statValue = it))
                                },
                                label = { Text("الرقم / النسبة", color = StudioTextSecondary) },
                                singleLine = true,
                                modifier = Modifier.weight(0.4f),
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = StudioNavyDark,
                                    unfocusedContainerColor = StudioNavyDark,
                                    focusedTextColor = StudioTextPrimary,
                                    unfocusedTextColor = StudioTextPrimary,
                                    focusedIndicatorColor = StudioGold,
                                    unfocusedIndicatorColor = StudioNavyBorder
                                )
                            )

                            OutlinedTextField(
                                value = currentSlide.statLabel,
                                onValueChange = {
                                    viewModel.updateCurrentSlide(currentSlide.copy(statLabel = it))
                                },
                                label = { Text("وصف المؤشر أو الإحصائية", color = StudioTextSecondary) },
                                singleLine = true,
                                modifier = Modifier.weight(0.6f),
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = StudioNavyDark,
                                    unfocusedContainerColor = StudioNavyDark,
                                    focusedTextColor = StudioTextPrimary,
                                    unfocusedTextColor = StudioTextPrimary,
                                    focusedIndicatorColor = StudioGold,
                                    unfocusedIndicatorColor = StudioNavyBorder
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(70.dp))
        }
    }
}
