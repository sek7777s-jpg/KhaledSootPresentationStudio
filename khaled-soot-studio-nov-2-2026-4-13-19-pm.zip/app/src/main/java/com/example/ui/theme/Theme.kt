package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val StudioDarkColorScheme = darkColorScheme(
    primary = StudioBlue,
    onPrimary = StudioNavyDark,
    primaryContainer = StudioNavySurface,
    onPrimaryContainer = StudioBlueGlow,
    secondary = StudioRed,
    onSecondary = StudioTextPrimary,
    secondaryContainer = StudioRedDark,
    onSecondaryContainer = StudioTextPrimary,
    tertiary = StudioGold,
    onTertiary = StudioNavyDark,
    tertiaryContainer = StudioNavyCard,
    onTertiaryContainer = StudioGoldLight,
    background = StudioNavyDark,
    onBackground = StudioTextPrimary,
    surface = StudioNavyCard,
    onSurface = StudioTextPrimary,
    surfaceVariant = StudioNavySurface,
    onSurfaceVariant = StudioTextSecondary,
    outline = StudioNavyBorder
)

@Composable
fun KhaledSootStudioTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = StudioNavyDark.toArgb()
                window.navigationBarColor = StudioNavyDark.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = StudioDarkColorScheme,
        typography = Typography,
        content = content
    )
}
