package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Slide
import com.example.data.model.TemplateCategory
import com.example.data.model.TransitionType
import com.example.ui.components.SlideCanvasView
import com.example.ui.theme.StudioBlue
import com.example.ui.theme.StudioBlueGlow
import com.example.ui.theme.StudioGold
import com.example.ui.theme.StudioGoldLight
import com.example.ui.theme.StudioNavyBorder
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.StudioRed
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.viewmodel.StudioViewModel

@Composable
fun SlideEditorScreen(viewModel: StudioViewModel) {
    val project by viewModel.currentProject.collectAsState()
    val currentSlideIndex by viewModel.currentSlideIndex.collectAsState()

    if (project == null || project!!.slides.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("لا يوجد مشروع نشط، يرجى اختيار مشروع من القائمة", color = StudioTextMuted)
        }
        return
    }

    val activeProject = project!!
    val currentSlide = activeProject.slides.getOrNull(currentSlideIndex) ?: activeProject.slides.first()

    var newBulletText by remember { mutableStateOf("") }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Live Preview of Current Slide
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioBlue.copy(alpha = 0.5f), RoundedCornerShape(10.dp)),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "معاينة الشريحة المباشرة (${currentSlideIndex + 1}/${activeProject.slides.size})",
                            color = StudioGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "مدة العرض: ${currentSlide.durationSeconds} ثوانٍ",
                            color = StudioBlueGlow,
                            fontSize = 11.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    SlideCanvasView(
                        slide = currentSlide,
                        broadcastSettings = activeProject.broadcastSettings,
                        aspectRatio = activeProject.aspectRatio,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Slides Carousel Strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                activeProject.slides.forEachIndexed { index, slide ->
                    val isSelected = index == currentSlideIndex
                    Box(
                        modifier = Modifier
                            .width(80.dp)
                            .height(55.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) StudioBlue else StudioNavySurface)
                            .border(
                                1.5.dp,
                                if (isSelected) StudioGold else StudioNavyBorder,
                                RoundedCornerShape(6.dp)
                            )
                            .clickable { viewModel.selectSlide(index) }
                            .padding(4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "شريحة ${index + 1}",
                                color = if (isSelected) StudioNavyDark else StudioTextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${slide.durationSeconds}ث",
                                color = if (isSelected) StudioNavyDark else StudioBlueGlow,
                                fontSize = 9.sp
                            )
                        }
                    }
                }

                // Add Slide Button
                Box(
                    modifier = Modifier
                        .width(70.dp)
                        .height(55.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(StudioRed)
                        .clickable { viewModel.addSlide() }
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "إضافة",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Slide Actions Bar: Duplicate, Delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = { viewModel.duplicateSlide(currentSlideIndex) },
                        colors = ButtonDefaults.buttonColors(containerColor = StudioNavySurface),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Duplicate",
                            modifier = Modifier.size(14.dp),
                            tint = StudioTextSecondary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تكرار الشريحة", fontSize = 11.sp, color = StudioTextSecondary)
                    }

                    if (activeProject.slides.size > 1) {
                        Button(
                            onClick = { viewModel.deleteSlide(currentSlideIndex) },
                            colors = ButtonDefaults.buttonColors(containerColor = StudioNavySurface),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete",
                                modifier = Modifier.size(14.dp),
                                tint = StudioRed
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("حذف", fontSize = 11.sp, color = StudioRed)
                        }
                    }
                }

                // Duration adjustment
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Timer,
                        contentDescription = "Timer",
                        tint = StudioGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${currentSlide.durationSeconds} ثانية",
                        color = StudioTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Duration Slider
            Column {
                Text(
                    text = "تحديد مدة ظهور الشريحة:",
                    color = StudioTextSecondary,
                    fontSize = 11.sp
                )
                Slider(
                    value = currentSlide.durationSeconds.toFloat(),
                    onValueChange = { newSec ->
                        viewModel.updateCurrentSlide(currentSlide.copy(durationSeconds = newSec.toInt()))
                    },
                    valueRange = 2f..20f,
                    steps = 17,
                    colors = SliderDefaults.colors(
                        thumbColor = StudioBlue,
                        activeTrackColor = StudioBlue,
                        inactiveTrackColor = StudioNavyBorder
                    )
                )
            }

            // Template Category Selector
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "نمط وقالب الشريحة:",
                    color = StudioTextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    TemplateCategory.values().forEach { cat ->
                        val isChosen = currentSlide.templateCategory == cat
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isChosen) StudioNavySurface else StudioNavyDark)
                                .border(
                                    1.dp,
                                    if (isChosen) StudioGold else StudioNavyBorder,
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable {
                                    viewModel.updateCurrentSlide(currentSlide.copy(templateCategory = cat))
                                }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = when (cat) {
                                    TemplateCategory.TV_NEWS -> "إخباري"
                                    TemplateCategory.HISTORICAL_DOC -> "وثائقي"
                                    TemplateCategory.ECONOMIC -> "اقتصادي"
                                    TemplateCategory.EDUCATIONAL -> "تعليمي"
                                },
                                color = if (isChosen) StudioGoldLight else StudioTextMuted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Background Theme Presets
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "خلفية الشريحة الاستوديو:",
                    color = StudioTextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val bgNames = listOf("كحلي ملكي", "رمادي تقني", "أحمر إخباري", "أخضر أسواق", "وثائقي دافئ")
                    val bgColors = listOf(
                        Color(0xFF0F1A2E),
                        Color(0xFF1E293B),
                        Color(0xFF2C0F17),
                        Color(0xFF0F382B),
                        Color(0xFF2E2018)
                    )

                    bgNames.forEachIndexed { idx, name ->
                        val isSelected = currentSlide.bgPresetIndex == idx
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(bgColors[idx])
                                .border(
                                    2.dp,
                                    if (isSelected) StudioBlue else StudioNavyBorder,
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable {
                                    viewModel.updateCurrentSlide(currentSlide.copy(bgPresetIndex = idx))
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = name,
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Text Inputs: Title & Subtitle
            OutlinedTextField(
                value = currentSlide.title,
                onValueChange = { viewModel.updateCurrentSlide(currentSlide.copy(title = it)) },
                label = { Text("عنوان الشريحة الرئيسي", color = StudioTextSecondary) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = StudioNavyDark,
                    unfocusedContainerColor = StudioNavyDark,
                    focusedTextColor = StudioTextPrimary,
                    unfocusedTextColor = StudioTextPrimary,
                    focusedIndicatorColor = StudioBlue,
                    unfocusedIndicatorColor = StudioNavyBorder
                )
            )

            OutlinedTextField(
                value = currentSlide.subtitle,
                onValueChange = { viewModel.updateCurrentSlide(currentSlide.copy(subtitle = it)) },
                label = { Text("العنوان الفرعي للشريحة", color = StudioTextSecondary) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = StudioNavyDark,
                    unfocusedContainerColor = StudioNavyDark,
                    focusedTextColor = StudioTextPrimary,
                    unfocusedTextColor = StudioTextPrimary,
                    focusedIndicatorColor = StudioBlue,
                    unfocusedIndicatorColor = StudioNavyBorder
                )
            )

            // Body Text
            OutlinedTextField(
                value = currentSlide.bodyText,
                onValueChange = { viewModel.updateCurrentSlide(currentSlide.copy(bodyText = it)) },
                label = { Text("النص التوضيحي للتقرير", color = StudioTextSecondary) },
                maxLines = 4,
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = StudioNavyDark,
                    unfocusedContainerColor = StudioNavyDark,
                    focusedTextColor = StudioTextPrimary,
                    unfocusedTextColor = StudioTextPrimary,
                    focusedIndicatorColor = StudioBlue,
                    unfocusedIndicatorColor = StudioNavyBorder
                )
            )

            // Bullet Points Management
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "نقاط المحتوى الرئيسية:",
                    color = StudioTextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                currentSlide.bulletPoints.forEachIndexed { bIdx, bp ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(StudioNavySurface)
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "• $bp",
                            color = StudioTextPrimary,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = {
                                val mut = currentSlide.bulletPoints.toMutableList()
                                mut.removeAt(bIdx)
                                viewModel.updateCurrentSlide(currentSlide.copy(bulletPoints = mut))
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Remove",
                                tint = StudioRed,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = newBulletText,
                        onValueChange = { newBulletText = it },
                        placeholder = { Text("أدخل نقطة توضيحية جديدة...", color = StudioTextMuted) },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = StudioNavyDark,
                            unfocusedContainerColor = StudioNavyDark,
                            focusedTextColor = StudioTextPrimary,
                            unfocusedTextColor = StudioTextPrimary,
                            focusedIndicatorColor = StudioBlue,
                            unfocusedIndicatorColor = StudioNavyBorder
                        )
                    )

                    Button(
                        onClick = {
                            if (newBulletText.isNotBlank()) {
                                val mut = currentSlide.bulletPoints.toMutableList()
                                mut.add(newBulletText.trim())
                                viewModel.updateCurrentSlide(currentSlide.copy(bulletPoints = mut))
                                newBulletText = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = StudioBlue),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("إضافة", color = StudioNavyDark, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Transition Selector
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "الانتقال السينمائي عند بداية الشريحة:",
                    color = StudioTextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    TransitionType.values().forEach { trans ->
                        val isChosen = currentSlide.transition == trans
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isChosen) StudioNavySurface else StudioNavyDark)
                                .border(
                                    1.dp,
                                    if (isChosen) StudioBlue else StudioNavyBorder,
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable {
                                    viewModel.updateCurrentSlide(currentSlide.copy(transition = trans))
                                }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = trans.titleAr,
                                color = if (isChosen) StudioBlueGlow else StudioTextMuted,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(70.dp))
        }
    }
}
