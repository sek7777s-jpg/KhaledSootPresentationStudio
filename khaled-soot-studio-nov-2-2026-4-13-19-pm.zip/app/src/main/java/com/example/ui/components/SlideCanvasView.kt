package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.AspectRatio
import com.example.data.model.BroadcastSettings
import com.example.data.model.Slide
import com.example.ui.theme.StudioBlue
import com.example.ui.theme.StudioBlueGlow
import com.example.ui.theme.StudioGold
import com.example.ui.theme.StudioGoldLight
import com.example.ui.theme.StudioNavyBorder
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.StudioRed
import com.example.ui.theme.StudioRedDark
import com.example.ui.theme.StudioRedGlow
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary

@Composable
fun SlideCanvasView(
    slide: Slide,
    broadcastSettings: BroadcastSettings,
    aspectRatio: AspectRatio = AspectRatio.RATIO_16_9,
    modifier: Modifier = Modifier,
    isLiveAnimated: Boolean = true
) {
    // Background gradient presets
    val bgGradients = listOf(
        // 0: Deep Classic Studio Navy
        Brush.verticalGradient(listOf(Color(0xFF070D19), Color(0xFF132238), Color(0xFF0F1A2E))),
        // 1: Slate Tech Broadcast
        Brush.verticalGradient(listOf(Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF0F172A))),
        // 2: Crimson Newsroom Dark
        Brush.verticalGradient(listOf(Color(0xFF18080C), Color(0xFF2C0F17), Color(0xFF15070A))),
        // 3: Wealth & Markets Emerald
        Brush.verticalGradient(listOf(Color(0xFF061A14), Color(0xFF0F382B), Color(0xFF071E17))),
        // 4: Documentary Amber / Warm Vintage
        Brush.verticalGradient(listOf(Color(0xFF1C130E), Color(0xFF2E2018), Color(0xFF170F0B)))
    )

    val currentBg = bgGradients[slide.bgPresetIndex % bgGradients.size]

    val infiniteTransition = rememberInfiniteTransition(label = "ticker_and_pulse")
    val liveAlpha by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "live_pulse"
    )

    val tickerOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -1200f,
        animationSpec = infiniteRepeatable(
            animation = tween(22000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ticker_scroll"
    )

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        BoxWithConstraints(
            modifier = modifier
                .aspectRatio(aspectRatio.ratioFloat)
                .clip(RoundedCornerShape(8.dp))
                .background(currentBg)
                .border(1.5.dp, StudioNavyBorder, RoundedCornerShape(8.dp))
                .drawBehind {
                    // Studio subtle grid lines
                    val linePaint = Color(0x10FFFFFF)
                    val stepY = size.height / 8f
                    for (i in 1..7) {
                        drawLine(
                            color = linePaint,
                            start = Offset(0f, i * stepY),
                            end = Offset(size.width, i * stepY),
                            strokeWidth = 1f
                        )
                    }
                }
        ) {
            val canvasWidth = maxWidth
            val canvasHeight = maxHeight

            // TOP TV BAR: Channel Logo & LIVE badge
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Channel Logo
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(StudioGold, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = broadcastSettings.channelLogoText.ifEmpty { "KHALED SOOT TV" },
                        color = StudioGoldLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                }

                // LIVE Badge
                if (slide.showLiveBadge) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(StudioRed)
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.FiberManualRecord,
                                contentDescription = "Live dot",
                                tint = if (isLiveAnimated) StudioRedGlow.copy(alpha = liveAlpha) else Color.White,
                                modifier = Modifier.size(8.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "مباشر LIVE",
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // MAIN SLIDE CONTENT AREA
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(
                        top = 32.dp,
                        bottom = if (broadcastSettings.showTicker) 32.dp else 12.dp,
                        start = 14.dp,
                        end = 14.dp
                    ),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Title & Subtitle
                Column {
                    if (slide.title.isNotEmpty()) {
                        Text(
                            text = slide.title,
                            color = StudioTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 20.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    if (slide.subtitle.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = slide.subtitle,
                            color = StudioBlueGlow,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Middle Section: Body + Image / Stat Card
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left/Main Text & Bullet Points
                    Column(
                        modifier = Modifier
                            .weight(if (slide.showStatCard || !slide.imageUri.isNullOrEmpty()) 0.62f else 1f)
                    ) {
                        if (slide.bodyText.isNotEmpty()) {
                            Text(
                                text = slide.bodyText,
                                color = StudioTextSecondary,
                                fontSize = 10.sp,
                                lineHeight = 14.sp,
                                maxLines = 3,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        if (slide.bulletPoints.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            slide.bulletPoints.take(3).forEach { bp ->
                                Row(
                                    modifier = Modifier.padding(vertical = 1.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(4.dp)
                                            .background(StudioBlue, CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text(
                                        text = bp,
                                        color = StudioTextSecondary,
                                        fontSize = 9.5.sp,
                                        lineHeight = 13.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }

                    // Stat Card or Image Graphic
                    if (slide.showStatCard && slide.statValue.isNotEmpty()) {
                        Box(
                            modifier = Modifier
                                .weight(0.38f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(StudioNavySurface.copy(alpha = 0.85f))
                                .border(1.dp, StudioBlue.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.TrendingUp,
                                    contentDescription = "Trend",
                                    tint = StudioGold,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = slide.statValue,
                                    color = StudioGoldLight,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = slide.statLabel,
                                    color = StudioTextPrimary,
                                    fontSize = 8.5.sp,
                                    textAlign = TextAlign.Center,
                                    maxLines = 2,
                                    lineHeight = 11.sp
                                )
                            }
                        }
                    } else if (!slide.imageUri.isNullOrEmpty()) {
                        Box(
                            modifier = Modifier
                                .weight(0.38f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(6.dp))
                                .border(1.dp, StudioNavyBorder, RoundedCornerShape(6.dp))
                        ) {
                            AsyncImage(
                                model = slide.imageUri,
                                contentDescription = "Slide Image",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }

                // Lower Third / Breaking Banner
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    // Breaking News Red Banner
                    if (slide.showBreakingBanner && slide.breakingNewsText.isNotEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(StudioRed)
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = slide.breakingNewsText,
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    // Lower Third (Guest/Presenter Card)
                    if (slide.showLowerThird && slide.lowerThirdName.isNotEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.75f)
                                .clip(RoundedCornerShape(4.dp))
                                .background(StudioNavyDark.copy(alpha = 0.95f))
                                .border(1.dp, StudioRedDark.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .width(3.dp)
                                        .height(20.dp)
                                        .background(StudioRed)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = slide.lowerThirdName,
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                    if (slide.lowerThirdRole.isNotEmpty()) {
                                        Text(
                                            text = slide.lowerThirdRole,
                                            color = StudioBlueGlow,
                                            fontSize = 8.5.sp,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // TV NEWS MOVING TICKER (شريط إخباري متحرك أسفل الشاشة)
            if (broadcastSettings.showTicker) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(24.dp)
                        .align(Alignment.BottomCenter)
                        .background(StudioNavyDark)
                        .border(1.dp, StudioNavyBorder)
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Red Breaking Badge
                        Box(
                            modifier = Modifier
                                .background(StudioRed)
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "عاجل",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        // Moving Ticker Text
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 8.dp)
                        ) {
                            Text(
                                text = broadcastSettings.tickerText,
                                color = StudioTextPrimary,
                                fontSize = 9.sp,
                                maxLines = 1,
                                modifier = Modifier.offset {
                                    if (isLiveAnimated) {
                                        IntOffset(tickerOffset.toInt(), 0)
                                    } else {
                                        IntOffset(0, 0)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
