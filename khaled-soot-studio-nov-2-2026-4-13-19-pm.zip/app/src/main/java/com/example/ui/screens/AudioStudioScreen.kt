package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.theme.StudioBlue
import com.example.ui.theme.StudioBlueGlow
import com.example.ui.theme.StudioGold
import com.example.ui.theme.StudioGoldLight
import com.example.ui.theme.StudioNavyBorder
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.StudioRed
import com.example.ui.theme.StudioRedDark
import com.example.ui.theme.StudioRedGlow
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.viewmodel.StudioViewModel

@Composable
fun AudioStudioScreen(viewModel: StudioViewModel) {
    val context = LocalContext.current
    val project by viewModel.currentProject.collectAsState()
    val audioManager = viewModel.audioManager

    val isRecording by audioManager.isRecording.collectAsState()
    val recDuration by audioManager.recordingDurationSec.collectAsState()
    val amplitude by audioManager.amplitude.collectAsState()
    val isPlayingPreview by audioManager.isPlayingPreview.collectAsState()

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasMicPermission = isGranted
        if (isGranted) {
            val path = audioManager.startRecording()
            if (path != null && project != null) {
                viewModel.updateAudioConfig(project!!.audioConfig.copy(voiceoverPath = path))
            }
        }
    }

    if (project == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("الرجاء اختيار مشروع للبدء بالهندسة الصوتية", color = StudioTextMuted)
        }
        return
    }

    val activeProject = project!!
    val audioConfig = activeProject.audioConfig

    val infiniteTransition = rememberInfiniteTransition(label = "mic_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_anim"
    )

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Info
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavySurface),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = "Audio Studio",
                        tint = StudioGold,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "استوديو هندسة الصوت والتعليق التلفزيوني",
                            color = StudioTextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "تسجيل مباشر من الميكروفون + موسيقى تصويرية وخفض ذكي (Ducking)",
                            color = StudioBlueGlow,
                            fontSize = 10.5.sp
                        )
                    }
                }
            }

            // SECTION 1: Voiceover Microphone Recording
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, if (isRecording) StudioRed else StudioNavyBorder, RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.RecordVoiceOver,
                                contentDescription = "Voice",
                                tint = StudioRed,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "مسار التعليق الصوتي المباشر (Voiceover)",
                                color = StudioTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (isRecording) {
                            Text(
                                text = "● جاري التسجيل الحي",
                                color = StudioRedGlow,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Big Mic Recording Button
                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .clip(CircleShape)
                            .background(if (isRecording) StudioRed else StudioNavySurface)
                            .border(2.dp, if (isRecording) StudioGold else StudioBlue, CircleShape)
                            .clickable {
                                if (isRecording) {
                                    val savedPath = audioManager.stopRecording()
                                    if (savedPath != null) {
                                        viewModel.updateAudioConfig(audioConfig.copy(voiceoverPath = savedPath))
                                    }
                                } else {
                                    if (hasMicPermission) {
                                        val path = audioManager.startRecording()
                                        if (path != null) {
                                            viewModel.updateAudioConfig(audioConfig.copy(voiceoverPath = path))
                                        }
                                    } else {
                                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isRecording) Icons.Default.Stop else Icons.Default.Mic,
                            contentDescription = "Mic Record",
                            tint = if (isRecording) Color.White else StudioBlue,
                            modifier = Modifier.size(34.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Timer Display
                    val recMin = recDuration / 60
                    val recSec = recDuration % 60
                    Text(
                        text = String.format("%02d:%02d", recMin, recSec),
                        color = if (isRecording) StudioRedGlow else StudioTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Live Waveform visualizer bars
                    Row(
                        modifier = Modifier
                            .fillMaxWidth(0.7f)
                            .height(24.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (i in 0 until 12) {
                            val barHeight = if (isRecording) {
                                val dynamicFactor = (amplitude * (15 + (i % 5) * 6)).coerceIn(4f, 24f)
                                dynamicFactor.dp
                            } else {
                                4.dp
                            }
                            Box(
                                modifier = Modifier
                                    .width(4.dp)
                                    .height(barHeight)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(if (isRecording) StudioGold else StudioNavyBorder)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Voiceover File Status & Playback
                    if (!audioConfig.voiceoverPath.isNullOrEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(StudioNavySurface)
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "تم حفظ التعليق الصوتي للمشروع بنجاح",
                                color = StudioGoldLight,
                                fontSize = 11.sp
                            )

                            Button(
                                onClick = {
                                    if (isPlayingPreview) {
                                        audioManager.stopPlayback()
                                    } else {
                                        audioManager.playVoiceover(audioConfig.voiceoverPath, audioConfig.voiceVolume)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = StudioBlue),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Icon(
                                    imageVector = if (isPlayingPreview) Icons.Default.Stop else Icons.Default.PlayArrow,
                                    contentDescription = "Play",
                                    tint = StudioNavyDark,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isPlayingPreview) "إيقاف" else "استماع",
                                    color = StudioNavyDark,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // SECTION 2: Background Music Track
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = "Music",
                                tint = StudioGold,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "موسيقى الخلفية التصويرية",
                                color = StudioTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Preview Music Button
                        Button(
                            onClick = {
                                audioManager.startBackgroundMusic(
                                    audioConfig.selectedMusicPreset,
                                    audioConfig.musicVolume
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = StudioNavySurface),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Test Music",
                                tint = StudioGold,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تجربة النغمة", color = StudioGold, fontSize = 10.sp)
                        }
                    }

                    // Music Presets
                    val presets = listOf(
                        Pair("BREAKING_NEWS", "نشرة أخبار عاجلة درامية"),
                        Pair("DOCUMENTARY", "وثائقي تاريخي وسينمائي"),
                        Pair("ECONOMIC_BEAT", "إيقاع اقتصادي وتقني سريع"),
                        Pair("CALM_PIANO", "بيانو استوديو هادئ"),
                        Pair("NONE", "بدون موسيقى (صامت)")
                    )

                    presets.forEach { (presetKey, presetTitle) ->
                        val isChosen = audioConfig.selectedMusicPreset == presetKey
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isChosen) StudioNavySurface else StudioNavyDark)
                                .border(
                                    1.dp,
                                    if (isChosen) StudioGold else StudioNavyBorder,
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable {
                                    viewModel.updateAudioConfig(audioConfig.copy(selectedMusicPreset = presetKey))
                                    audioManager.startBackgroundMusic(presetKey, audioConfig.musicVolume)
                                }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = presetTitle,
                                    color = if (isChosen) StudioGoldLight else StudioTextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = if (isChosen) FontWeight.Bold else FontWeight.Normal
                                )

                                if (isChosen) {
                                    Text("● نشطة", color = StudioGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // SECTION 3: Audio Faders & Mixer
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "ميكسر التحكم في مستويات الصوت:",
                        color = StudioTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )

                    // Voice Volume Fader
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "مستوى التعليق الصوتي (Voice):",
                                color = StudioTextSecondary,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "${(audioConfig.voiceVolume * 100).toInt()}%",
                                color = StudioBlueGlow,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Slider(
                            value = audioConfig.voiceVolume,
                            onValueChange = {
                                viewModel.updateAudioConfig(audioConfig.copy(voiceVolume = it))
                            },
                            colors = SliderDefaults.colors(
                                thumbColor = StudioBlue,
                                activeTrackColor = StudioBlue
                            )
                        )
                    }

                    // Music Volume Fader
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "مستوى الموسيقى التصويرية (Music):",
                                color = StudioTextSecondary,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "${(audioConfig.musicVolume * 100).toInt()}%",
                                color = StudioGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Slider(
                            value = audioConfig.musicVolume,
                            onValueChange = {
                                viewModel.updateAudioConfig(audioConfig.copy(musicVolume = it))
                                audioManager.setMusicVolume(it)
                            },
                            colors = SliderDefaults.colors(
                                thumbColor = StudioGold,
                                activeTrackColor = StudioGold
                            )
                        )
                    }
                }
            }

            // SECTION 4: Smart Audio Ducking Toggle
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "خفض الموسيقى تلقائياً (Audio Ducking)",
                            color = StudioTextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "يقوم النظام بخفض صوت الموسيقى تلقائياً أثناء حديث المعلق الصوتي لإبراز وضوح الصوت.",
                            color = StudioTextMuted,
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )
                    }

                    Switch(
                        checked = audioConfig.autoDucking,
                        onCheckedChange = {
                            viewModel.updateAudioConfig(audioConfig.copy(autoDucking = it))
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = StudioBlue,
                            checkedTrackColor = StudioNavySurface
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(70.dp))
        }
    }
}
