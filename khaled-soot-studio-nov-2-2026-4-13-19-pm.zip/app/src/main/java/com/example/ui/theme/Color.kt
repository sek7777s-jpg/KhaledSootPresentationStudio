package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Broadcast Studio Dark Theme Colors
val StudioNavyDark = Color(0xFF070D19)      // Deep TV Studio Navy
val StudioNavyCard = Color(0xFF0F1A2E)      // Studio Card Navy
val StudioNavySurface = Color(0xFF162540)   // Elevated Surface
val StudioNavyBorder = Color(0xFF243B60)    // Element Border
val StudioNavyAccent = Color(0xFF1E3A8A)    // Deep Indigo Accent

// Brand Accents
val StudioRed = Color(0xFFE63946)           // Broadcast Breaking News Crimson
val StudioRedDark = Color(0xFFB51A2B)       // Darker Crimson
val StudioRedGlow = Color(0xFFFF4D5A)       // Glowing Red Live Badge

val StudioBlue = Color(0xFF00B4D8)          // Electric Studio Cyan/Blue
val StudioBlueGlow = Color(0xFF90E0EF)      // Highlighting Cyan
val StudioGold = Color(0xFFFFB703)          // Economic & Award Gold
val StudioGoldLight = Color(0xFFFFD166)     // Accent Gold

// Text & Monochromes
val StudioTextPrimary = Color(0xFFF8F9FA)   // High contrast white
val StudioTextSecondary = Color(0xFFCBD5E1) // Soft slate text
val StudioTextMuted = Color(0xFF94A3B8)     // Muted gray-blue
val StudioSuccess = Color(0xFF06D6A0)       // Green Live / Ok
val StudioWarning = Color(0xFFFB8500)       // Warning amber
