package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AspectRatio
import com.example.data.model.AudioConfig
import com.example.data.model.BroadcastSettings
import com.example.data.model.Project
import com.example.data.model.Slide
import com.example.data.model.SoundEffectItem
import com.example.data.model.StudioFontFamily
import com.example.data.model.TemplateCategory
import com.example.data.model.TextStyleConfig
import com.example.data.model.TransitionType
import com.example.data.repository.AudioStudioManager
import com.example.data.repository.ProjectRepository
import com.example.data.repository.SoundFxManager
import com.example.data.repository.VideoExporter
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

enum class StudioTab(val titleAr: String, val iconDesc: String) {
    PROJECTS("المشاريع", "إدارة وتصفح المشاريع"),
    SLIDES("العرض والشرائح", "إنشاء وتعديل عناصر الشريحة"),
    TV_STUDIO("استوديو الأخبار", "شارات وعواجل وشريط الأخبار"),
    TIMELINE("مونتاج الفيديو", "الخط الزمني والانتقالات"),
    AUDIO("استوديو الصوت", "تسجيل وميكساج ومؤثرات صوتية"),
    EXPORT("التصدير والمشاركة", "تصدير MP4 بجودة عالية")
}

class StudioViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ProjectRepository(application)
    val audioManager = AudioStudioManager(application)
    val soundFxManager = SoundFxManager(application)
    val videoExporter = VideoExporter(application)

    val projects: StateFlow<List<Project>> = repository.projects

    private val _selectedTab = MutableStateFlow(StudioTab.PROJECTS)
    val selectedTab: StateFlow<StudioTab> = _selectedTab.asStateFlow()

    private val _currentProject = MutableStateFlow<Project?>(null)
    val currentProject: StateFlow<Project?> = _currentProject.asStateFlow()

    private val _currentSlideIndex = MutableStateFlow(0)
    val currentSlideIndex: StateFlow<Int> = _currentSlideIndex.asStateFlow()

    // Playback Preview State
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playbackSlideIndex = MutableStateFlow(0)
    val playbackSlideIndex: StateFlow<Int> = _playbackSlideIndex.asStateFlow()

    private val _playbackElapsedSeconds = MutableStateFlow(0f)
    val playbackElapsedSeconds: StateFlow<Float> = _playbackElapsedSeconds.asStateFlow()

    private val _showAboutDialog = MutableStateFlow(false)
    val showAboutDialog: StateFlow<Boolean> = _showAboutDialog.asStateFlow()

    val availableSoundEffects: List<SoundEffectItem> = soundFxManager.availableEffects
    val currentlyPlayingFxId: StateFlow<String?> = soundFxManager.currentlyPlayingId

    private var playbackJob: Job? = null

    init {
        viewModelScope.launch {
            repository.initialize()
            soundFxManager.initialize()
            if (_currentProject.value == null && repository.projects.value.isNotEmpty()) {
                _currentProject.value = repository.projects.value.first()
            }
        }
    }

    fun selectTab(tab: StudioTab) {
        _selectedTab.value = tab
    }

    fun openAboutDialog(show: Boolean) {
        _showAboutDialog.value = show
    }

    fun selectProject(project: Project) {
        _currentProject.value = project
        _currentSlideIndex.value = 0
        _selectedTab.value = StudioTab.SLIDES
    }

    fun createNewProject(
        title: String = "مشروع تقرير جديد 2.0",
        category: TemplateCategory = TemplateCategory.TV_NEWS,
        aspectRatio: AspectRatio = AspectRatio.RATIO_16_9
    ) {
        viewModelScope.launch {
            val defaultSlide = Slide(
                title = "عنوان التقرير الإخباري الرئيسي",
                subtitle = "نشرة استوديو خالد صوت 2.0 المتطورة",
                bodyText = "استعراض تفاعلي لأهم الأحداث مع دعم استيراد الوسائط المتعددة والخطوط والتأثيرات الصوتية الحقيقية.",
                templateCategory = category,
                showBreakingBanner = true,
                breakingNewsText = "عاجل | استوديو خالد صوت 2.0 ينقل التغطية الميدانية",
                showLowerThird = true,
                lowerThirdName = "خالد صوت",
                lowerThirdRole = "المراسل الرئيسي",
                durationSeconds = 6,
                textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.KUFI.id, titleFontSizeSp = 20, isBold = true)
            )

            val newProj = Project(
                id = UUID.randomUUID().toString(),
                title = title,
                aspectRatio = aspectRatio,
                slides = listOf(defaultSlide),
                broadcastSettings = BroadcastSettings()
            )

            repository.saveProject(newProj)
            _currentProject.value = newProj
            _currentSlideIndex.value = 0
            _selectedTab.value = StudioTab.SLIDES
        }
    }

    fun duplicateProject(project: Project) {
        viewModelScope.launch {
            val dup = repository.duplicateProject(project)
            _currentProject.value = dup
        }
    }

    fun deleteProject(projectId: String) {
        viewModelScope.launch {
            repository.deleteProject(projectId)
            if (_currentProject.value?.id == projectId) {
                _currentProject.value = repository.projects.value.firstOrNull()
                _currentSlideIndex.value = 0
            }
        }
    }

    fun updateProjectTitle(newTitle: String) {
        val proj = _currentProject.value ?: return
        val updated = proj.copy(title = newTitle)
        _currentProject.value = updated
        autoSave(updated)
    }

    fun updateAspectRatio(ratio: AspectRatio) {
        val proj = _currentProject.value ?: return
        val updated = proj.copy(aspectRatio = ratio)
        _currentProject.value = updated
        autoSave(updated)
    }

    fun updateBroadcastSettings(settings: BroadcastSettings) {
        val proj = _currentProject.value ?: return
        val updated = proj.copy(broadcastSettings = settings)
        _currentProject.value = updated
        autoSave(updated)
    }

    fun updateAudioConfig(config: AudioConfig) {
        val proj = _currentProject.value ?: return
        val updated = proj.copy(audioConfig = config)
        _currentProject.value = updated
        autoSave(updated)
    }

    fun selectSlide(index: Int) {
        val proj = _currentProject.value ?: return
        if (index in proj.slides.indices) {
            _currentSlideIndex.value = index
        }
    }

    fun updateCurrentSlide(updatedSlide: Slide) {
        val proj = _currentProject.value ?: return
        val idx = _currentSlideIndex.value
        if (idx in proj.slides.indices) {
            val mutableList = proj.slides.toMutableList()
            mutableList[idx] = updatedSlide
            val updatedProj = proj.copy(slides = mutableList)
            _currentProject.value = updatedProj
            autoSave(updatedProj)
        }
    }

    // Media Import Operations
    fun setSlideImage(uriString: String) {
        val current = getCurrentSlide() ?: return
        val updatedMedia = (listOf(uriString) + current.mediaList.filter { it != uriString })
        updateCurrentSlide(current.copy(imageUri = uriString, mediaList = updatedMedia))
    }

    fun setSlideVideo(uriString: String) {
        val current = getCurrentSlide() ?: return
        val updatedMedia = (listOf(uriString) + current.mediaList.filter { it != uriString })
        updateCurrentSlide(current.copy(videoUri = uriString, mediaList = updatedMedia))
    }

    fun addMultipleMediaToSlide(uriStrings: List<String>) {
        val current = getCurrentSlide() ?: return
        val currentMedia = current.mediaList.toMutableList()
        uriStrings.forEach { if (!currentMedia.contains(it)) currentMedia.add(it) }
        val primaryImage = current.imageUri ?: uriStrings.firstOrNull()
        updateCurrentSlide(current.copy(imageUri = primaryImage, mediaList = currentMedia))
    }

    fun removeMediaFromSlide(uriString: String) {
        val current = getCurrentSlide() ?: return
        val currentMedia = current.mediaList.filter { it != uriString }
        val newImg = if (current.imageUri == uriString) currentMedia.firstOrNull() else current.imageUri
        val newVid = if (current.videoUri == uriString) null else current.videoUri
        updateCurrentSlide(current.copy(imageUri = newImg, videoUri = newVid, mediaList = currentMedia))
    }

    fun setSlideMediaPosition(position: String) {
        val current = getCurrentSlide() ?: return
        updateCurrentSlide(current.copy(imagePosition = position))
    }

    // Typography Operations
    fun updateSlideTextStyle(style: TextStyleConfig) {
        val current = getCurrentSlide() ?: return
        updateCurrentSlide(current.copy(textStyle = style))
    }

    // Audio Import & Sound Effects
    fun importAudioFile(uri: Uri) {
        viewModelScope.launch {
            val result = audioManager.importAudioFile(uri)
            if (result != null) {
                val (filePath, fileName) = result
                val proj = _currentProject.value ?: return@launch
                val updatedAudio = proj.audioConfig.copy(
                    customAudioPath = filePath,
                    customAudioName = fileName,
                    selectedMusicPreset = "CUSTOM"
                )
                updateAudioConfig(updatedAudio)
            }
        }
    }

    fun playSoundEffect(id: String, volume: Float = 0.8f) {
        soundFxManager.playSoundEffect(id, volume)
    }

    fun stopSoundEffect() {
        soundFxManager.stopSoundEffect()
    }

    fun selectSoundEffectForProject(id: String) {
        val proj = _currentProject.value ?: return
        updateAudioConfig(proj.audioConfig.copy(selectedSoundFxId = id))
    }

    fun getCurrentSlide(): Slide? {
        val proj = _currentProject.value ?: return null
        val idx = _currentSlideIndex.value
        return proj.slides.getOrNull(idx) ?: proj.slides.firstOrNull()
    }

    fun addSlide(category: TemplateCategory = TemplateCategory.TV_NEWS) {
        val proj = _currentProject.value ?: return
        val newSlide = Slide(
            title = "مشهد جديد #${proj.slides.size + 1}",
            subtitle = "وصف فرعي للمشهد",
            bodyText = "محتوى الشريحة التوضيحي للتقرير أو العرض التقديمي.",
            templateCategory = category,
            bgPresetIndex = (proj.slides.size % 5),
            durationSeconds = 5
        )
        val mutableList = proj.slides.toMutableList()
        mutableList.add(newSlide)
        val updatedProj = proj.copy(slides = mutableList)
        _currentProject.value = updatedProj
        _currentSlideIndex.value = mutableList.lastIndex
        autoSave(updatedProj)
    }

    fun duplicateSlide(index: Int) {
        val proj = _currentProject.value ?: return
        if (index in proj.slides.indices) {
            val source = proj.slides[index]
            val dup = source.copy(id = UUID.randomUUID().toString(), title = "${source.title} (نسخة)")
            val mutableList = proj.slides.toMutableList()
            mutableList.add(index + 1, dup)
            val updatedProj = proj.copy(slides = mutableList)
            _currentProject.value = updatedProj
            _currentSlideIndex.value = index + 1
            autoSave(updatedProj)
        }
    }

    fun deleteSlide(index: Int) {
        val proj = _currentProject.value ?: return
        if (proj.slides.size <= 1) return
        if (index in proj.slides.indices) {
            val mutableList = proj.slides.toMutableList()
            mutableList.removeAt(index)
            val updatedProj = proj.copy(slides = mutableList)
            _currentProject.value = updatedProj
            _currentSlideIndex.value = (index - 1).coerceAtLeast(0)
            autoSave(updatedProj)
        }
    }

    fun moveSlide(from: Int, to: Int) {
        val proj = _currentProject.value ?: return
        if (from in proj.slides.indices && to in proj.slides.indices && from != to) {
            val mutableList = proj.slides.toMutableList()
            val item = mutableList.removeAt(from)
            mutableList.add(to, item)
            val updatedProj = proj.copy(slides = mutableList)
            _currentProject.value = updatedProj
            _currentSlideIndex.value = to
            autoSave(updatedProj)
        }
    }

    // Playback Engine
    fun togglePlay() {
        if (_isPlaying.value) {
            stopPlayback()
        } else {
            startPlayback()
        }
    }

    private fun startPlayback() {
        val proj = _currentProject.value ?: return
        if (proj.slides.isEmpty()) return

        _isPlaying.value = true
        val totalSec = proj.slides.sumOf { it.durationSeconds }

        val audioConf = proj.audioConfig
        if (audioConf.selectedMusicPreset != "NONE" && audioConf.selectedMusicPreset != "CUSTOM") {
            audioManager.startBackgroundMusic(audioConf.selectedMusicPreset, audioConf.musicVolume)
        } else if (audioConf.selectedMusicPreset == "CUSTOM" && !audioConf.customAudioPath.isNullOrEmpty()) {
            audioManager.playCustomAudio(audioConf.customAudioPath, audioConf.musicVolume)
        }

        playbackJob?.cancel()
        playbackJob = viewModelScope.launch {
            var currentSec = _playbackElapsedSeconds.value
            if (currentSec >= totalSec) currentSec = 0f

            while (isActive && _isPlaying.value && currentSec < totalSec) {
                delay(100)
                currentSec += 0.1f
                _playbackElapsedSeconds.value = currentSec

                var accum = 0
                var activeIdx = 0
                for (i in proj.slides.indices) {
                    accum += proj.slides[i].durationSeconds
                    if (currentSec <= accum) {
                        activeIdx = i
                        break
                    }
                }
                _playbackSlideIndex.value = activeIdx
            }

            if (currentSec >= totalSec) {
                stopPlayback()
                _playbackElapsedSeconds.value = 0f
                _playbackSlideIndex.value = 0
            }
        }
    }

    fun stopPlayback() {
        _isPlaying.value = false
        playbackJob?.cancel()
        playbackJob = null
        audioManager.stopMusic()
        audioManager.stopPlayback()
        soundFxManager.stopSoundEffect()
    }

    fun seekPlaybackTo(seconds: Float) {
        _playbackElapsedSeconds.value = seconds
        val proj = _currentProject.value ?: return
        var accum = 0
        var activeIdx = 0
        for (i in proj.slides.indices) {
            accum += proj.slides[i].durationSeconds
            if (seconds <= accum) {
                activeIdx = i
                break
            }
        }
        _playbackSlideIndex.value = activeIdx
    }

    // Video Exporting & MediaStore
    fun exportCurrentProject(quality1080p: Boolean = false) {
        val proj = _currentProject.value ?: return
        viewModelScope.launch {
            videoExporter.exportProjectToMp4(proj, quality1080p)
        }
    }

    fun openExportedVideo() {
        videoExporter.openExportedVideo()
    }

    fun shareExportedVideo() {
        videoExporter.shareExportedVideo()
    }

    private fun autoSave(project: Project) {
        viewModelScope.launch {
            repository.saveProject(project)
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioManager.release()
        soundFxManager.stopSoundEffect()
        stopPlayback()
    }
}
