package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatAlignLeft
import androidx.compose.material.icons.filled.FormatAlignRight
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StudioFontFamily
import com.example.data.model.TextStyleConfig
import com.example.ui.theme.StudioBlue
import com.example.ui.theme.StudioBlueGlow
import com.example.ui.theme.StudioGold
import com.example.ui.theme.StudioGoldLight
import com.example.ui.theme.StudioNavyBorder
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.StudioRed
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary

@Composable
fun TextFormattingPanel(
    textStyle: TextStyleConfig,
    onStyleChange: (TextStyleConfig) -> Unit,
    modifier: Modifier = Modifier
) {
    val colorPresets = listOf(
        Pair("#F8F9FA", "أبيض ناصع"),
        Pair("#FFD166", "ذهبي استوديو"),
        Pair("#00B4D8", "أزرق سماوي"),
        Pair("#E63946", "أحمر عاجل"),
        Pair("#06D6A0", "أخضر اقتصادي"),
        Pair("#CBD5E1", "فضي كلاسيكي")
    )

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Card(
            modifier = modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.TextFields,
                            contentDescription = "Text Settings",
                            tint = StudioGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "لوحة تنسيق الخطوط والنصوص (Typography):",
                            color = StudioGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Bold Toggle & Alignment Buttons
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Bold Toggle
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (textStyle.isBold) StudioBlue else StudioNavySurface)
                                .clickable {
                                    onStyleChange(textStyle.copy(isBold = !textStyle.isBold))
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.FormatBold,
                                contentDescription = "Bold",
                                tint = if (textStyle.isBold) StudioNavyDark else StudioTextPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        // Alignment: Right, Center, Left
                        val alignIcons = listOf(
                            Triple("RIGHT", Icons.Default.FormatAlignRight, "يمين"),
                            Triple("CENTER", Icons.Default.FormatAlignCenter, "وسط"),
                            Triple("LEFT", Icons.Default.FormatAlignLeft, "يسار")
                        )

                        alignIcons.forEach { (alignKey, icon, desc) ->
                            val isSelected = textStyle.textAlignment == alignKey
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSelected) StudioBlue else StudioNavySurface)
                                    .clickable {
                                        onStyleChange(textStyle.copy(textAlignment = alignKey))
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = desc,
                                    tint = if (isSelected) StudioNavyDark else StudioTextMuted,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                // 1. Font Family Selector
                Text(
                    text = "نوع الخط (Font Family):",
                    color = StudioTextSecondary,
                    fontSize = 11.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    StudioFontFamily.values().forEach { font ->
                        val isChosen = textStyle.fontFamilyId == font.id
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isChosen) StudioNavySurface else StudioNavyDark)
                                .border(
                                    1.dp,
                                    if (isChosen) StudioGold else StudioNavyBorder,
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable {
                                    onStyleChange(textStyle.copy(fontFamilyId = font.id))
                                }
                                .padding(vertical = 7.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = font.titleAr.split(" ").first(),
                                color = if (isChosen) StudioGoldLight else StudioTextMuted,
                                fontSize = 10.sp,
                                fontWeight = if (isChosen) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }

                // 2. Font Size Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "حجم عنوان الشريحة:",
                            color = StudioTextSecondary,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "${textStyle.titleFontSizeSp} sp",
                            color = StudioBlueGlow,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Slider(
                        value = textStyle.titleFontSizeSp.toFloat(),
                        onValueChange = { onStyleChange(textStyle.copy(titleFontSizeSp = it.toInt())) },
                        valueRange = 14f..36f,
                        steps = 21,
                        colors = SliderDefaults.colors(
                            thumbColor = StudioBlue,
                            activeTrackColor = StudioBlue,
                            inactiveTrackColor = StudioNavyBorder
                        )
                    )
                }

                // 3. Color Palette Swatches
                Text(
                    text = "لون النص والعناوين:",
                    color = StudioTextSecondary,
                    fontSize = 11.sp
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    colorPresets.forEach { (hex, name) ->
                        val parsedColor = try { Color(android.graphics.Color.parseColor(hex)) } catch (_: Exception) { Color.White }
                        val isSelected = textStyle.textColorHex.equals(hex, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(parsedColor)
                                .border(
                                    2.dp,
                                    if (isSelected) StudioGold else StudioNavyBorder,
                                    CircleShape
                                )
                                .clickable {
                                    onStyleChange(textStyle.copy(textColorHex = hex))
                                }
                        )
                    }
                }
            }
        }
    }
}
