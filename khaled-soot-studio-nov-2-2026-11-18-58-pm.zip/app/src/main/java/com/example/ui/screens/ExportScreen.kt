package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AspectRatio
import com.example.ui.theme.StudioBlue
import com.example.ui.theme.StudioBlueGlow
import com.example.ui.theme.StudioGold
import com.example.ui.theme.StudioGoldLight
import com.example.ui.theme.StudioNavyBorder
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.StudioRed
import com.example.ui.theme.StudioRedDark
import com.example.ui.theme.StudioSuccess
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.viewmodel.StudioViewModel

@Composable
fun ExportScreen(viewModel: StudioViewModel) {
    val project by viewModel.currentProject.collectAsState()
    val videoExporter = viewModel.videoExporter

    val isExporting by videoExporter.isExporting.collectAsState()
    val exportProgress by videoExporter.exportProgress.collectAsState()
    val statusMessage by videoExporter.statusMessage.collectAsState()
    val lastExportedFile by videoExporter.lastExportedFile.collectAsState()
    val lastExportedPathDisplay by videoExporter.lastExportedPathDisplay.collectAsState()
    val lastExportedSizeBytes by videoExporter.lastExportedSizeBytes.collectAsState()
    val exportErrorMessage by videoExporter.exportErrorMessage.collectAsState()

    var is1080p by remember { mutableStateOf(false) }

    if (project == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("الرجاء اختيار مشروع للبدء بعملية التصدير", color = StudioTextMuted)
        }
        return
    }

    val activeProject = project!!
    val totalSeconds = activeProject.slides.sumOf { it.durationSeconds }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Info Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavySurface),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.MovieCreation,
                        contentDescription = "Export Engine",
                        tint = StudioGold,
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "محرك تصدير الفيديو التلفزيوني MP4 - الإصدار 2.0",
                            color = StudioTextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "ترميز H.264 حقيقي وحفظ مباشر في Movies/KhaledSootStudio عبر MediaStore",
                            color = StudioBlueGlow,
                            fontSize = 10.5.sp
                        )
                    }
                }
            }

            // Project Specifications Summary
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "تفاصيل التقرير الجاري تصديره:",
                        color = StudioTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("عنوان المشروع:", color = StudioTextSecondary, fontSize = 11.sp)
                        Text(activeProject.title, color = StudioGoldLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("عدد المشاهد والشرائح:", color = StudioTextSecondary, fontSize = 11.sp)
                        Text("${activeProject.slides.size} مشاهد", color = StudioBlueGlow, fontSize = 11.sp)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("المدة الإجمالية للتقرير:", color = StudioTextSecondary, fontSize = 11.sp)
                        Text("$totalSeconds ثانية", color = StudioBlueGlow, fontSize = 11.sp)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("مسار الصوت والمؤثرات:", color = StudioTextSecondary, fontSize = 11.sp)
                        val audioStatus = when {
                            !activeProject.audioConfig.voiceoverPath.isNullOrEmpty() -> "تعليق صوتي + مؤثرات ✓"
                            !activeProject.audioConfig.customAudioPath.isNullOrEmpty() -> "صوت مستورد + مؤثرات ✓"
                            else -> "موسيقى استوديو ومؤثرات ✓"
                        }
                        Text(audioStatus, color = StudioGold, fontSize = 11.sp)
                    }
                }
            }

            // Aspect Ratio Selector with Platform Presets
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "أبعاد الفيديو ومنصة النشر المستهدفة:",
                        color = StudioTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AspectRatio.values().forEach { ratio ->
                            val isChosen = activeProject.aspectRatio == ratio
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isChosen) StudioBlue else StudioNavyDark)
                                    .border(
                                        1.dp,
                                        if (isChosen) StudioGold else StudioNavyBorder,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .clickable { viewModel.updateAspectRatio(ratio) }
                                    .padding(vertical = 10.dp, horizontal = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = ratio.iconLabel,
                                        color = if (isChosen) StudioNavyDark else StudioTextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = when (ratio) {
                                            AspectRatio.RATIO_16_9 -> "تلفزيون ويوتيوب"
                                            AspectRatio.RATIO_9_16 -> "ريلز وتيك توك"
                                            AspectRatio.RATIO_1_1 -> "إنستغرام وفيسبوك"
                                        },
                                        color = if (isChosen) StudioNavyDark else StudioTextMuted,
                                        fontSize = 9.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Resolution Selector (720p vs 1080p)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "دقة التصدير وجودة الصورة:",
                        color = StudioTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // 720p HD
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (!is1080p) StudioNavySurface else StudioNavyDark)
                                .border(
                                    1.dp,
                                    if (!is1080p) StudioBlue else StudioNavyBorder,
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable { is1080p = false }
                                .padding(10.dp)
                        ) {
                            Column {
                                Text(
                                    text = "720p HD جودة قياسية",
                                    color = if (!is1080p) StudioBlueGlow else StudioTextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text("معالجة سريعة وحجم خفيف مناسب للواتساب", color = StudioTextMuted, fontSize = 9.sp)
                            }
                        }

                        // 1080p Full HD
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (is1080p) StudioNavySurface else StudioNavyDark)
                                .border(
                                    1.dp,
                                    if (is1080p) StudioGold else StudioNavyBorder,
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable { is1080p = true }
                                .padding(10.dp)
                        ) {
                            Column {
                                Text(
                                    text = "1080p Full HD فائق",
                                    color = if (is1080p) StudioGoldLight else StudioTextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text("أعلى وضوح للبث والشاشات الكبيرة واليوتيوب", color = StudioTextMuted, fontSize = 9.sp)
                            }
                        }
                    }
                }
            }

            // Error Message Banner (if failed)
            if (!exportErrorMessage.isNullOrEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, StudioRed, RoundedCornerShape(10.dp)),
                    colors = CardDefaults.cardColors(containerColor = StudioRedDark.copy(alpha = 0.25f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Error, contentDescription = "Error", tint = StudioRed, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(text = exportErrorMessage!!, color = StudioTextPrimary, fontSize = 11.sp)
                    }
                }
            }

            // Export Action or Progress Bar
            if (isExporting) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, StudioBlue, RoundedCornerShape(10.dp)),
                    colors = CardDefaults.cardColors(containerColor = StudioNavyCard)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CircularProgressIndicator(
                            progress = { exportProgress },
                            color = StudioRed,
                            modifier = Modifier.size(48.dp)
                        )

                        Text(
                            text = "${(exportProgress * 100).toInt()}%",
                            color = StudioGold,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black
                        )

                        Text(
                            text = statusMessage.ifEmpty { "جاري معالجة الإطارات وكودك الفيديو..." },
                            color = StudioTextSecondary,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )

                        LinearProgressIndicator(
                            progress = { exportProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = StudioBlue,
                            trackColor = StudioNavyBorder
                        )
                    }
                }
            } else {
                Button(
                    onClick = { viewModel.exportCurrentProject(is1080p) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = StudioRed),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = "Export MP4",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "بدء تصدير الفيديو MP4 الفعلي 2.0",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            // Export Succeeded Result Card (Strict validation: only if file exists and size > 0)
            if (lastExportedFile != null && lastExportedFile!!.exists() && lastExportedSizeBytes > 0L) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, StudioSuccess, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = StudioNavySurface)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Done",
                                tint = StudioSuccess,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "تم اكتمال التصدير والتحقق من حفظ ملف الفيديو بنجاح!",
                                color = StudioGoldLight,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            text = "مسار الحفظ في الهاتف: $lastExportedPathDisplay",
                            color = StudioTextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )

                        val sizeMb = lastExportedSizeBytes / (1024f * 1024f)
                        Text(
                            text = "الحجم الفعلي على الذاكرة: ${String.format("%.2f", sizeMb)} ميجابايت",
                            color = StudioBlueGlow,
                            fontSize = 11.sp
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Open Video Button
                            Button(
                                onClick = { viewModel.openExportedVideo() },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = StudioBlue),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = StudioNavyDark, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("مشاهدة الفيديو", color = StudioNavyDark, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            // Share Video Button
                            Button(
                                onClick = { viewModel.shareExportedVideo() },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = StudioGold),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = "Share", tint = StudioNavyDark, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("مشاركة الفيديو", color = StudioNavyDark, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(70.dp))
        }
    }
}
