package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AboutKhaledSootDialog
import com.example.ui.theme.StudioBlue
import com.example.ui.theme.StudioBlueGlow
import com.example.ui.theme.StudioGold
import com.example.ui.theme.StudioGoldLight
import com.example.ui.theme.StudioNavyBorder
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.StudioRed
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.viewmodel.StudioTab
import com.example.ui.viewmodel.StudioViewModel

@Composable
fun MainStudioScreen(viewModel: StudioViewModel) {
    val selectedTab by viewModel.selectedTab.collectAsState()
    val currentProject by viewModel.currentProject.collectAsState()
    val showAbout by viewModel.showAboutDialog.collectAsState()

    // Handle back button: if not in PROJECTS, go back to PROJECTS
    BackHandler(enabled = selectedTab != StudioTab.PROJECTS) {
        viewModel.selectTab(StudioTab.PROJECTS)
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars),
            containerColor = StudioNavyDark,
            topBar = {
                // TV Studio Header Bar
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(StudioNavyDark)
                                    .border(1.5.dp, StudioRed, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Videocam,
                                    contentDescription = "Studio Logo",
                                    tint = StudioGoldLight,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "استوديو خالد صوت",
                                        color = StudioTextPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(StudioRed)
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    ) {
                                        Text(
                                            text = "2.0",
                                            color = Color.White,
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Text(
                                    text = currentProject?.title ?: "للعروض والتقارير التلفزيونية",
                                    color = StudioBlueGlow,
                                    fontSize = 10.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        IconButton(
                            onClick = { viewModel.openAboutDialog(true) },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "Studio Details",
                                tint = StudioGold,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            },
            bottomBar = {
                NavigationBar(
                    modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars),
                    containerColor = StudioNavyCard,
                    tonalElevation = 8.dp
                ) {
                    val tabs = listOf(
                        Triple(StudioTab.PROJECTS, "المشاريع", Icons.Default.Folder),
                        Triple(StudioTab.SLIDES, "الشرائح", Icons.Default.Slideshow),
                        Triple(StudioTab.TV_STUDIO, "استوديو TV", Icons.Default.LiveTv),
                        Triple(StudioTab.TIMELINE, "المونتاج", Icons.Default.Movie),
                        Triple(StudioTab.AUDIO, "الصوت", Icons.Default.GraphicEq),
                        Triple(StudioTab.EXPORT, "تصدير", Icons.Default.Download)
                    )

                    tabs.forEach { (tab, title, icon) ->
                        val isSelected = selectedTab == tab
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { viewModel.selectTab(tab) },
                            icon = {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = title,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = title,
                                    fontSize = 9.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = StudioNavyDark,
                                selectedTextColor = StudioGold,
                                indicatorColor = StudioBlue,
                                unselectedIconColor = StudioTextMuted,
                                unselectedTextColor = StudioTextMuted
                            )
                        )
                    }
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                Crossfade(targetState = selectedTab, label = "tab_fade") { tab ->
                    when (tab) {
                        StudioTab.PROJECTS -> ProjectsScreen(viewModel)
                        StudioTab.SLIDES -> SlideEditorScreen(viewModel)
                        StudioTab.TV_STUDIO -> TvBroadcastScreen(viewModel)
                        StudioTab.TIMELINE -> VideoTimelineScreen(viewModel)
                        StudioTab.AUDIO -> AudioStudioScreen(viewModel)
                        StudioTab.EXPORT -> ExportScreen(viewModel)
                    }
                }
            }

            if (showAbout) {
                AboutKhaledSootDialog(onDismiss = { viewModel.openAboutDialog(false) })
            }
        }
    }
}
