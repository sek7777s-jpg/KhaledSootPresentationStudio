package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TransitionType
import com.example.ui.components.SlideCanvasView
import com.example.ui.theme.StudioBlue
import com.example.ui.theme.StudioBlueGlow
import com.example.ui.theme.StudioGold
import com.example.ui.theme.StudioGoldLight
import com.example.ui.theme.StudioNavyBorder
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.StudioRed
import com.example.ui.theme.StudioRedDark
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.viewmodel.StudioViewModel

@Composable
fun VideoTimelineScreen(viewModel: StudioViewModel) {
    val project by viewModel.currentProject.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val playbackSlideIdx by viewModel.playbackSlideIndex.collectAsState()
    val elapsedSeconds by viewModel.playbackElapsedSeconds.collectAsState()
    val currentSlideIndex by viewModel.currentSlideIndex.collectAsState()

    // Android 14 compliant Video Picker
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.setSlideVideo(uri.toString())
        }
    }

    if (project == null || project!!.slides.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("الرجاء اختيار مشروع نشط للبدء بالمونتاج والخط الزمني", color = StudioTextMuted)
        }
        return
    }

    val activeProject = project!!
    val totalSeconds = activeProject.slides.sumOf { it.durationSeconds }.coerceAtLeast(1)
    val displayedSlideIdx = if (isPlaying) playbackSlideIdx else currentSlideIndex
    val displayedSlide = activeProject.slides.getOrNull(displayedSlideIdx) ?: activeProject.slides.first()

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Live Video Playback Monitor
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, if (isPlaying) StudioRed else StudioNavyBorder, RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Movie,
                                contentDescription = "Monitor",
                                tint = if (isPlaying) StudioRed else StudioBlue,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isPlaying) "معاينة الفيديو المشغل الآن..." else "شاشة المونتاج والمعاينة",
                                color = StudioGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Timecode Display: 00:04 / 00:18
                        val elapsedInt = elapsedSeconds.toInt()
                        val elapsedStr = String.format("%02d:%02d", elapsedInt / 60, elapsedInt % 60)
                        val totalStr = String.format("%02d:%02d", totalSeconds / 60, totalSeconds % 60)
                        Text(
                            text = "$elapsedStr / $totalStr",
                            color = StudioBlueGlow,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    SlideCanvasView(
                        slide = displayedSlide,
                        broadcastSettings = activeProject.broadcastSettings,
                        aspectRatio = activeProject.aspectRatio,
                        isLiveAnimated = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Scrubber Bar
                    Slider(
                        value = elapsedSeconds.coerceIn(0f, totalSeconds.toFloat()),
                        onValueChange = { viewModel.seekPlaybackTo(it) },
                        valueRange = 0f..totalSeconds.toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = StudioRed,
                            activeTrackColor = StudioRed,
                            inactiveTrackColor = StudioNavyBorder
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Player Controls: Rewind, Play/Pause, Stop
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                val newSec = (elapsedSeconds - 3f).coerceAtLeast(0f)
                                viewModel.seekPlaybackTo(newSec)
                            },
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(StudioNavySurface)
                        ) {
                            Icon(
                                imageVector = Icons.Default.FastRewind,
                                contentDescription = "Rewind",
                                tint = StudioTextPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Button(
                            onClick = { viewModel.togglePlay() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isPlaying) StudioRed else StudioBlue
                            ),
                            shape = CircleShape,
                            modifier = Modifier.size(54.dp)
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play/Pause",
                                tint = if (isPlaying) Color.White else StudioNavyDark,
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        IconButton(
                            onClick = { viewModel.stopPlayback() },
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(StudioNavySurface)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = "Stop",
                                tint = StudioRed,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            // Timeline Header with Video Import Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الخط الزمني للمشاهد (${activeProject.slides.size} مشاهد):",
                    color = StudioTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Video Import Button
                    Button(
                        onClick = {
                            videoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = StudioRed),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VideoFile,
                            contentDescription = "Import Video",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("استيراد فيديو", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    // Add Scene Button
                    Button(
                        onClick = { viewModel.addSlide() },
                        colors = ButtonDefaults.buttonColors(containerColor = StudioNavySurface),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add Scene",
                            tint = StudioBlue,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إضافة مشهد", color = StudioBlue, fontSize = 11.sp)
                    }
                }
            }

            // If active scene has an imported video, show badge & controls
            if (!displayedSlide.videoUri.isNullOrEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = StudioNavySurface),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Videocam,
                                contentDescription = "Video",
                                tint = StudioGold,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "مقطع فيديو B-Roll مدرج في المشهد الحالي",
                                color = StudioGoldLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = { viewModel.removeMediaFromSlide(displayedSlide.videoUri!!) },
                            colors = ButtonDefaults.buttonColors(containerColor = StudioNavyDark),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Remove", tint = StudioRed, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إزالة الفيديو", color = StudioRed, fontSize = 10.sp)
                        }
                    }
                }
            }

            // Horizontal Timeline Reel
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                activeProject.slides.forEachIndexed { index, slide ->
                    val isCurrent = index == currentSlideIndex
                    val isPlayingNow = isPlaying && index == playbackSlideIdx

                    Card(
                        modifier = Modifier
                            .width(160.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(
                                width = if (isPlayingNow) 2.dp else if (isCurrent) 1.5.dp else 1.dp,
                                color = if (isPlayingNow) StudioRed else if (isCurrent) StudioBlue else StudioNavyBorder,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable { viewModel.selectSlide(index) },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isPlayingNow) StudioRedDark.copy(alpha = 0.3f) else StudioNavyCard
                        )
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            // Scene Number & Duration
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "مشهد ${index + 1}",
                                    color = if (isCurrent) StudioGoldLight else StudioTextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(StudioNavyDark)
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "${slide.durationSeconds}ث",
                                        color = StudioBlueGlow,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            // Video or Image Indicator
                            if (!slide.videoUri.isNullOrEmpty()) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(StudioRed.copy(alpha = 0.2f))
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Icon(Icons.Default.Videocam, contentDescription = "Video", tint = StudioRed, modifier = Modifier.size(10.dp))
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text("فيديو B-Roll", color = StudioRed, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                            }

                            Text(
                                text = slide.title.ifEmpty { "شريحة بدون عنوان" },
                                color = StudioTextSecondary,
                                fontSize = 10.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            // Transition badge
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(StudioNavySurface)
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = "Trans",
                                    tint = StudioGold,
                                    modifier = Modifier.size(10.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = slide.transition.titleAr,
                                    color = StudioTextMuted,
                                    fontSize = 9.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Reordering & Duration Quick Controls
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(
                                    onClick = { if (index > 0) viewModel.moveSlide(index, index - 1) },
                                    enabled = index > 0,
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                        contentDescription = "Move Left",
                                        tint = if (index > 0) StudioBlue else StudioTextMuted,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "+",
                                        color = StudioGold,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        modifier = Modifier
                                            .clickable {
                                                viewModel.updateCurrentSlide(slide.copy(durationSeconds = slide.durationSeconds + 1))
                                            }
                                            .padding(horizontal = 4.dp)
                                    )
                                    Text(
                                        text = "-",
                                        color = StudioGold,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        modifier = Modifier
                                            .clickable {
                                                if (slide.durationSeconds > 2) {
                                                    viewModel.updateCurrentSlide(slide.copy(durationSeconds = slide.durationSeconds - 1))
                                                }
                                            }
                                            .padding(horizontal = 4.dp)
                                    )
                                }

                                IconButton(
                                    onClick = { if (index < activeProject.slides.size - 1) viewModel.moveSlide(index, index + 1) },
                                    enabled = index < activeProject.slides.size - 1,
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                        contentDescription = "Move Right",
                                        tint = if (index < activeProject.slides.size - 1) StudioBlue else StudioTextMuted,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Transition Preset Selector for Current Scene
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "مؤثر الانتقال للمشهد المحدد (مشهد ${currentSlideIndex + 1}):",
                        color = StudioGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        TransitionType.values().forEach { trans ->
                            val isChosen = displayedSlide.transition == trans
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isChosen) StudioNavySurface else StudioNavyDark)
                                    .border(
                                        1.dp,
                                        if (isChosen) StudioBlue else StudioNavyBorder,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .clickable {
                                        viewModel.updateCurrentSlide(displayedSlide.copy(transition = trans))
                                    }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = trans.titleAr,
                                    color = if (isChosen) StudioBlueGlow else StudioTextMuted,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(70.dp))
        }
    }
}
