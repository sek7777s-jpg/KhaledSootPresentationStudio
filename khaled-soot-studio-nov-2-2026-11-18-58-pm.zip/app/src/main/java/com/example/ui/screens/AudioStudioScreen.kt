package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.theme.StudioBlue
import com.example.ui.theme.StudioBlueGlow
import com.example.ui.theme.StudioGold
import com.example.ui.theme.StudioGoldLight
import com.example.ui.theme.StudioNavyBorder
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.StudioRed
import com.example.ui.theme.StudioRedDark
import com.example.ui.theme.StudioRedGlow
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.viewmodel.StudioViewModel

@Composable
fun AudioStudioScreen(viewModel: StudioViewModel) {
    val context = LocalContext.current
    val project by viewModel.currentProject.collectAsState()
    val audioManager = viewModel.audioManager

    val isRecording by audioManager.isRecording.collectAsState()
    val recDuration by audioManager.recordingDurationSec.collectAsState()
    val amplitude by audioManager.amplitude.collectAsState()
    val isPlayingVoice by audioManager.isPlayingVoicePreview.collectAsState()
    val isPlayingCustom by audioManager.isPlayingCustomPreview.collectAsState()
    val playbackProgressSec by audioManager.playbackProgressSec.collectAsState()
    val currentlyPlayingFxId by viewModel.currentlyPlayingFxId.collectAsState()

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasMicPermission = isGranted
        if (isGranted) {
            val path = audioManager.startRecording()
            if (path != null && project != null) {
                viewModel.updateAudioConfig(project!!.audioConfig.copy(voiceoverPath = path))
            }
        }
    }

    // Audio File Picker (MP3 / WAV)
    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.importAudioFile(uri)
        }
    }

    if (project == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("الرجاء اختيار مشروع للبدء بالهندسة الصوتية", color = StudioTextMuted)
        }
        return
    }

    val activeProject = project!!
    val audioConfig = activeProject.audioConfig

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Info
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavySurface),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = "Audio Studio",
                        tint = StudioGold,
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "استوديو هندسة الصوت والمؤثرات التلفزيونية 2.0",
                            color = StudioTextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "تسجيل حي + استيراد MP3/WAV + مكتبة مؤثرات أصلية + خفض ذكي (Ducking)",
                            color = StudioBlueGlow,
                            fontSize = 10.5.sp
                        )
                    }
                }
            }

            // SECTION 1: VOICE RECORDING
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, if (isRecording) StudioRed else StudioNavyBorder, RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.RecordVoiceOver,
                                contentDescription = "Voice",
                                tint = StudioRed,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "مسار التعليق الصوتي الحي (Voiceover):",
                                color = StudioTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (isRecording) {
                            Text(
                                text = "● جاري التسجيل المباشر",
                                color = StudioRedGlow,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Record Button
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(if (isRecording) StudioRed else StudioNavySurface)
                            .border(2.dp, if (isRecording) StudioGold else StudioBlue, CircleShape)
                            .clickable {
                                if (isRecording) {
                                    val savedPath = audioManager.stopRecording()
                                    if (savedPath != null) {
                                        viewModel.updateAudioConfig(audioConfig.copy(voiceoverPath = savedPath))
                                    }
                                } else {
                                    if (hasMicPermission) {
                                        val path = audioManager.startRecording()
                                        if (path != null) {
                                            viewModel.updateAudioConfig(audioConfig.copy(voiceoverPath = path))
                                        }
                                    } else {
                                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isRecording) Icons.Default.Stop else Icons.Default.Mic,
                            contentDescription = "Mic Record",
                            tint = if (isRecording) Color.White else StudioBlue,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val recMin = recDuration / 60
                    val recSec = recDuration % 60
                    Text(
                        text = String.format("%02d:%02d", recMin, recSec),
                        color = if (isRecording) StudioRedGlow else StudioTextPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Waveform visualizer bars
                    Row(
                        modifier = Modifier
                            .fillMaxWidth(0.7f)
                            .height(22.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (i in 0 until 12) {
                            val barHeight = if (isRecording) {
                                val dynamicFactor = (amplitude * (15 + (i % 5) * 6)).coerceIn(4f, 22f)
                                dynamicFactor.dp
                            } else {
                                4.dp
                            }
                            Box(
                                modifier = Modifier
                                    .width(4.dp)
                                    .height(barHeight)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(if (isRecording) StudioGold else StudioNavyBorder)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (!audioConfig.voiceoverPath.isNullOrEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(StudioNavySurface)
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("تم حفظ التعليق الصوتي للمشروع بنجاح", color = StudioGoldLight, fontSize = 11.sp)
                            Button(
                                onClick = {
                                    if (isPlayingVoice) {
                                        audioManager.stopPlayback()
                                    } else {
                                        audioManager.playVoiceover(audioConfig.voiceoverPath, audioConfig.voiceVolume)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = StudioBlue),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Icon(
                                    imageVector = if (isPlayingVoice) Icons.Default.Stop else Icons.Default.PlayArrow,
                                    contentDescription = "Play",
                                    tint = StudioNavyDark,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isPlayingVoice) "إيقاف" else "استماع",
                                    color = StudioNavyDark,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // SECTION 2: IMPORT AUDIO FILES (MP3, WAV)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AudioFile,
                                contentDescription = "Audio File",
                                tint = StudioBlue,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "استيراد ملف صوتي خارجي (MP3 / WAV):",
                                color = StudioTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = { audioPickerLauncher.launch("audio/*") },
                            colors = ButtonDefaults.buttonColors(containerColor = StudioBlue),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Icon(Icons.Default.UploadFile, contentDescription = "Import", tint = StudioNavyDark, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("استيراد ملف", color = StudioNavyDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (!audioConfig.customAudioPath.isNullOrEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(StudioNavySurface)
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = audioConfig.customAudioName ?: "ملف صوتي مستورد",
                                    color = StudioGoldLight,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text("تم ربط الملف مع المشروع كمسار صوتي رئيسي", color = StudioTextMuted, fontSize = 9.sp)
                            }

                            Button(
                                onClick = {
                                    if (isPlayingCustom) {
                                        audioManager.stopPlayback()
                                    } else {
                                        audioManager.playCustomAudio(audioConfig.customAudioPath, audioConfig.musicVolume)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = StudioGold),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Icon(
                                    imageVector = if (isPlayingCustom) Icons.Default.Stop else Icons.Default.PlayArrow,
                                    contentDescription = "Play",
                                    tint = StudioNavyDark,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (isPlayingCustom) "إيقاف" else "تشغيل", color = StudioNavyDark, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        Text(
                            text = "يمكنك استيراد أي تسجيل أو تعليق أو أنشودة أو مقطوعة MP3 أو WAV محفوظة على هاتفك.",
                            color = StudioTextMuted,
                            fontSize = 10.5.sp
                        )
                    }
                }
            }

            // SECTION 3: BUILT-IN ORIGINAL SOUND EFFECTS LIBRARY
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "FX",
                                tint = StudioGold,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "مكتبة المؤثرات الصوتية الأصلية المدمجة (7 مؤثرات):",
                                color = StudioGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    viewModel.availableSoundEffects.forEach { sfx ->
                        val isPlaying = currentlyPlayingFxId == sfx.id
                        val isSelected = audioConfig.selectedSoundFxId == sfx.id

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) StudioNavySurface else StudioNavyDark)
                                .border(
                                    1.dp,
                                    if (isSelected) StudioGold else StudioNavyBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    viewModel.selectSoundEffectForProject(sfx.id)
                                }
                                .padding(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = sfx.titleAr,
                                            color = if (isSelected) StudioGoldLight else StudioTextPrimary,
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(StudioNavyDark)
                                                .padding(horizontal = 4.dp, vertical = 1.dp)
                                        ) {
                                            Text(
                                                text = "${sfx.durationSeconds}ث",
                                                color = StudioBlueGlow,
                                                fontSize = 9.sp
                                            )
                                        }
                                    }
                                    Text(
                                        text = sfx.descriptionAr,
                                        color = StudioTextMuted,
                                        fontSize = 9.5.sp,
                                        maxLines = 1
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    // Play / Stop FX Preview
                                    IconButton(
                                        onClick = {
                                            if (isPlaying) {
                                                viewModel.stopSoundEffect()
                                            } else {
                                                viewModel.playSoundEffect(sfx.id, audioConfig.soundFxVolume)
                                            }
                                        },
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(CircleShape)
                                            .background(if (isPlaying) StudioRed else StudioNavySurface)
                                    ) {
                                        Icon(
                                            imageVector = if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                                            contentDescription = "Play FX",
                                            tint = if (isPlaying) Color.White else StudioGold,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // SECTION 4: MULTI-TRACK AUDIO MIXER & TIMING
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "ميكسر التحكم بمستويات الصوت المتعددة:",
                        color = StudioTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )

                    // Track 1: Voice Volume
                    Column {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("1. مستوى صوت التعليق (Voice):", color = StudioTextSecondary, fontSize = 11.sp)
                            Text("${(audioConfig.voiceVolume * 100).toInt()}%", color = StudioBlueGlow, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = audioConfig.voiceVolume,
                            onValueChange = { viewModel.updateAudioConfig(audioConfig.copy(voiceVolume = it)) },
                            colors = SliderDefaults.colors(thumbColor = StudioBlue, activeTrackColor = StudioBlue)
                        )
                    }

                    // Track 2: Music Volume
                    Column {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("2. مستوى الموسيقى التصويرية (Music):", color = StudioTextSecondary, fontSize = 11.sp)
                            Text("${(audioConfig.musicVolume * 100).toInt()}%", color = StudioGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = audioConfig.musicVolume,
                            onValueChange = {
                                viewModel.updateAudioConfig(audioConfig.copy(musicVolume = it))
                                audioManager.setMusicVolume(it)
                            },
                            colors = SliderDefaults.colors(thumbColor = StudioGold, activeTrackColor = StudioGold)
                        )
                    }

                    // Track 3: Sound FX Volume
                    Column {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("3. مستوى المؤثرات التلفزيونية (Sound FX):", color = StudioTextSecondary, fontSize = 11.sp)
                            Text("${(audioConfig.soundFxVolume * 100).toInt()}%", color = StudioRedGlow, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = audioConfig.soundFxVolume,
                            onValueChange = { viewModel.updateAudioConfig(audioConfig.copy(soundFxVolume = it)) },
                            colors = SliderDefaults.colors(thumbColor = StudioRed, activeTrackColor = StudioRed)
                        )
                    }

                    // Audio Start Offset on Timeline
                    Column {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("بداية انطلاق الصوت على الخط الزمني:", color = StudioTextSecondary, fontSize = 11.sp)
                            Text("${String.format("%.1f", audioConfig.audioOffsetSec)} ثانية", color = StudioBlueGlow, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = audioConfig.audioOffsetSec,
                            onValueChange = { viewModel.updateAudioConfig(audioConfig.copy(audioOffsetSec = it)) },
                            valueRange = 0f..10f,
                            colors = SliderDefaults.colors(thumbColor = StudioBlue, activeTrackColor = StudioBlue)
                        )
                    }
                }
            }

            // SECTION 5: SMART DUCKING
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "خفض الموسيقى تلقائياً (Smart Audio Ducking)",
                            color = StudioTextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "يقوم النظام بخفض صوت الموسيقى والمؤثرات تلقائياً أثناء وجود التعليق الصوتي لضمان أقصى درجات الوضوح الإذاعي.",
                            color = StudioTextMuted,
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )
                    }

                    Switch(
                        checked = audioConfig.autoDucking,
                        onCheckedChange = { viewModel.updateAudioConfig(audioConfig.copy(autoDucking = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = StudioBlue, checkedTrackColor = StudioNavySurface)
                    )
                }
            }

            Spacer(modifier = Modifier.height(70.dp))
        }
    }
}
