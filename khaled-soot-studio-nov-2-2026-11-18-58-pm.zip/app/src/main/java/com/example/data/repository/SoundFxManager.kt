package com.example.data.repository

import android.content.Context
import android.media.MediaPlayer
import com.example.data.model.SoundEffectItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

class SoundFxManager(
    private val context: Context? = null,
    private val customBaseDir: File? = null
) {
    constructor(context: Context) : this(context, null)
    constructor(customBaseDir: File) : this(null, customBaseDir)

    private val fxDir = File(customBaseDir ?: context?.filesDir ?: File(System.getProperty("java.io.tmpdir") ?: "."), "sound_fx")
    private var mediaPlayer: MediaPlayer? = null

    private val _currentlyPlayingId = MutableStateFlow<String?>(null)
    val currentlyPlayingId: StateFlow<String?> = _currentlyPlayingId.asStateFlow()

    val availableEffects = listOf(
        SoundEffectItem(
            id = "fx_breaking_news",
            titleAr = "مقدمة أخبار عاجلة",
            categoryAr = "عواجل وشارات",
            fileName = "fx_breaking_news.wav",
            durationSeconds = 3.2f,
            descriptionAr = "ضربات نحاسية درامية قوية مخصصة للأخبار العاجلة والحدث الساخن"
        ),
        SoundEffectItem(
            id = "fx_news_intro",
            titleAr = "مقدمة نشرة إخبارية احترافية",
            categoryAr = "مقدمات النشرات",
            fileName = "fx_news_intro.wav",
            durationSeconds = 4.0f,
            descriptionAr = "افتتاحية كلاسيكية متوازنة لنشرات الأخبار والتقارير الرئيسية"
        ),
        SoundEffectItem(
            id = "fx_news_transition",
            titleAr = "مؤثر انتقال إخباري سريع",
            categoryAr = "انتقالات بصرية",
            fileName = "fx_news_transition.wav",
            durationSeconds = 1.6f,
            descriptionAr = "صوت مسح وانتقال تلفزيوني هوائي بين مشاهد التقرير"
        ),
        SoundEffectItem(
            id = "fx_documentary_ambient",
            titleAr = "موسيقى وثائقية هادئة",
            categoryAr = "وثائقي وسرد",
            fileName = "fx_documentary_ambient.wav",
            durationSeconds = 5.0f,
            descriptionAr = "نغمات وترية تأملية دافئة لمشاهد التاريخ والحضارة والقصص"
        ),
        SoundEffectItem(
            id = "fx_investigative_tension",
            titleAr = "موسيقى تحقيقات وتشويق",
            categoryAr = "تحقيقات استقصائية",
            fileName = "fx_investigative_tension.wav",
            durationSeconds = 4.5f,
            descriptionAr = "نبض درامي منخفض ومؤثرات ترقب لكشف الحقائق والأرقام الحساسة"
        ),
        SoundEffectItem(
            id = "fx_field_report_beeps",
            titleAr = "مؤثرات التقرير الميداني",
            categoryAr = "تقارير ميدانية",
            fileName = "fx_field_report_beeps.wav",
            durationSeconds = 3.0f,
            descriptionAr = "إشارات اتصال فضائي وأصوات أجهزة البث الميداني الحي"
        ),
        SoundEffectItem(
            id = "fx_outro_chime",
            titleAr = "شارة ختامية للتقرير",
            categoryAr = "خواتيم وشارات",
            fileName = "fx_outro_chime.wav",
            durationSeconds = 2.8f,
            descriptionAr = "رنين إخباري نقي وأنيق لإغلاق التقرير وتقديم شارة النهاية"
        )
    )

    suspend fun initialize() = withContext(Dispatchers.IO) {
        if (!fxDir.exists()) fxDir.mkdirs()
        for (item in availableEffects) {
            val file = File(fxDir, item.fileName)
            if (!file.exists() || file.length() < 1000) {
                generateWavFile(item, file)
            }
        }
    }

    fun getSoundEffectFile(id: String): File? {
        val item = availableEffects.find { it.id == id } ?: return null
        val file = File(fxDir, item.fileName)
        return if (file.exists()) file else null
    }

    fun playSoundEffect(id: String, volume: Float = 0.8f, onFinished: () -> Unit = {}) {
        stopSoundEffect()
        val file = getSoundEffectFile(id) ?: return
        try {
            mediaPlayer = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setVolume(volume.coerceIn(0f, 1f), volume.coerceIn(0f, 1f))
                prepare()
                setOnCompletionListener {
                    _currentlyPlayingId.value = null
                    onFinished()
                }
                start()
            }
            _currentlyPlayingId.value = id
        } catch (e: Exception) {
            e.printStackTrace()
            _currentlyPlayingId.value = null
        }
    }

    fun stopSoundEffect() {
        try {
            mediaPlayer?.apply {
                if (isPlaying) stop()
                release()
            }
        } catch (_: Exception) {}
        mediaPlayer = null
        _currentlyPlayingId.value = null
    }

    private fun generateWavFile(item: SoundEffectItem, targetFile: File) {
        val sampleRate = 44100
        val totalSamples = (sampleRate * item.durationSeconds).toInt()
        val samples = ShortArray(totalSamples)

        when (item.id) {
            "fx_breaking_news" -> {
                // Triple dramatic orchestral hits (G3 -> Bb3 -> D4 -> Eb4)
                for (i in 0 until totalSamples) {
                    val t = i.toDouble() / sampleRate
                    val envelope = when {
                        t < 0.6 -> exp(-5.0 * t)
                        t < 1.4 -> exp(-4.0 * (t - 0.7))
                        else -> exp(-2.5 * (t - 1.5))
                    }
                    val f1 = if (t < 0.7) 196.0 else if (t < 1.5) 233.08 else 311.13
                    val f2 = f1 * 1.5
                    val f3 = f1 * 2.0
                    val sig = (sin(2 * PI * f1 * t) * 0.5 + sin(2 * PI * f2 * t) * 0.3 + sin(2 * PI * f3 * t) * 0.2) * envelope
                    samples[i] = (sig * 28000).toInt().coerceIn(-32767, 32767).toShort()
                }
            }
            "fx_news_intro" -> {
                // Professional fanfare chord progression
                val notes = listOf(261.63, 329.63, 392.0, 523.25) // C major fanfare
                for (i in 0 until totalSamples) {
                    val t = i.toDouble() / sampleRate
                    val chordIdx = ((t / item.durationSeconds) * notes.size).toInt().coerceIn(0, notes.lastIndex)
                    val freq = notes[chordIdx]
                    val envelope = (1.0 - (t / item.durationSeconds)).coerceIn(0.0, 1.0)
                    val pulse = if ((t * 4.0).toInt() % 2 == 0) 1.0 else 0.7
                    val sig = (sin(2 * PI * freq * t) * 0.6 + sin(2 * PI * (freq * 1.5) * t) * 0.25) * envelope * pulse
                    samples[i] = (sig * 26000).toInt().coerceIn(-32767, 32767).toShort()
                }
            }
            "fx_news_transition" -> {
                // Frequency sweep swoosh (100Hz -> 1800Hz -> 150Hz)
                for (i in 0 until totalSamples) {
                    val t = i.toDouble() / sampleRate
                    val normT = t / item.durationSeconds
                    val freq = 120.0 + 1600.0 * sin(PI * normT)
                    val envelope = sin(PI * normT)
                    val noise = (Math.random() * 2.0 - 1.0) * 0.25
                    val sig = (sin(2 * PI * freq * t) * 0.75 + noise) * envelope
                    samples[i] = (sig * 26000).toInt().coerceIn(-32767, 32767).toShort()
                }
            }
            "fx_documentary_ambient" -> {
                // Warm ambient pad (D minor / F major swell)
                for (i in 0 until totalSamples) {
                    val t = i.toDouble() / sampleRate
                    val envelope = sin(PI * (t / item.durationSeconds))
                    val sig = (sin(2 * PI * 146.83 * t) * 0.4 +
                            sin(2 * PI * 220.0 * t) * 0.3 +
                            sin(2 * PI * 261.63 * t) * 0.2 +
                            sin(2 * PI * 349.23 * t) * 0.1) * envelope
                    samples[i] = (sig * 24000).toInt().coerceIn(-32767, 32767).toShort()
                }
            }
            "fx_investigative_tension" -> {
                // Low tension pulse with clock tick
                for (i in 0 until totalSamples) {
                    val t = i.toDouble() / sampleRate
                    val drone = sin(2 * PI * 65.41 * t) * 0.6 + sin(2 * PI * 98.0 * t) * 0.25
                    val tickPhase = (t * 2.0) % 1.0
                    val tick = if (tickPhase < 0.05) sin(2 * PI * 2400.0 * tickPhase) * exp(-60.0 * tickPhase) else 0.0
                    val sig = (drone + tick * 0.4) * (1.0 - (t / item.durationSeconds) * 0.3)
                    samples[i] = (sig * 25000).toInt().coerceIn(-32767, 32767).toShort()
                }
            }
            "fx_field_report_beeps" -> {
                // Radio telemetry beeps
                for (i in 0 until totalSamples) {
                    val t = i.toDouble() / sampleRate
                    val beepInterval = (t * 3.5) % 1.0
                    val beep = if (beepInterval < 0.15) sin(2 * PI * 1800.0 * t) else 0.0
                    val bgHiss = (Math.random() * 2.0 - 1.0) * 0.08
                    val sig = beep * 0.8 + bgHiss
                    samples[i] = (sig * 22000).toInt().coerceIn(-32767, 32767).toShort()
                }
            }
            "fx_outro_chime" -> {
                // Clear high broadcast chimes (E5, B5, G#5)
                for (i in 0 until totalSamples) {
                    val t = i.toDouble() / sampleRate
                    val envelope = exp(-1.8 * t)
                    val sig = (sin(2 * PI * 659.25 * t) * 0.5 +
                            sin(2 * PI * 987.77 * t) * 0.3 +
                            sin(2 * PI * 830.61 * t) * 0.2) * envelope
                    samples[i] = (sig * 26000).toInt().coerceIn(-32767, 32767).toShort()
                }
            }
        }

        writeWavHeaderAndData(targetFile, samples, sampleRate)
    }

    private fun writeWavHeaderAndData(file: File, samples: ShortArray, sampleRate: Int) {
        val numChannels = 1
        val bitsPerSample = 16
        val dataSize = samples.size * 2
        val totalSize = 36 + dataSize

        FileOutputStream(file).use { out ->
            val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
                put("RIFF".toByteArray())
                putInt(totalSize)
                put("WAVE".toByteArray())
                put("fmt ".toByteArray())
                putInt(16) // Subchunk1Size
                putShort(1) // PCM format
                putShort(numChannels.toShort())
                putInt(sampleRate)
                putInt(sampleRate * numChannels * (bitsPerSample / 8)) // ByteRate
                putShort((numChannels * (bitsPerSample / 8)).toShort()) // BlockAlign
                putShort(bitsPerSample.toShort())
                put("data".toByteArray())
                putInt(dataSize)
            }
            out.write(header.array())

            val sampleBytes = ByteBuffer.allocate(dataSize).order(ByteOrder.LITTLE_ENDIAN)
            for (s in samples) {
                sampleBytes.putShort(s)
            }
            out.write(sampleBytes.array())
        }
    }
}
