package com.example.data.repository

import android.content.Context
import com.example.data.model.AspectRatio
import com.example.data.model.AudioConfig
import com.example.data.model.BroadcastSettings
import com.example.data.model.Project
import com.example.data.model.Slide
import com.example.data.model.StudioFontFamily
import com.example.data.model.TemplateCategory
import com.example.data.model.TextStyleConfig
import com.example.data.model.TransitionType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class ProjectRepository(private val context: Context) {

    private val storageFile = File(context.filesDir, "khaled_soot_projects.json")
    private val _projects = MutableStateFlow<List<Project>>(emptyList())
    val projects: StateFlow<List<Project>> = _projects.asStateFlow()

    suspend fun initialize() {
        withContext(Dispatchers.IO) {
            val list = loadFromDisk()
            if (list.isEmpty()) {
                val samples = createSampleProjects()
                saveToDisk(samples)
                _projects.value = samples
            } else {
                _projects.value = list
            }
        }
    }

    suspend fun saveProject(project: Project) {
        withContext(Dispatchers.IO) {
            val currentList = _projects.value.toMutableList()
            val index = currentList.indexOfFirst { it.id == project.id }
            val updatedProject = project.copy(updatedAt = System.currentTimeMillis())
            if (index >= 0) {
                currentList[index] = updatedProject
            } else {
                currentList.add(0, updatedProject)
            }
            saveToDisk(currentList)
            _projects.value = currentList
        }
    }

    suspend fun deleteProject(projectId: String) {
        withContext(Dispatchers.IO) {
            val currentList = _projects.value.filter { it.id != projectId }
            saveToDisk(currentList)
            _projects.value = currentList
        }
    }

    suspend fun duplicateProject(source: Project): Project {
        return withContext(Dispatchers.IO) {
            val duplicated = source.copy(
                id = UUID.randomUUID().toString(),
                title = "${source.title} (نسخة 2.0)",
                slides = source.slides.map { it.copy(id = UUID.randomUUID().toString()) },
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            saveProject(duplicated)
            duplicated
        }
    }

    fun getProjectById(id: String): Project? {
        return _projects.value.firstOrNull { it.id == id }
    }

    private fun loadFromDisk(): List<Project> {
        return try {
            if (!storageFile.exists()) return emptyList()
            val text = storageFile.readText()
            if (text.isBlank()) return emptyList()
            val jsonArray = JSONArray(text)
            val list = mutableListOf<Project>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(deserializeProject(obj))
            }
            list
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    private fun saveToDisk(list: List<Project>) {
        try {
            val jsonArray = JSONArray()
            for (p in list) {
                jsonArray.put(serializeProject(p))
            }
            storageFile.writeText(jsonArray.toString(2))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun serializeProject(p: Project): JSONObject {
        val root = JSONObject()
        root.put("id", p.id)
        root.put("title", p.title)
        root.put("description", p.description)
        root.put("aspectRatio", p.aspectRatio.name)
        root.put("createdAt", p.createdAt)
        root.put("updatedAt", p.updatedAt)

        // BroadcastSettings
        val bs = JSONObject()
        bs.put("channelLogoText", p.broadcastSettings.channelLogoText)
        bs.put("channelSubText", p.broadcastSettings.channelSubText)
        bs.put("tickerText", p.broadcastSettings.tickerText)
        bs.put("showTicker", p.broadcastSettings.showTicker)
        bs.put("tickerSpeed", p.broadcastSettings.tickerSpeed.toDouble())
        bs.put("studioLocation", p.broadcastSettings.studioLocation)
        bs.put("presenterName", p.broadcastSettings.presenterName)
        bs.put("tickerTextColorHex", p.broadcastSettings.tickerTextColorHex)
        bs.put("tickerFontSizeSp", p.broadcastSettings.tickerFontSizeSp)
        bs.put("tickerFontFamilyId", p.broadcastSettings.tickerFontFamilyId)
        root.put("broadcastSettings", bs)

        // AudioConfig
        val ac = JSONObject()
        ac.put("voiceoverPath", p.audioConfig.voiceoverPath ?: "")
        ac.put("voiceoverDurationMs", p.audioConfig.voiceoverDurationMs)
        ac.put("selectedMusicPreset", p.audioConfig.selectedMusicPreset)
        ac.put("customAudioPath", p.audioConfig.customAudioPath ?: "")
        ac.put("customAudioName", p.audioConfig.customAudioName ?: "")
        ac.put("voiceVolume", p.audioConfig.voiceVolume.toDouble())
        ac.put("musicVolume", p.audioConfig.musicVolume.toDouble())
        ac.put("soundFxVolume", p.audioConfig.soundFxVolume.toDouble())
        ac.put("selectedSoundFxId", p.audioConfig.selectedSoundFxId ?: "")
        ac.put("audioOffsetSec", p.audioConfig.audioOffsetSec.toDouble())
        ac.put("autoDucking", p.audioConfig.autoDucking)
        root.put("audioConfig", ac)

        // Slides
        val slidesArray = JSONArray()
        for (s in p.slides) {
            val so = JSONObject()
            so.put("id", s.id)
            so.put("title", s.title)
            so.put("subtitle", s.subtitle)
            so.put("bodyText", s.bodyText)
            val bp = JSONArray()
            s.bulletPoints.forEach { bp.put(it) }
            so.put("bulletPoints", bp)
            so.put("templateCategory", s.templateCategory.name)
            so.put("bgPresetIndex", s.bgPresetIndex)
            so.put("imageUri", s.imageUri ?: "")
            so.put("videoUri", s.videoUri ?: "")
            val mediaArr = JSONArray()
            s.mediaList.forEach { mediaArr.put(it) }
            so.put("mediaList", mediaArr)
            so.put("imagePosition", s.imagePosition)
            so.put("durationSeconds", s.durationSeconds)
            so.put("transition", s.transition.name)
            so.put("lowerThirdName", s.lowerThirdName)
            so.put("lowerThirdRole", s.lowerThirdRole)
            so.put("showLowerThird", s.showLowerThird)
            so.put("showLiveBadge", s.showLiveBadge)
            so.put("breakingNewsText", s.breakingNewsText)
            so.put("showBreakingBanner", s.showBreakingBanner)
            so.put("statValue", s.statValue)
            so.put("statLabel", s.statLabel)
            so.put("showStatCard", s.showStatCard)

            // TextStyleConfig
            val ts = JSONObject()
            ts.put("fontFamilyId", s.textStyle.fontFamilyId)
            ts.put("titleFontSizeSp", s.textStyle.titleFontSizeSp)
            ts.put("subtitleFontSizeSp", s.textStyle.subtitleFontSizeSp)
            ts.put("bodyFontSizeSp", s.textStyle.bodyFontSizeSp)
            ts.put("isBold", s.textStyle.isBold)
            ts.put("textColorHex", s.textStyle.textColorHex)
            ts.put("accentColorHex", s.textStyle.accentColorHex)
            ts.put("textAlignment", s.textStyle.textAlignment)
            so.put("textStyle", ts)

            slidesArray.put(so)
        }
        root.put("slides", slidesArray)
        return root
    }

    private fun deserializeProject(root: JSONObject): Project {
        val id = root.optString("id", UUID.randomUUID().toString())
        val title = root.optString("title", "مشروع جديد")
        val description = root.optString("description", "")
        val aspectRatio = try {
            AspectRatio.valueOf(root.optString("aspectRatio", AspectRatio.RATIO_16_9.name))
        } catch (_: Exception) {
            AspectRatio.RATIO_16_9
        }
        val createdAt = root.optLong("createdAt", System.currentTimeMillis())
        val updatedAt = root.optLong("updatedAt", System.currentTimeMillis())

        val bsObj = root.optJSONObject("broadcastSettings")
        val broadcastSettings = if (bsObj != null) {
            BroadcastSettings(
                channelLogoText = bsObj.optString("channelLogoText", "KHALED SOOT TV"),
                channelSubText = bsObj.optString("channelSubText", "صوت الخبر والتحليل"),
                tickerText = bsObj.optString("tickerText", "استوديو خالد صوت 2.0: التغطية مستمرة..."),
                showTicker = bsObj.optBoolean("showTicker", true),
                tickerSpeed = bsObj.optDouble("tickerSpeed", 1.0).toFloat(),
                studioLocation = bsObj.optString("studioLocation", "الرياض - الاستوديو الرئيسي"),
                presenterName = bsObj.optString("presenterName", "خالد صوت"),
                tickerTextColorHex = bsObj.optString("tickerTextColorHex", "#F8F9FA"),
                tickerFontSizeSp = bsObj.optInt("tickerFontSizeSp", 10),
                tickerFontFamilyId = bsObj.optString("tickerFontFamilyId", StudioFontFamily.SANS_SERIF.id)
            )
        } else BroadcastSettings()

        val acObj = root.optJSONObject("audioConfig")
        val audioConfig = if (acObj != null) {
            val vPath = acObj.optString("voiceoverPath", "")
            val cPath = acObj.optString("customAudioPath", "")
            val cName = acObj.optString("customAudioName", "")
            val sFxId = acObj.optString("selectedSoundFxId", "fx_breaking_news")
            AudioConfig(
                voiceoverPath = if (vPath.isNotEmpty()) vPath else null,
                voiceoverDurationMs = acObj.optLong("voiceoverDurationMs", 0L),
                selectedMusicPreset = acObj.optString("selectedMusicPreset", "BREAKING_NEWS"),
                customAudioPath = if (cPath.isNotEmpty()) cPath else null,
                customAudioName = if (cName.isNotEmpty()) cName else null,
                voiceVolume = acObj.optDouble("voiceVolume", 1.0).toFloat(),
                musicVolume = acObj.optDouble("musicVolume", 0.45).toFloat(),
                soundFxVolume = acObj.optDouble("soundFxVolume", 0.8).toFloat(),
                selectedSoundFxId = if (sFxId.isNotEmpty()) sFxId else null,
                audioOffsetSec = acObj.optDouble("audioOffsetSec", 0.0).toFloat(),
                autoDucking = acObj.optBoolean("autoDucking", true)
            )
        } else AudioConfig()

        val slides = mutableListOf<Slide>()
        val slidesArray = root.optJSONArray("slides")
        if (slidesArray != null) {
            for (i in 0 until slidesArray.length()) {
                val so = slidesArray.getJSONObject(i)
                val bpList = mutableListOf<String>()
                val bpArray = so.optJSONArray("bulletPoints")
                if (bpArray != null) {
                    for (j in 0 until bpArray.length()) {
                        bpList.add(bpArray.getString(j))
                    }
                }

                val mediaList = mutableListOf<String>()
                val mediaArray = so.optJSONArray("mediaList")
                if (mediaArray != null) {
                    for (j in 0 until mediaArray.length()) {
                        mediaList.add(mediaArray.getString(j))
                    }
                }

                val cat = try {
                    TemplateCategory.valueOf(so.optString("templateCategory", TemplateCategory.TV_NEWS.name))
                } catch (_: Exception) {
                    TemplateCategory.TV_NEWS
                }
                val trans = try {
                    TransitionType.valueOf(so.optString("transition", TransitionType.FADE.name))
                } catch (_: Exception) {
                    TransitionType.FADE
                }
                val imgUri = so.optString("imageUri", "")
                val vidUri = so.optString("videoUri", "")

                val tsObj = so.optJSONObject("textStyle")
                val textStyle = if (tsObj != null) {
                    TextStyleConfig(
                        fontFamilyId = tsObj.optString("fontFamilyId", StudioFontFamily.SANS_SERIF.id),
                        titleFontSizeSp = tsObj.optInt("titleFontSizeSp", 18),
                        subtitleFontSizeSp = tsObj.optInt("subtitleFontSizeSp", 12),
                        bodyFontSizeSp = tsObj.optInt("bodyFontSizeSp", 11),
                        isBold = tsObj.optBoolean("isBold", true),
                        textColorHex = tsObj.optString("textColorHex", "#F8F9FA"),
                        accentColorHex = tsObj.optString("accentColorHex", "#00B4D8"),
                        textAlignment = tsObj.optString("textAlignment", "RIGHT")
                    )
                } else TextStyleConfig()

                slides.add(
                    Slide(
                        id = so.optString("id", UUID.randomUUID().toString()),
                        title = so.optString("title", ""),
                        subtitle = so.optString("subtitle", ""),
                        bodyText = so.optString("bodyText", ""),
                        bulletPoints = bpList,
                        templateCategory = cat,
                        bgPresetIndex = so.optInt("bgPresetIndex", 0),
                        imageUri = if (imgUri.isNotEmpty()) imgUri else null,
                        videoUri = if (vidUri.isNotEmpty()) vidUri else null,
                        mediaList = mediaList,
                        imagePosition = so.optString("imagePosition", "SPLIT"),
                        durationSeconds = so.optInt("durationSeconds", 5),
                        transition = trans,
                        lowerThirdName = so.optString("lowerThirdName", ""),
                        lowerThirdRole = so.optString("lowerThirdRole", ""),
                        showLowerThird = so.optBoolean("showLowerThird", false),
                        showLiveBadge = so.optBoolean("showLiveBadge", true),
                        breakingNewsText = so.optString("breakingNewsText", ""),
                        showBreakingBanner = so.optBoolean("showBreakingBanner", false),
                        statValue = so.optString("statValue", ""),
                        statLabel = so.optString("statLabel", ""),
                        showStatCard = so.optBoolean("showStatCard", false),
                        textStyle = textStyle
                    )
                )
            }
        }

        return Project(
            id = id,
            title = title,
            description = description,
            aspectRatio = aspectRatio,
            slides = slides,
            broadcastSettings = broadcastSettings,
            audioConfig = audioConfig,
            createdAt = createdAt,
            updatedAt = updatedAt
        )
    }

    private fun createSampleProjects(): List<Project> {
        val proj1 = Project(
            id = "proj_tv_broadcast_sample_v2",
            title = "تقرير تلفزيوني: ثورة الذكاء الاصطناعي والإعلام الجديد 2.0",
            description = "قالب إخباري تفاعلي متكامل مع شريط عاجل ومؤثرات صوتية واستيراد وسائط",
            aspectRatio = AspectRatio.RATIO_16_9,
            broadcastSettings = BroadcastSettings(
                channelLogoText = "KHALED SOOT NEWS",
                channelSubText = "تغطية مباشرة وحصرية 2.0",
                tickerText = "عاجل: إطلاق استوديو خالد صوت 2.0 بمحرك تصدير MP4 وتنسيق خطوط احترافي متقدم...",
                showTicker = true,
                studioLocation = "الرياض - الاستوديو 1",
                presenterName = "خالد صوت"
            ),
            audioConfig = AudioConfig(
                selectedMusicPreset = "BREAKING_NEWS",
                selectedSoundFxId = "fx_breaking_news",
                musicVolume = 0.4f,
                soundFxVolume = 0.85f,
                autoDucking = true
            ),
            slides = listOf(
                Slide(
                    id = "s1",
                    title = "عاجل: تدشين استوديو خالد صوت 2.0 للتقارير والعروض التلفزيونية",
                    subtitle = "نشرة الرابعة التفاعلية - استوديو خالد صوت",
                    bodyText = "يدعم الإصدار الجديد استيراد الوسائط المتعددة ولوحة تنسيق الخطوط العربية ومكتبة المؤثرات الصوتية الحقيقية.",
                    templateCategory = TemplateCategory.TV_NEWS,
                    bgPresetIndex = 0,
                    showBreakingBanner = true,
                    breakingNewsText = "عاجل | إطلاق استوديو خالد صوت 2.0 مع تصدير MP4 وحفظ في Movies/KhaledSootStudio",
                    lowerThirdName = "خالد صوت",
                    lowerThirdRole = "المعد والمقدم الرئيسي",
                    showLowerThird = true,
                    showLiveBadge = true,
                    durationSeconds = 6,
                    transition = TransitionType.FADE,
                    textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.KUFI.id, titleFontSizeSp = 20, isBold = true)
                ),
                Slide(
                    id = "s2",
                    title = "مؤشرات نمو المشاهدات وصناعة المحتوى الرقمي",
                    subtitle = "إحصائيات متسارعة لمنصات الفيديو في الشرق الأوسط",
                    bodyText = "ارتفاع ملحوظ في استخدام الهواتف الذكية لمونتاج وتصدير التقارير التلفزيونية ذات الجودة العالية.",
                    bulletPoints = listOf(
                        "استيراد الصور والفيديوهات عبر Android Photo Picker المعتمد",
                        "مكتبة مؤثرات صوتية أصلية جاهزة للبث المباشر",
                        "تصدير بدقة 1080p Full HD و 720p لكافة المنصات"
                    ),
                    templateCategory = TemplateCategory.ECONOMIC,
                    bgPresetIndex = 1,
                    showStatCard = true,
                    statValue = "+140%",
                    statLabel = "نمو التفاعل مع تقارير الفيديو التلفزيونية",
                    lowerThirdName = "مركز الرصد الرقمي",
                    lowerThirdRole = "وحدة التحليل البياني",
                    showLowerThird = true,
                    durationSeconds = 7,
                    transition = TransitionType.SLIDE
                )
            )
        )

        return listOf(proj1)
    }
}
