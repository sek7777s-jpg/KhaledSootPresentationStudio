package com.example.data.model

import java.util.UUID

enum class AspectRatio(
    val labelAr: String,
    val ratioFloat: Float,
    val iconLabel: String,
    val platformHint: String
) {
    RATIO_16_9("16:9 شاشة تلفزيون وعرض", 16f / 9f, "16:9", "يوتيوب وشاشات التلفزيون 1080p/720p"),
    RATIO_9_16("9:16 ريلز وتيك توك", 9f / 16f, "9:16", "ريلز إنستغرام، تيك توك، يوتيوب شورتس"),
    RATIO_1_1("1:1 منشورات مربعة", 1f, "1:1", "منشورات فيسبوك وإنستغرام")
}

enum class TransitionType(val titleAr: String) {
    FADE("تلاشي سينمائي"),
    SLIDE("انزلاق تلفزيوني"),
    ZOOM("تكبير ديناميكي"),
    WIPE("مسح استوديو")
}

enum class TemplateCategory(val titleAr: String, val iconDescription: String) {
    TV_NEWS("تقرير إخباري تلفزيوني", "قوالب عواجل وشارات إخبارية"),
    HISTORICAL_DOC("وثائقي وسرد تاريخي", "قوالب سردية وخرائط توضيحية"),
    ECONOMIC("اقتصادي ومؤشرات وأرقام", "نسب بيانية وإحصائيات مالية"),
    EDUCATIONAL("عرض تدريبي وتعليمي", "محاور رئيسية ونقاط استعراض")
}

enum class StudioFontFamily(val id: String, val titleAr: String) {
    SANS_SERIF("SANS_SERIF", "حديث متوازن (Sans)"),
    SERIF("SERIF", "نسخ كلاسيكي (Serif)"),
    KUFI("KUFI", "كوفي عريض للتلفزيون"),
    MONOSPACE("MONOSPACE", "تقني ورقمي (Mono)")
}

data class TextStyleConfig(
    val fontFamilyId: String = StudioFontFamily.SANS_SERIF.id,
    val titleFontSizeSp: Int = 18,
    val subtitleFontSizeSp: Int = 12,
    val bodyFontSizeSp: Int = 11,
    val isBold: Boolean = true,
    val textColorHex: String = "#F8F9FA",
    val accentColorHex: String = "#00B4D8",
    val textAlignment: String = "RIGHT" // RIGHT, CENTER, LEFT
)

data class SoundEffectItem(
    val id: String,
    val titleAr: String,
    val categoryAr: String,
    val fileName: String,
    val durationSeconds: Float,
    val descriptionAr: String
)

data class Slide(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val subtitle: String = "",
    val bodyText: String = "",
    val bulletPoints: List<String> = emptyList(),
    val templateCategory: TemplateCategory = TemplateCategory.TV_NEWS,
    val bgPresetIndex: Int = 0,
    val imageUri: String? = null,
    val videoUri: String? = null,
    val mediaList: List<String> = emptyList(),
    val imagePosition: String = "SPLIT", // SPLIT, CENTER, FULL_BG, RIGHT, LEFT
    val durationSeconds: Int = 5,
    val transition: TransitionType = TransitionType.FADE,
    val lowerThirdName: String = "",
    val lowerThirdRole: String = "",
    val showLowerThird: Boolean = false,
    val showLiveBadge: Boolean = true,
    val breakingNewsText: String = "",
    val showBreakingBanner: Boolean = false,
    val statValue: String = "",
    val statLabel: String = "",
    val showStatCard: Boolean = false,
    val textStyle: TextStyleConfig = TextStyleConfig()
)

data class BroadcastSettings(
    val channelLogoText: String = "KHALED SOOT TV",
    val channelSubText: String = "صوت الخبر والتحليل",
    val tickerText: String = "استوديو خالد صوت 2.0: استمرار البث المباشر لأحدث التقارير الوثائقية والتحليلات المتخصصة على مدار الساعة...",
    val showTicker: Boolean = true,
    val tickerSpeed: Float = 1.0f,
    val studioLocation: String = "الرياض - الاستوديو الرئيسي",
    val presenterName: String = "خالد صوت",
    val tickerTextColorHex: String = "#F8F9FA",
    val tickerFontSizeSp: Int = 10,
    val tickerFontFamilyId: String = StudioFontFamily.SANS_SERIF.id
)

data class AudioConfig(
    val voiceoverPath: String? = null,
    val voiceoverDurationMs: Long = 0L,
    val selectedMusicPreset: String = "BREAKING_NEWS", // NONE, BREAKING_NEWS, DOCUMENTARY, ECONOMIC_BEAT, CALM_PIANO, CUSTOM
    val customAudioPath: String? = null,
    val customAudioName: String? = null,
    val voiceVolume: Float = 1.0f,
    val musicVolume: Float = 0.45f,
    val soundFxVolume: Float = 0.8f,
    val selectedSoundFxId: String? = "fx_breaking_news",
    val audioOffsetSec: Float = 0f,
    val autoDucking: Boolean = true
)

data class Project(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "مشروع تقرير جديد",
    val description: String = "",
    val aspectRatio: AspectRatio = AspectRatio.RATIO_16_9,
    val slides: List<Slide> = emptyList(),
    val broadcastSettings: BroadcastSettings = BroadcastSettings(),
    val audioConfig: AudioConfig = AudioConfig(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
