package com.example.data.repository

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.sin

class AudioStudioManager(private val context: Context) {

    private var mediaRecorder: MediaRecorder? = null
    private var voiceMediaPlayer: MediaPlayer? = null
    private var customAudioPlayer: MediaPlayer? = null
    private var musicAudioTrack: AudioTrack? = null
    private var isPlayingMusic = false
    private var musicSynthesisJob: Job? = null

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    private val _recordingDurationSec = MutableStateFlow(0)
    val recordingDurationSec: StateFlow<Int> = _recordingDurationSec.asStateFlow()

    private val _amplitude = MutableStateFlow(0f)
    val amplitude: StateFlow<Float> = _amplitude.asStateFlow()

    private val _isPlayingVoicePreview = MutableStateFlow(false)
    val isPlayingVoicePreview: StateFlow<Boolean> = _isPlayingVoicePreview.asStateFlow()

    private val _isPlayingCustomPreview = MutableStateFlow(false)
    val isPlayingCustomPreview: StateFlow<Boolean> = _isPlayingCustomPreview.asStateFlow()

    private val _playbackProgressSec = MutableStateFlow(0f)
    val playbackProgressSec: StateFlow<Float> = _playbackProgressSec.asStateFlow()

    private var currentVoiceFile: File? = null
    private var recordingTimerJob: Job? = null
    private var playbackProgressJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    fun startRecording(): String? {
        stopPlayback()
        stopMusic()
        try {
            val audioDir = File(context.filesDir, "voiceovers")
            if (!audioDir.exists()) audioDir.mkdirs()
            val outputFile = File(audioDir, "rec_${System.currentTimeMillis()}.m4a")
            currentVoiceFile = outputFile

            val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }

            recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            recorder.setAudioEncodingBitRate(128000)
            recorder.setAudioSamplingRate(44100)
            recorder.setOutputFile(outputFile.absolutePath)
            recorder.prepare()
            recorder.start()

            mediaRecorder = recorder
            _isRecording.value = true
            _recordingDurationSec.value = 0

            recordingTimerJob = scope.launch(Dispatchers.IO) {
                var seconds = 0
                while (isActive && _isRecording.value) {
                    delay(100)
                    val maxAmp = try {
                        mediaRecorder?.maxAmplitude ?: 0
                    } catch (_: Exception) { 0 }
                    val normalizedAmp = (maxAmp / 32767f).coerceIn(0.05f, 1f)
                    _amplitude.value = normalizedAmp
                    if (System.currentTimeMillis() % 1000 < 100) {
                        seconds++
                        _recordingDurationSec.value = seconds
                    }
                }
            }
            return outputFile.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            _isRecording.value = false
            return null
        }
    }

    fun stopRecording(): String? {
        recordingTimerJob?.cancel()
        _isRecording.value = false
        _amplitude.value = 0f
        return try {
            mediaRecorder?.apply {
                stop()
                release()
            }
            mediaRecorder = null
            currentVoiceFile?.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            mediaRecorder = null
            null
        }
    }

    /**
     * Imports an audio file (MP3, WAV, AAC, M4A) selected via SAF/Content URI,
     * copies it into local storage, and returns Pair(filePath, displayName).
     */
    suspend fun importAudioFile(uri: Uri): Pair<String, String>? = withContext(Dispatchers.IO) {
        try {
            var fileName = "audio_${System.currentTimeMillis()}.mp3"
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex != -1 && cursor.moveToFirst()) {
                    fileName = cursor.getString(nameIndex) ?: fileName
                }
            }

            val importsDir = File(context.filesDir, "audio_imports")
            if (!importsDir.exists()) importsDir.mkdirs()

            val sanitized = fileName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
            val destFile = File(importsDir, "${System.currentTimeMillis()}_$sanitized")

            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            }

            if (destFile.exists() && destFile.length() > 0) {
                Pair(destFile.absolutePath, fileName)
            } else {
                null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun playVoiceover(path: String?, volume: Float = 1.0f, onFinished: () -> Unit = {}) {
        stopPlayback()
        if (path.isNullOrEmpty()) return
        val file = File(path)
        if (!file.exists()) return

        try {
            voiceMediaPlayer = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setVolume(volume.coerceIn(0f, 1f), volume.coerceIn(0f, 1f))
                prepare()
                setOnCompletionListener {
                    _isPlayingVoicePreview.value = false
                    playbackProgressJob?.cancel()
                    _playbackProgressSec.value = 0f
                    onFinished()
                }
                start()
            }
            _isPlayingVoicePreview.value = true

            playbackProgressJob = scope.launch {
                while (isActive && _isPlayingVoicePreview.value) {
                    val pos = voiceMediaPlayer?.currentPosition ?: 0
                    _playbackProgressSec.value = pos / 1000f
                    delay(200)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            _isPlayingVoicePreview.value = false
        }
    }

    fun playCustomAudio(path: String?, volume: Float = 0.8f, onFinished: () -> Unit = {}) {
        stopPlayback()
        if (path.isNullOrEmpty()) return
        val file = File(path)
        if (!file.exists()) return

        try {
            customAudioPlayer = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setVolume(volume.coerceIn(0f, 1f), volume.coerceIn(0f, 1f))
                prepare()
                setOnCompletionListener {
                    _isPlayingCustomPreview.value = false
                    playbackProgressJob?.cancel()
                    _playbackProgressSec.value = 0f
                    onFinished()
                }
                start()
            }
            _isPlayingCustomPreview.value = true

            playbackProgressJob = scope.launch {
                while (isActive && _isPlayingCustomPreview.value) {
                    val pos = customAudioPlayer?.currentPosition ?: 0
                    _playbackProgressSec.value = pos / 1000f
                    delay(200)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            _isPlayingCustomPreview.value = false
        }
    }

    fun stopPlayback() {
        playbackProgressJob?.cancel()
        _playbackProgressSec.value = 0f
        try {
            voiceMediaPlayer?.apply {
                if (isPlaying) stop()
                release()
            }
        } catch (_: Exception) {}
        voiceMediaPlayer = null
        _isPlayingVoicePreview.value = false

        try {
            customAudioPlayer?.apply {
                if (isPlaying) stop()
                release()
            }
        } catch (_: Exception) {}
        customAudioPlayer = null
        _isPlayingCustomPreview.value = false
    }

    fun startBackgroundMusic(preset: String, volume: Float = 0.5f) {
        if (preset == "NONE" || preset == "CUSTOM") {
            stopMusic()
            return
        }
        stopMusic()
        isPlayingMusic = true

        val sampleRate = 44100
        val bufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ) * 4

        try {
            musicAudioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            musicAudioTrack?.setVolume(volume.coerceIn(0f, 1f))
            musicAudioTrack?.play()

            musicSynthesisJob = scope.launch(Dispatchers.Default) {
                val baseFreqs = when (preset) {
                    "BREAKING_NEWS" -> listOf(220.0, 277.18, 329.63, 440.0)
                    "DOCUMENTARY" -> listOf(146.83, 220.0, 261.63, 329.63)
                    "ECONOMIC_BEAT" -> listOf(261.63, 329.63, 392.0, 523.25)
                    else -> listOf(196.0, 246.94, 293.66, 392.0)
                }

                val buffer = ShortArray(1024)
                var phase = 0.0
                var step = 0

                while (isActive && isPlayingMusic) {
                    val currentFreq = baseFreqs[(step / 16000) % baseFreqs.size]
                    val subFreq = currentFreq * 0.5

                    for (i in buffer.indices) {
                        val angle = 2.0 * Math.PI * currentFreq / sampleRate
                        val sampleVal = (sin(phase) * 0.65 + sin(phase * 0.5) * 0.25 + sin(phase * 2.0) * 0.1) * Short.MAX_VALUE * 0.35
                        buffer[i] = sampleVal.toInt().toShort()
                        phase += angle
                        if (phase > 2.0 * Math.PI) phase -= 2.0 * Math.PI
                        step++
                    }
                    musicAudioTrack?.write(buffer, 0, buffer.size)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setMusicVolume(volume: Float) {
        try {
            musicAudioTrack?.setVolume(volume.coerceIn(0f, 1f))
        } catch (_: Exception) {}
    }

    fun stopMusic() {
        isPlayingMusic = false
        musicSynthesisJob?.cancel()
        musicSynthesisJob = null
        try {
            musicAudioTrack?.apply {
                pause()
                flush()
                stop()
                release()
            }
        } catch (_: Exception) {}
        musicAudioTrack = null
    }

    fun release() {
        stopRecording()
        stopPlayback()
        stopMusic()
    }
}
