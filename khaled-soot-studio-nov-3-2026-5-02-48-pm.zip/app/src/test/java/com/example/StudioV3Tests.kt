package com.example

import com.example.data.model.AspectRatio
import com.example.data.model.ExportBitrateMode
import com.example.data.model.ExportFps
import com.example.data.model.ExportResolution
import com.example.data.model.ExportState
import com.example.data.model.ExportStatus
import com.example.data.model.Project
import com.example.data.model.ProjectType
import com.example.data.model.Slide
import com.example.data.model.StudioFontFamily
import com.example.data.model.StudioTemplateCatalog
import com.example.ui.viewmodel.StudioStorageInfo
import com.example.ui.viewmodel.StudioTab
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StudioV3Tests {

    @Test
    fun test1_aspectRatiosIncludingFourByFive() {
        assertEquals(4, AspectRatio.values().size)
        val ratio45 = AspectRatio.RATIO_4_5
        assertEquals(4f / 5f, ratio45.ratioFloat, 0.001f)
        assertEquals("4:5", ratio45.iconLabel)
        assertTrue(ratio45.labelAr.contains("4:5"))
    }

    @Test
    fun test2_exportResolutionsEnsureEvenDimensionsForH264() {
        val resolutions = ExportResolution.values()
        val ratios = AspectRatio.values()

        for (res in resolutions) {
            for (ratio in ratios) {
                val (w, h) = res.getDimensions(ratio)
                assertEquals("Width must be even for H.264 ($res, $ratio)", 0, w % 2)
                assertEquals("Height must be even for H.264 ($res, $ratio)", 0, h % 2)
                assertTrue("Width must be positive ($res, $ratio)", w > 0)
                assertTrue("Height must be positive ($res, $ratio)", h > 0)
            }
        }
    }

    @Test
    fun test3_projectTypesCatalogAndDefaults() {
        val types = ProjectType.values()
        assertEquals(8, types.size)

        val breaking = ProjectType.BREAKING_NEWS
        assertEquals("خبر عاجل", breaking.titleAr)
        assertEquals(AspectRatio.RATIO_16_9, breaking.defaultRatio)

        val social = ProjectType.SOCIAL_SHORT
        assertEquals("فيديو قصير للسوشيال ميديا", social.titleAr)
        assertEquals(AspectRatio.RATIO_9_16, social.defaultRatio)

        val doc = ProjectType.DOCUMENTARY
        assertEquals("فيلم وثائقي", doc.titleAr)
    }

    @Test
    fun test4_studioTemplatesCatalogIntegrity() {
        val templates = StudioTemplateCatalog.templates
        assertTrue("Templates catalog should have at least 6 templates", templates.size >= 6)

        for (item in templates) {
            assertNotNull(item.id)
            assertTrue("Template title should not be blank", item.titleAr.isNotBlank())
            assertTrue("Template description should not be blank", item.descriptionAr.isNotBlank())
            assertTrue("Template should have slidesCount >= 1", item.slidesCount >= 1)

            val generatedProject = item.createProject("مشروع تجريبي")
            assertNotNull(generatedProject.id)
            assertFalse("Generated project slides should not be empty", generatedProject.slides.isEmpty())
            assertEquals(item.projectType, generatedProject.projectType)
        }
    }

    @Test
    fun test5_exportStateTransitions() {
        var state = ExportState()
        assertEquals(ExportStatus.IDLE, state.status)
        assertEquals(0f, state.progress, 0.01f)

        state = state.copy(status = ExportStatus.RUNNING, progress = 0.5f, elapsedSeconds = 15)
        assertEquals(ExportStatus.RUNNING, state.status)
        assertEquals(15, state.elapsedSeconds)

        state = state.copy(status = ExportStatus.SUCCESS, progress = 1.0f)
        assertEquals(ExportStatus.SUCCESS, state.status)
        assertEquals(1.0f, state.progress, 0.01f)
    }

    @Test
    fun test6_videoTrimmingCalculation() {
        val slide = Slide(
            title = "مشهد فيديو",
            durationSeconds = 10,
            videoStartOffsetMs = 2000L,
            videoEndOffsetMs = 8000L
        )

        val trimmedSeconds = ((slide.videoEndOffsetMs - slide.videoStartOffsetMs) / 1000L).toInt()
        assertEquals(6, trimmedSeconds)
    }

    @Test
    fun test7_storageInfoFormatting() {
        val info = StudioStorageInfo(
            videosSizeBytes = 10 * 1024 * 1024L,
            imagesSizeBytes = 2 * 1024 * 1024L,
            audioSizeBytes = 500 * 1024L,
            exportsSizeBytes = 15 * 1024 * 1024L,
            totalSizeBytes = (10 + 2 + 15) * 1024 * 1024L + 500 * 1024L
        )

        val formatted = info.formatSize(info.videosSizeBytes)
        assertTrue(formatted.contains("10.0 MB") || formatted.contains("10 MB"))
    }

    @Test
    fun test8_studioTabsFifteenSections() {
        val tabs = StudioTab.values()
        assertEquals(15, tabs.size)
        assertTrue(tabs.any { it.name == "DASHBOARD" })
        assertTrue(tabs.any { it.name == "BREAKING_NEWS" })
        assertTrue(tabs.any { it.name == "DOCUMENTARY" })
        assertTrue(tabs.any { it.name == "VIDEO_TIMELINE" })
        assertTrue(tabs.any { it.name == "MEDIA_LIBRARY" })
        assertTrue(tabs.any { it.name == "EXPORT_HUB" })
        assertTrue(tabs.any { it.name == "SETTINGS_HELP" })
    }
}
