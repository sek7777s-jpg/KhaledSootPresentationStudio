package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SlideCanvasView
import com.example.ui.theme.StudioBlue
import com.example.ui.theme.StudioGoldLight
import com.example.ui.theme.StudioNavyBorder
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.StudioRed
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.viewmodel.StudioTab
import com.example.ui.viewmodel.StudioViewModel

@Composable
fun BreakingNewsStudioScreen(viewModel: StudioViewModel) {
    val currentProject by viewModel.currentProject.collectAsState()
    val currentSlide = viewModel.getCurrentSlide()

    if (currentProject == null || currentSlide == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("لا يوجد مشروع نشط، يرجى إنشاء أو اختيار مشروع.", color = StudioTextSecondary)
        }
        return
    }

    val proj = currentProject!!

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Header Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(StudioRed, Color(0xFF800020))))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(StudioRed.copy(alpha = 0.2f))
                            .border(1.5.dp, StudioRed, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Whatshot, contentDescription = null, tint = StudioRed, modifier = Modifier.size(24.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("استوديو الأخبار العاجلة – BREAKING NEWS", color = StudioTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Black)
                        Text("أشرطة عواجل حمراء، شارات تلفزيونية، وتغطيات طارئة مباشرة", color = StudioTextSecondary, fontSize = 10.sp)
                    }
                }
            }
        }

        // 2. Live Studio Monitor Canvas
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyDark),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(StudioRed, StudioBlue)))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    SlideCanvasView(
                        slide = currentSlide,
                        project = proj,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(210.dp)
                    )
                }
            }
        }

        // 3. Urgent Ticker & Banner Controls
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("إعدادات شريط العاجل والشارة الحمراء:", color = StudioGoldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    // Breaking Banner Toggle & Input
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("إظهار شريط عاجل أحمر على الشاشة", color = StudioTextPrimary, fontSize = 12.sp)
                        Switch(
                            checked = currentSlide.showBreakingBanner,
                            onCheckedChange = { viewModel.updateCurrentSlide(currentSlide.copy(showBreakingBanner = it)) },
                            colors = SwitchDefaults.colors(checkedThumbColor = StudioRed, checkedTrackColor = StudioRed.copy(alpha = 0.5f))
                        )
                    }

                    if (currentSlide.showBreakingBanner) {
                        OutlinedTextField(
                            value = currentSlide.breakingNewsText,
                            onValueChange = { viewModel.updateCurrentSlide(currentSlide.copy(breakingNewsText = it)) },
                            label = { Text("نص الخبر العاجل") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = StudioRed,
                                unfocusedBorderColor = StudioNavyBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = StudioTextPrimary
                            )
                        )
                    }

                    // Ticker Bottom Message
                    OutlinedTextField(
                        value = proj.broadcastSettings.tickerText,
                        onValueChange = {
                            viewModel.updateBroadcastSettings(proj.broadcastSettings.copy(tickerText = it))
                        },
                        label = { Text("شريط الأخبار المتحرك أسفل الشاشة") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = StudioBlue,
                            unfocusedBorderColor = StudioNavyBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = StudioTextPrimary
                        )
                    )

                    // Reporter Lower Third
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = currentSlide.lowerThirdName,
                            onValueChange = { viewModel.updateCurrentSlide(currentSlide.copy(lowerThirdName = it, showLowerThird = it.isNotEmpty())) },
                            label = { Text("اسم الموفد / المراسل") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = StudioBlue,
                                unfocusedBorderColor = StudioNavyBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = StudioTextPrimary
                            )
                        )

                        OutlinedTextField(
                            value = currentSlide.lowerThirdRole,
                            onValueChange = { viewModel.updateCurrentSlide(currentSlide.copy(lowerThirdRole = it)) },
                            label = { Text("الصفة / الموقع") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = StudioBlue,
                                unfocusedBorderColor = StudioNavyBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = StudioTextPrimary
                            )
                        )
                    }
                }
            }
        }

        // 4. Sound FX Quick Trigger
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.GraphicEq, contentDescription = null, tint = StudioRed, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("مؤثرات العواجل الصوتية الحية:", color = StudioTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { viewModel.playSoundEffect("fx_breaking_news") },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = StudioRed),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("شارة عاجل 🚨", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { viewModel.playSoundEffect("fx_dramatic_sting") },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = StudioNavySurface),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("ضربة درامية ⚡", fontSize = 11.sp, color = StudioTextPrimary)
                        }
                    }
                }
            }
        }

        // 5. Actions: Go to timeline or export
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { viewModel.selectTab(StudioTab.VIDEO_TIMELINE) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = StudioBlue),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("محرر ومونتاج الفيديو", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { viewModel.selectTab(StudioTab.EXPORT_HUB) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = StudioRed),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تصدير التقرير", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
