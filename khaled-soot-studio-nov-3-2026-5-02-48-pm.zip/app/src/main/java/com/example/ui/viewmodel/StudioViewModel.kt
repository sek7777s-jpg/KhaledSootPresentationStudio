package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AspectRatio
import com.example.data.model.AudioConfig
import com.example.data.model.BroadcastSettings
import com.example.data.model.ExportBitrateMode
import com.example.data.model.ExportFps
import com.example.data.model.ExportResolution
import com.example.data.model.ExportState
import com.example.data.model.Project
import com.example.data.model.ProjectType
import com.example.data.model.Slide
import com.example.data.model.SoundEffectItem
import com.example.data.model.StudioFontFamily
import com.example.data.model.StudioTemplateItem
import com.example.data.model.TemplateCategory
import com.example.data.model.TextStyleConfig
import com.example.data.model.TransitionType
import com.example.data.model.VideoDisplayMode
import com.example.data.repository.AudioStudioManager
import com.example.data.repository.MediaStorageHelper
import com.example.data.repository.ProjectRepository
import com.example.data.repository.SoundFxManager
import com.example.data.repository.VideoExporter
import com.example.data.service.StudioExportService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

enum class StudioTab(val id: String, val titleAr: String, val iconDesc: String) {
    DASHBOARD("DASHBOARD", "لوحة التحكم الرئيسية", "نظرة عامة وإحصائيات واستئناف العمل"),
    PROJECTS("PROJECTS", "مشاريعي", "إدارة وتصفح المشاريع المحفوظة"),
    NEW_PROJECT("NEW_PROJECT", "إنشاء مشروع جديد", "بدء إنتاج جديد وتحديد القالب والنوع"),
    BREAKING_NEWS("BREAKING_NEWS", "استوديو الأخبار العاجلة", "عواجل وشارات حمراء وشريط عاجل"),
    NEWS_REPORTS("NEWS_REPORTS", "استوديو التقارير الإخبارية", "تقارير تلفزيونية ومراسلين"),
    DOCUMENTARY("DOCUMENTARY", "استوديو الأفلام الوثائقية", "سرد سينمائي واقتباسات وأرشيف"),
    VIDEO_TIMELINE("VIDEO_TIMELINE", "محرر الفيديو والمونتاج", "الخط الزمني والانتقالات والقص"),
    SLIDE_GRAPHICS("SLIDE_GRAPHICS", "محرر الصور والتصاميم", "الشرائح والرسوم والتقسيمات"),
    TYPOGRAPHY_TITLES("TYPOGRAPHY_TITLES", "استوديو النصوص والعناوين", "الخطوط والأحجام والشريط السفلي"),
    VOICEOVER_AUDIO("VOICEOVER_AUDIO", "استوديو التعليق الصوتي", "تسجيل وميكساج ومسارات صوتية"),
    SOUND_FX_MUSIC("SOUND_FX_MUSIC", "مكتبة الموسيقى والمؤثرات", "مؤثرات إخبارية ووثائقية"),
    MEDIA_LIBRARY("MEDIA_LIBRARY", "مكتبة الوسائط", "الفيديوهات والصور المستوردة محلياً"),
    TEMPLATES_CATALOG("TEMPLATES_CATALOG", "القوالب الجاهزة", "قوالب قابلة للتخصيص الكامل"),
    EXPORT_HUB("EXPORT_HUB", "إعدادات التصدير والجودة", "تصدير MP4 في الخلفية بجودة 4K/1080p"),
    SETTINGS_HELP("SETTINGS_HELP", "الإعدادات والمساعدة", "إدارة التخزين ومعلومات الاستوديو")
}

data class StudioStorageInfo(
    val videosSizeBytes: Long = 0L,
    val imagesSizeBytes: Long = 0L,
    val audioSizeBytes: Long = 0L,
    val exportsSizeBytes: Long = 0L,
    val totalSizeBytes: Long = 0L
) {
    fun formatSize(bytes: Long): String {
        return when {
            bytes >= 1024 * 1024 * 1024 -> String.format("%.2f GB", bytes.toDouble() / (1024 * 1024 * 1024))
            bytes >= 1024 * 1024 -> String.format("%.1f MB", bytes.toDouble() / (1024 * 1024))
            bytes >= 1024 -> String.format("%.0f KB", bytes.toDouble() / 1024)
            else -> "$bytes B"
        }
    }
}

class StudioViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ProjectRepository(application)
    val audioManager = AudioStudioManager(application)
    val soundFxManager = SoundFxManager(application)
    val videoExporter = VideoExporter(application)
    val mediaStorageHelper = MediaStorageHelper(application)

    val projects: StateFlow<List<Project>> = repository.projects

    private val _selectedTab = MutableStateFlow(StudioTab.DASHBOARD)
    val selectedTab: StateFlow<StudioTab> = _selectedTab.asStateFlow()

    private val _currentProject = MutableStateFlow<Project?>(null)
    val currentProject: StateFlow<Project?> = _currentProject.asStateFlow()

    private val _currentSlideIndex = MutableStateFlow(0)
    val currentSlideIndex: StateFlow<Int> = _currentSlideIndex.asStateFlow()

    // Full screen video preview toggle
    private val _isFullScreenPreview = MutableStateFlow(false)
    val isFullScreenPreview: StateFlow<Boolean> = _isFullScreenPreview.asStateFlow()

    // Storage info state
    private val _storageInfo = MutableStateFlow(StudioStorageInfo())
    val storageInfo: StateFlow<StudioStorageInfo> = _storageInfo.asStateFlow()

    // Connected to Background Foreground Service
    val exportState: StateFlow<ExportState> = StudioExportService.exportState

    // Playback Preview State
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playbackSlideIndex = MutableStateFlow(0)
    val playbackSlideIndex: StateFlow<Int> = _playbackSlideIndex.asStateFlow()

    private val _playbackElapsedSeconds = MutableStateFlow(0f)
    val playbackElapsedSeconds: StateFlow<Float> = _playbackElapsedSeconds.asStateFlow()

    private val _showAboutDialog = MutableStateFlow(false)
    val showAboutDialog: StateFlow<Boolean> = _showAboutDialog.asStateFlow()

    val availableSoundEffects: List<SoundEffectItem> = soundFxManager.availableEffects
    val currentlyPlayingFxId: StateFlow<String?> = soundFxManager.currentlyPlayingId

    private var playbackJob: Job? = null

    init {
        viewModelScope.launch {
            repository.initialize()
            soundFxManager.initialize()
            if (_currentProject.value == null && repository.projects.value.isNotEmpty()) {
                _currentProject.value = repository.projects.value.first()
            }
            refreshStorageInfo()
        }
    }

    fun selectTab(tab: StudioTab) {
        _selectedTab.value = tab
    }

    fun setFullScreenPreview(isFull: Boolean) {
        _isFullScreenPreview.value = isFull
    }

    fun openAboutDialog(show: Boolean) {
        _showAboutDialog.value = show
    }

    fun selectProject(project: Project) {
        _currentProject.value = project
        _currentSlideIndex.value = 0
        _selectedTab.value = StudioTab.SLIDE_GRAPHICS
    }

    fun createNewProject(
        title: String = "مشروع إعلامي جديد 3.0",
        type: ProjectType = ProjectType.NEWS_REPORT,
        aspectRatio: AspectRatio = AspectRatio.RATIO_16_9,
        resolution: ExportResolution = ExportResolution.RES_720P,
        category: TemplateCategory = TemplateCategory.TV_NEWS
    ) {
        viewModelScope.launch {
            val defaultSlide = Slide(
                title = "عنوان التقرير الإخباري الرئيسي",
                subtitle = "استوديو خالد صوت 3.0 للإنتاج الإعلامي",
                bodyText = "استعراض تفاعلي لأهم الأحداث مع دعم استيراد الوسائط ومونتاج الفيديو والتصدير في الخلفية.",
                templateCategory = category,
                showBreakingBanner = (type == ProjectType.BREAKING_NEWS),
                breakingNewsText = "عاجل | استوديو خالد صوت 3.0 يبدأ التغطية الحصرية",
                showLowerThird = true,
                lowerThirdName = "خالد صوت",
                lowerThirdRole = "رئيس التحرير ومقدم النشرة",
                durationSeconds = 6,
                textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.CAIRO.id, titleFontSizeSp = 20, isBold = true)
            )

            val newProj = Project(
                id = UUID.randomUUID().toString(),
                title = title,
                projectType = type,
                aspectRatio = aspectRatio,
                exportResolution = resolution,
                slides = listOf(defaultSlide),
                broadcastSettings = BroadcastSettings()
            )

            repository.saveProject(newProj)
            _currentProject.value = newProj
            _currentSlideIndex.value = 0
            _selectedTab.value = StudioTab.SLIDE_GRAPHICS
            refreshStorageInfo()
        }
    }

    fun applyTemplate(templateItem: StudioTemplateItem) {
        viewModelScope.launch {
            val proj = templateItem.createProject("")
            repository.saveProject(proj)
            _currentProject.value = proj
            _currentSlideIndex.value = 0
            _selectedTab.value = StudioTab.SLIDE_GRAPHICS
            refreshStorageInfo()
        }
    }

    fun duplicateProject(project: Project) {
        viewModelScope.launch {
            val dup = repository.duplicateProject(project)
            _currentProject.value = dup
            refreshStorageInfo()
        }
    }

    fun deleteProject(projectId: String) {
        viewModelScope.launch {
            repository.deleteProject(projectId)
            if (_currentProject.value?.id == projectId) {
                _currentProject.value = repository.projects.value.firstOrNull()
                _currentSlideIndex.value = 0
            }
            refreshStorageInfo()
        }
    }

    fun updateProjectTitle(newTitle: String) {
        val proj = _currentProject.value ?: return
        val updated = proj.copy(title = newTitle)
        _currentProject.value = updated
        autoSave(updated)
    }

    fun updateAspectRatio(ratio: AspectRatio) {
        val proj = _currentProject.value ?: return
        val updated = proj.copy(aspectRatio = ratio)
        _currentProject.value = updated
        autoSave(updated)
    }

    fun updateExportResolution(res: ExportResolution) {
        val proj = _currentProject.value ?: return
        val updated = proj.copy(exportResolution = res)
        _currentProject.value = updated
        autoSave(updated)
    }

    fun updateExportFps(fps: ExportFps) {
        val proj = _currentProject.value ?: return
        val updated = proj.copy(exportFps = fps)
        _currentProject.value = updated
        autoSave(updated)
    }

    fun updateExportBitrateMode(mode: ExportBitrateMode) {
        val proj = _currentProject.value ?: return
        val updated = proj.copy(exportBitrateMode = mode)
        _currentProject.value = updated
        autoSave(updated)
    }

    fun updateBroadcastSettings(settings: BroadcastSettings) {
        val proj = _currentProject.value ?: return
        val updated = proj.copy(broadcastSettings = settings)
        _currentProject.value = updated
        autoSave(updated)
    }

    fun updateAudioConfig(config: AudioConfig) {
        val proj = _currentProject.value ?: return
        val updated = proj.copy(audioConfig = config)
        _currentProject.value = updated
        autoSave(updated)
    }

    fun selectSlide(index: Int) {
        val proj = _currentProject.value ?: return
        if (index in proj.slides.indices) {
            _currentSlideIndex.value = index
        }
    }

    fun updateCurrentSlide(updatedSlide: Slide) {
        val proj = _currentProject.value ?: return
        val idx = _currentSlideIndex.value
        if (idx in proj.slides.indices) {
            val mutableList = proj.slides.toMutableList()
            mutableList[idx] = updatedSlide
            val updatedProj = proj.copy(slides = mutableList)
            _currentProject.value = updatedProj
            autoSave(updatedProj)
        }
    }

    // Persistent Media Import Operations
    fun importVideoForSlide(uri: Uri) {
        viewModelScope.launch {
            val localPath = mediaStorageHelper.copyUriToLocalVideo(uri) ?: uri.toString()
            val durationSec = mediaStorageHelper.getVideoDurationSeconds(localPath)
            val current = getCurrentSlide() ?: return@launch
            val updatedMedia = (listOf(localPath) + current.mediaList.filter { it != localPath })
            updateCurrentSlide(
                current.copy(
                    videoUri = localPath,
                    durationSeconds = durationSec.coerceIn(3, 120),
                    mediaList = updatedMedia
                )
            )
            refreshStorageInfo()
        }
    }

    fun importImageForSlide(uri: Uri) {
        viewModelScope.launch {
            val localPath = mediaStorageHelper.copyUriToLocalImage(uri) ?: uri.toString()
            val current = getCurrentSlide() ?: return@launch
            val updatedMedia = (listOf(localPath) + current.mediaList.filter { it != localPath })
            updateCurrentSlide(
                current.copy(
                    imageUri = localPath,
                    mediaList = updatedMedia
                )
            )
            refreshStorageInfo()
        }
    }

    fun importMultipleImagesForSlide(uris: List<Uri>) {
        viewModelScope.launch {
            val localPaths = uris.map { mediaStorageHelper.copyUriToLocalImage(it) ?: it.toString() }
            val current = getCurrentSlide() ?: return@launch
            val currentMedia = current.mediaList.toMutableList()
            localPaths.forEach { if (!currentMedia.contains(it)) currentMedia.add(it) }
            val primaryImage = current.imageUri ?: localPaths.firstOrNull()
            updateCurrentSlide(current.copy(imageUri = primaryImage, mediaList = currentMedia))
            refreshStorageInfo()
        }
    }

    fun setSlideImage(uriString: String) {
        val current = getCurrentSlide() ?: return
        val updatedMedia = (listOf(uriString) + current.mediaList.filter { it != uriString })
        updateCurrentSlide(current.copy(imageUri = uriString, mediaList = updatedMedia))
    }

    fun setSlideVideo(uriString: String) {
        val current = getCurrentSlide() ?: return
        val updatedMedia = (listOf(uriString) + current.mediaList.filter { it != uriString })
        updateCurrentSlide(current.copy(videoUri = uriString, mediaList = updatedMedia))
    }

    fun setSlideVideoDisplayMode(mode: VideoDisplayMode) {
        val current = getCurrentSlide() ?: return
        updateCurrentSlide(current.copy(videoDisplayMode = mode))
    }

    fun setSlideVideoZoom(zoom: Float) {
        val current = getCurrentSlide() ?: return
        updateCurrentSlide(current.copy(videoZoom = zoom.coerceIn(0.5f, 2.5f)))
    }

    fun setSlideVideoPan(panX: Float, panY: Float) {
        val current = getCurrentSlide() ?: return
        updateCurrentSlide(current.copy(videoPanX = panX.coerceIn(-100f, 100f), videoPanY = panY.coerceIn(-100f, 100f)))
    }

    fun setSlideVideoVolume(volume: Float) {
        val current = getCurrentSlide() ?: return
        updateCurrentSlide(current.copy(videoVolume = volume.coerceIn(0f, 1f)))
    }

    fun setSlideVideoTrim(startOffsetMs: Long, endOffsetMs: Long) {
        val current = getCurrentSlide() ?: return
        val safeStart = startOffsetMs.coerceAtLeast(0L)
        val safeEnd = if (endOffsetMs > safeStart) endOffsetMs else 0L
        val trimmedDurationSec = if (safeEnd > safeStart) ((safeEnd - safeStart) / 1000L).toInt().coerceIn(2, 120) else current.durationSeconds
        updateCurrentSlide(
            current.copy(
                videoStartOffsetMs = safeStart,
                videoEndOffsetMs = safeEnd,
                durationSeconds = trimmedDurationSec
            )
        )
    }

    fun addMultipleMediaToSlide(uriStrings: List<String>) {
        val current = getCurrentSlide() ?: return
        val currentMedia = current.mediaList.toMutableList()
        uriStrings.forEach { if (!currentMedia.contains(it)) currentMedia.add(it) }
        val primaryImage = current.imageUri ?: uriStrings.firstOrNull()
        updateCurrentSlide(current.copy(imageUri = primaryImage, mediaList = currentMedia))
    }

    fun removeMediaFromSlide(uriString: String) {
        val current = getCurrentSlide() ?: return
        val currentMedia = current.mediaList.filter { it != uriString }
        val newImg = if (current.imageUri == uriString) currentMedia.firstOrNull() else current.imageUri
        val newVid = if (current.videoUri == uriString) null else current.videoUri
        updateCurrentSlide(current.copy(imageUri = newImg, videoUri = newVid, mediaList = currentMedia))
    }

    fun setSlideMediaPosition(position: String) {
        val current = getCurrentSlide() ?: return
        updateCurrentSlide(current.copy(imagePosition = position))
    }

    // Typography Operations
    fun updateSlideTextStyle(style: TextStyleConfig) {
        val current = getCurrentSlide() ?: return
        updateCurrentSlide(current.copy(textStyle = style))
    }

    // Audio Import & Sound Effects
    fun importAudioFile(uri: Uri) {
        viewModelScope.launch {
            val result = audioManager.importAudioFile(uri)
            if (result != null) {
                val (filePath, fileName) = result
                val proj = _currentProject.value ?: return@launch
                val updatedAudio = proj.audioConfig.copy(
                    customAudioPath = filePath,
                    customAudioName = fileName,
                    selectedMusicPreset = "CUSTOM"
                )
                updateAudioConfig(updatedAudio)
                refreshStorageInfo()
            }
        }
    }

    fun playSoundEffect(id: String, volume: Float = 0.8f) {
        soundFxManager.playSoundEffect(id, volume)
    }

    fun stopSoundEffect() {
        soundFxManager.stopSoundEffect()
    }

    fun selectSoundEffectForProject(id: String) {
        val proj = _currentProject.value ?: return
        updateAudioConfig(proj.audioConfig.copy(selectedSoundFxId = id))
    }

    fun getCurrentSlide(): Slide? {
        val proj = _currentProject.value ?: return null
        val idx = _currentSlideIndex.value
        return proj.slides.getOrNull(idx) ?: proj.slides.firstOrNull()
    }

    fun addSlide(category: TemplateCategory = TemplateCategory.TV_NEWS) {
        val proj = _currentProject.value ?: return
        val newSlide = Slide(
            title = "مشهد جديد #${proj.slides.size + 1}",
            subtitle = "وصف فرعي للمشهد التلفزيوني",
            bodyText = "محتوى الشريحة التوضيحي للتقرير أو العرض التقديمي.",
            templateCategory = category,
            bgPresetIndex = (proj.slides.size % 5),
            durationSeconds = 5
        )
        val mutableList = proj.slides.toMutableList()
        mutableList.add(newSlide)
        val updatedProj = proj.copy(slides = mutableList)
        _currentProject.value = updatedProj
        _currentSlideIndex.value = mutableList.lastIndex
        autoSave(updatedProj)
    }

    fun duplicateSlide(index: Int) {
        val proj = _currentProject.value ?: return
        if (index in proj.slides.indices) {
            val source = proj.slides[index]
            val dup = source.copy(id = UUID.randomUUID().toString(), title = "${source.title} (نسخة)")
            val mutableList = proj.slides.toMutableList()
            mutableList.add(index + 1, dup)
            val updatedProj = proj.copy(slides = mutableList)
            _currentProject.value = updatedProj
            _currentSlideIndex.value = index + 1
            autoSave(updatedProj)
        }
    }

    fun deleteSlide(index: Int) {
        val proj = _currentProject.value ?: return
        if (proj.slides.size <= 1) return
        if (index in proj.slides.indices) {
            val mutableList = proj.slides.toMutableList()
            mutableList.removeAt(index)
            val updatedProj = proj.copy(slides = mutableList)
            _currentProject.value = updatedProj
            _currentSlideIndex.value = (index - 1).coerceAtLeast(0)
            autoSave(updatedProj)
        }
    }

    fun moveSlideUp(index: Int) {
        if (index > 0) {
            moveSlide(index, index - 1)
        }
    }

    fun moveSlideDown(index: Int) {
        val proj = _currentProject.value ?: return
        if (index < proj.slides.lastIndex) {
            moveSlide(index, index + 1)
        }
    }

    fun moveSlide(from: Int, to: Int) {
        val proj = _currentProject.value ?: return
        if (from in proj.slides.indices && to in proj.slides.indices && from != to) {
            val mutableList = proj.slides.toMutableList()
            val item = mutableList.removeAt(from)
            mutableList.add(to, item)
            val updatedProj = proj.copy(slides = mutableList)
            _currentProject.value = updatedProj
            _currentSlideIndex.value = to
            autoSave(updatedProj)
        }
    }

    // Playback Engine
    fun togglePlay() {
        if (_isPlaying.value) {
            stopPlayback()
        } else {
            startPlayback()
        }
    }

    private fun startPlayback() {
        val proj = _currentProject.value ?: return
        if (proj.slides.isEmpty()) return

        _isPlaying.value = true
        val totalSec = proj.slides.sumOf { it.durationSeconds }

        val audioConf = proj.audioConfig
        if (audioConf.selectedMusicPreset != "NONE" && audioConf.selectedMusicPreset != "CUSTOM") {
            audioManager.startBackgroundMusic(audioConf.selectedMusicPreset, audioConf.musicVolume)
        } else if (audioConf.selectedMusicPreset == "CUSTOM" && !audioConf.customAudioPath.isNullOrEmpty()) {
            audioManager.playCustomAudio(audioConf.customAudioPath, audioConf.musicVolume)
        }

        playbackJob?.cancel()
        playbackJob = viewModelScope.launch {
            var currentSec = _playbackElapsedSeconds.value
            if (currentSec >= totalSec) currentSec = 0f

            while (isActive && _isPlaying.value && currentSec < totalSec) {
                delay(100)
                currentSec += 0.1f
                _playbackElapsedSeconds.value = currentSec

                var accum = 0
                var activeIdx = 0
                for (i in proj.slides.indices) {
                    accum += proj.slides[i].durationSeconds
                    if (currentSec <= accum) {
                        activeIdx = i
                        break
                    }
                }
                _playbackSlideIndex.value = activeIdx
            }

            if (currentSec >= totalSec) {
                stopPlayback()
                _playbackElapsedSeconds.value = 0f
                _playbackSlideIndex.value = 0
            }
        }
    }

    fun stopPlayback() {
        _isPlaying.value = false
        playbackJob?.cancel()
        playbackJob = null
        audioManager.stopMusic()
        audioManager.stopPlayback()
        soundFxManager.stopSoundEffect()
    }

    fun seekPlaybackTo(seconds: Float) {
        _playbackElapsedSeconds.value = seconds
        val proj = _currentProject.value ?: return
        var accum = 0
        var activeIdx = 0
        for (i in proj.slides.indices) {
            accum += proj.slides[i].durationSeconds
            if (seconds <= accum) {
                activeIdx = i
                break
            }
        }
        _playbackSlideIndex.value = activeIdx
    }

    // Foreground Background Video Exporting
    fun startBackgroundExport(project: Project? = null) {
        val target = project ?: _currentProject.value ?: return
        StudioExportService.startExport(getApplication(), target)
    }

    fun cancelBackgroundExport() {
        StudioExportService.cancelExport(getApplication())
    }

    fun resetExportStatus() {
        StudioExportService.resetExportState()
    }

    fun openExportedVideo() {
        videoExporter.openExportedVideo()
    }

    fun shareExportedVideo() {
        videoExporter.shareExportedVideo()
    }

    // Storage Management & Cache Clearing
    fun refreshStorageInfo() {
        viewModelScope.launch(Dispatchers.IO) {
            val context = getApplication<Application>()
            val vDir = File(context.filesDir, "imported_videos")
            val iDir = File(context.filesDir, "imported_images")
            val aDir = File(context.filesDir, "audio")
            val eDir = File(context.filesDir, "exports")

            val vSize = getFolderSize(vDir)
            val iSize = getFolderSize(iDir)
            val aSize = getFolderSize(aDir)
            val eSize = getFolderSize(eDir)
            val total = vSize + iSize + aSize + eSize

            _storageInfo.value = StudioStorageInfo(
                videosSizeBytes = vSize,
                imagesSizeBytes = iSize,
                audioSizeBytes = aSize,
                exportsSizeBytes = eSize,
                totalSizeBytes = total
            )
        }
    }

    fun cleanTemporaryFiles() {
        viewModelScope.launch(Dispatchers.IO) {
            val context = getApplication<Application>()
            // Clear app cache directory
            context.cacheDir.deleteRecursively()
            context.cacheDir.mkdirs()

            // Delete temporary exports older than 24 hours
            val eDir = File(context.filesDir, "exports")
            if (eDir.exists()) {
                val dayAgo = System.currentTimeMillis() - (24 * 60 * 60 * 1000L)
                eDir.listFiles()?.forEach { file ->
                    if (file.lastModified() < dayAgo && file.name.endsWith(".mp4")) {
                        file.delete()
                    }
                }
            }
            refreshStorageInfo()
        }
    }

    private fun getFolderSize(dir: File): Long {
        if (!dir.exists()) return 0L
        var size = 0L
        dir.listFiles()?.forEach { f ->
            size += if (f.isDirectory) getFolderSize(f) else f.length()
        }
        return size
    }

    private fun autoSave(project: Project) {
        viewModelScope.launch {
            repository.saveProject(project)
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioManager.release()
        soundFxManager.stopSoundEffect()
        stopPlayback()
    }
}
