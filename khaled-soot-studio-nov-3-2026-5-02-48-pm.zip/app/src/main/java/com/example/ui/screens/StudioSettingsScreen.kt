package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.SdStorage
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.StudioBlue
import com.example.ui.theme.StudioBlueGlow
import com.example.ui.theme.StudioGold
import com.example.ui.theme.StudioGoldLight
import com.example.ui.theme.StudioNavyBorder
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.StudioRed
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.viewmodel.StudioViewModel

@Composable
fun StudioSettingsScreen(viewModel: StudioViewModel) {
    val storageInfo by viewModel.storageInfo.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Header Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(StudioBlue, StudioGold)))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(StudioBlue.copy(alpha = 0.2f))
                            .border(1.5.dp, StudioBlue, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = null, tint = StudioBlueGlow, modifier = Modifier.size(24.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("الإعدادات والمساعدة والدعم الفني", color = StudioTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Black)
                        Text("إدارة التخزين، معلومات الإصدار 3.0، ودليل الإنتاج الإعلامي", color = StudioTextSecondary, fontSize = 10.sp)
                    }
                }
            }
        }

        // 2. Storage Breakdown & Clean Cache
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.SdStorage, contentDescription = null, tint = StudioGoldLight, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تفاصيل مساحة التخزين الداخلية:", color = StudioTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("مقاطع الفيديو المستوردة:", color = StudioTextSecondary, fontSize = 11.sp)
                        Text(storageInfo.formatSize(storageInfo.videosSizeBytes), color = StudioTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("الصور والرسومات:", color = StudioTextSecondary, fontSize = 11.sp)
                        Text(storageInfo.formatSize(storageInfo.imagesSizeBytes), color = StudioTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("ملفات التعليق الصوتي والموسيقى:", color = StudioTextSecondary, fontSize = 11.sp)
                        Text(storageInfo.formatSize(storageInfo.audioSizeBytes), color = StudioTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("ملفات الفيديو المصدّرة:", color = StudioTextSecondary, fontSize = 11.sp)
                        Text(storageInfo.formatSize(storageInfo.exportsSizeBytes), color = StudioTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Button(
                        onClick = { viewModel.cleanTemporaryFiles() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = StudioNavySurface),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.CleaningServices, contentDescription = null, modifier = Modifier.size(16.dp), tint = StudioGoldLight)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تنظيف الملفات المؤقتة والكاش بأمان", fontSize = 11.sp, color = StudioTextPrimary)
                    }
                }
            }
        }

        // 3. Media Production Tips
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Help, contentDescription = null, tint = StudioBlueGlow, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("إرشادات إنتاج التقارير التلفزيونية الناجحة:", color = StudioTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Text("1. التصدير في الخلفية: يمكنك تشغيل التصدير وقفل شاشة الهاتف بأمان؛ ستظل الخدمة تعمل حتى اكتمال التشفير وحفظ الفيديو في المعرض.", color = StudioTextSecondary, fontSize = 11.sp, lineHeight = 16.sp)
                    Text("2. اختيار نسبة الأبعاد: استخدم 16:9 للتلفزيون واليوتيوب، 9:16 لريلز وتيك توك وشورتس، و1:1 أو 4:5 لخلاصات السوشيال ميديا.", color = StudioTextSecondary, fontSize = 11.sp, lineHeight = 16.sp)
                    Text("3. تنسيق الخطوط: خط كايرو والمراعي مثاليان للنشرات الإخبارية، بينما خط أميري يمنح الأفلام الوثائقية طابعاً سينمائياً وتاريخياً عريقاً.", color = StudioTextSecondary, fontSize = 11.sp, lineHeight = 16.sp)
                    Text("4. توازن الصوت: ينصح بضبط صوت الموسيقى بين 30% إلى 45% لضمان وضوح التعليق الصوتي وصوت الفيديو الأصلي.", color = StudioTextSecondary, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }

        // 4. About Khaled Soot Studio 3.0
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(StudioRed, StudioGold)))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(StudioNavyDark)
                            .border(2.dp, StudioRed, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Videocam, contentDescription = null, tint = StudioGoldLight, modifier = Modifier.size(28.dp))
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "استوديو خالد صوت للإنتاج الإعلامي",
                        color = StudioTextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "الإصدار 3.0 (Khaled Soot Professional Media Studio 3.0)",
                        color = StudioGoldLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "إنتاج وتطوير: Khaled Soot",
                        color = StudioBlueGlow,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "تطبيق أندرويد مستقل 100% يعمل بدون إنترنت، مصمم لدعم صناع المحتوى الإعلامي، الصحفيين الميدانيين، وصناع الأفلام الوثائقية والتقارير التلفزيونية.",
                        color = StudioTextSecondary,
                        fontSize = 10.5.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
