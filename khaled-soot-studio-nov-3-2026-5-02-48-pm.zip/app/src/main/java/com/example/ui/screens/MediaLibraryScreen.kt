package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.StudioBlue
import com.example.ui.theme.StudioBlueGlow
import com.example.ui.theme.StudioGoldLight
import com.example.ui.theme.StudioNavyBorder
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.StudioRed
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.viewmodel.StudioViewModel
import java.io.File

data class LocalMediaItem(
    val file: File,
    val type: String, // "VIDEO", "IMAGE", "AUDIO"
    val sizeBytes: Long,
    val name: String
)

@Composable
fun MediaLibraryScreen(viewModel: StudioViewModel) {
    val context = LocalContext.current
    var mediaItems by remember { mutableStateOf<List<LocalMediaItem>>(emptyList()) }
    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, VIDEO, IMAGE, AUDIO

    fun loadLocalMedia() {
        val list = mutableListOf<LocalMediaItem>()
        val vDir = File(context.filesDir, "imported_videos")
        val iDir = File(context.filesDir, "imported_images")
        val aDir = File(context.filesDir, "audio")

        if (vDir.exists()) {
            vDir.listFiles()?.forEach { file ->
                if (file.isFile && file.length() > 0) {
                    list.add(LocalMediaItem(file, "VIDEO", file.length(), file.name))
                }
            }
        }
        if (iDir.exists()) {
            iDir.listFiles()?.forEach { file ->
                if (file.isFile && file.length() > 0) {
                    list.add(LocalMediaItem(file, "IMAGE", file.length(), file.name))
                }
            }
        }
        if (aDir.exists()) {
            aDir.listFiles()?.forEach { file ->
                if (file.isFile && file.length() > 0) {
                    list.add(LocalMediaItem(file, "AUDIO", file.length(), file.name))
                }
            }
        }
        mediaItems = list.sortedByDescending { it.file.lastModified() }
    }

    LaunchedEffect(Unit) {
        loadLocalMedia()
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.importImageForSlide(uri)
            loadLocalMedia()
        }
    }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.importVideoForSlide(uri)
            loadLocalMedia()
        }
    }

    val filteredList = when (selectedFilter) {
        "VIDEO" -> mediaItems.filter { it.type == "VIDEO" }
        "IMAGE" -> mediaItems.filter { it.type == "IMAGE" }
        "AUDIO" -> mediaItems.filter { it.type == "AUDIO" }
        else -> mediaItems
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Header Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(StudioBlue, Color(0xFF1D3557))))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(StudioBlue.copy(alpha = 0.2f))
                            .border(1.5.dp, StudioBlue, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = StudioBlueGlow, modifier = Modifier.size(24.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("مكتبة الوسائط والصور والفيديوهات", color = StudioTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Black)
                        Text("ملفات الوسائط المستوردة والمحفوظة بأمان في التخزين الدائم", color = StudioTextSecondary, fontSize = 10.sp)
                    }
                }
            }
        }

        // 2. Import Action Buttons
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = {
                        videoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = StudioRed),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Movie, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("استيراد فيديو", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = StudioBlue),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("استيراد صورة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // 3. Filter Chips
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("ALL" to "الكل (${mediaItems.size})", "VIDEO" to "فيديوهات", "IMAGE" to "صور", "AUDIO" to "صوتيات").forEach { (f, label) ->
                    FilterChip(
                        selected = selectedFilter == f,
                        onClick = { selectedFilter = f },
                        label = { Text(label, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = StudioBlue,
                            selectedLabelColor = Color.White,
                            containerColor = StudioNavySurface,
                            labelColor = StudioTextSecondary
                        )
                    )
                }
            }
        }

        // 4. Media List Items
        if (filteredList.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = StudioTextMuted, modifier = Modifier.size(40.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("لا توجد ملفات وسائط في هذا القسم بعد.", color = StudioTextSecondary, fontSize = 12.sp)
                        Text("استخدم أزرار الاستيراد أعلاه لإضافة فيديوهات وصور من جهازك.", color = StudioTextMuted, fontSize = 10.sp)
                    }
                }
            }
        } else {
            items(filteredList) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(StudioNavyBorder, StudioNavySurface)))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        when (item.type) {
                                            "VIDEO" -> StudioRed.copy(alpha = 0.2f)
                                            "IMAGE" -> StudioBlue.copy(alpha = 0.2f)
                                            else -> Color(0xFFF77F00).copy(alpha = 0.2f)
                                        }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when (item.type) {
                                        "VIDEO" -> Icons.Default.Movie
                                        "IMAGE" -> Icons.Default.Image
                                        else -> Icons.Default.Audiotrack
                                    },
                                    contentDescription = null,
                                    tint = when (item.type) {
                                        "VIDEO" -> StudioRed
                                        "IMAGE" -> StudioBlueGlow
                                        else -> Color(0xFFF77F00)
                                    },
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = item.name,
                                    color = StudioTextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                val sizeFormatted = if (item.sizeBytes >= 1024 * 1024) {
                                    String.format("%.1f MB", item.sizeBytes.toDouble() / (1024 * 1024))
                                } else {
                                    String.format("%.0f KB", item.sizeBytes.toDouble() / 1024)
                                }
                                Text(
                                    text = "${item.type} • $sizeFormatted",
                                    color = StudioTextSecondary,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(
                                onClick = {
                                    if (item.type == "VIDEO") {
                                        viewModel.setSlideVideo(item.file.absolutePath)
                                    } else if (item.type == "IMAGE") {
                                        viewModel.setSlideImage(item.file.absolutePath)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = StudioNavySurface),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("إدراج بالمشهد", fontSize = 10.sp, color = StudioGoldLight)
                            }

                            Spacer(modifier = Modifier.width(4.dp))

                            IconButton(
                                onClick = {
                                    item.file.delete()
                                    loadLocalMedia()
                                    viewModel.refreshStorageInfo()
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "حذف", tint = StudioTextMuted, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
