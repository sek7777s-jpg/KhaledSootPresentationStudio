package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AspectRatio
import com.example.data.model.ExportBitrateMode
import com.example.data.model.ExportFps
import com.example.data.model.ExportResolution
import com.example.data.model.ExportStatus
import com.example.ui.theme.StudioBlue
import com.example.ui.theme.StudioBlueGlow
import com.example.ui.theme.StudioGold
import com.example.ui.theme.StudioGoldLight
import com.example.ui.theme.StudioNavyBorder
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.StudioRed
import com.example.ui.theme.StudioRedDark
import com.example.ui.theme.StudioSuccess
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.viewmodel.StudioViewModel

@Composable
fun ExportScreen(viewModel: StudioViewModel) {
    val project by viewModel.currentProject.collectAsState()
    val exportState by viewModel.exportState.collectAsState()

    if (project == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("الرجاء اختيار أو إنشاء مشروع للبدء بعملية التصدير", color = StudioTextMuted)
        }
        return
    }

    val activeProject = project!!
    val totalSeconds = activeProject.slides.sumOf { it.durationSeconds }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Info Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(StudioRed, StudioBlue)))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(StudioRed.copy(alpha = 0.2f))
                            .border(1.5.dp, StudioRed, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.MovieCreation, contentDescription = null, tint = StudioRed, modifier = Modifier.size(24.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "نظام التصدير والترميز في الخلفية 3.0",
                            color = StudioTextPrimary,
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "تصدير مستقل ومستمر مع إطفاء الشاشة أو التبديل بين التطبيقات",
                            color = StudioBlueGlow,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            // 1. Active Export Progress Card
            AnimatedVisibility(visible = exportState.status == ExportStatus.RUNNING) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2E)),
                    shape = RoundedCornerShape(14.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(StudioRed, StudioBlue)))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(22.dp),
                                    strokeWidth = 2.5.dp,
                                    color = StudioRed
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "جاري التصدير في الخلفية (خدمة نشطة مع قفل الشاشة)",
                                    color = StudioTextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Button(
                                onClick = { viewModel.cancelBackgroundExport() },
                                colors = ButtonDefaults.buttonColors(containerColor = StudioRedDark),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("إلغاء", fontSize = 10.sp)
                            }
                        }

                        LinearProgressIndicator(
                            progress = { exportState.progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = StudioBlue,
                            trackColor = StudioNavyDark
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = exportState.statusMessage,
                                color = StudioTextSecondary,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            val mins = exportState.elapsedSeconds / 60
                            val secs = exportState.elapsedSeconds % 60
                            Text(
                                text = "${(exportState.progress * 100).toInt()}% • ${String.format("%02d:%02d", mins, secs)}",
                                color = StudioGoldLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // 2. Success Status Card
            AnimatedVisibility(visible = exportState.status == ExportStatus.SUCCESS) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F2B1D)),
                    shape = RoundedCornerShape(14.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(StudioSuccess, StudioBlue)))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StudioSuccess, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "تم اكتمال التصدير والتحقق من صلاحية الملف بنجاح! 🎬",
                                color = Color.White,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            text = "مسار الحفظ: ${exportState.outputDisplayPath}",
                            color = StudioTextSecondary,
                            fontSize = 11.sp
                        )

                        val sizeMb = exportState.outputSizeBytes.toDouble() / (1024 * 1024)
                        Text(
                            text = "حجم الملف النهائي: ${String.format("%.2f MB", sizeMb)}",
                            color = StudioGoldLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { viewModel.openExportedVideo() },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = StudioSuccess),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تشغيل الفيديو", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { viewModel.shareExportedVideo() },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = StudioBlue),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("مشاركة الفيديو", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // 3. Error / Cancelled Status Card
            AnimatedVisibility(visible = exportState.status == ExportStatus.ERROR || exportState.status == ExportStatus.CANCELLED) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = StudioRedDark.copy(alpha = 0.25f)),
                    shape = RoundedCornerShape(14.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(StudioRed, StudioNavyBorder)))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (exportState.status == ExportStatus.CANCELLED) Icons.Default.Close else Icons.Default.Error,
                                contentDescription = null,
                                tint = StudioRed,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (exportState.status == ExportStatus.CANCELLED) "تم إلغاء التصدير" else "تعذر إكمال التصدير",
                                color = StudioTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = exportState.errorMessage ?: exportState.statusMessage,
                            color = StudioTextSecondary,
                            fontSize = 11.sp
                        )
                        OutlinedButton(
                            onClick = { viewModel.resetExportStatus() },
                            modifier = Modifier.align(Alignment.End),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إعادة المحاولة", fontSize = 10.sp)
                        }
                    }
                }
            }

            // 4. Resolution Selection
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("دقة الفيديو وجودة الترميز:", color = StudioGoldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    ExportResolution.values().forEach { res ->
                        val isSelected = activeProject.exportResolution == res
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.updateExportResolution(res) },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) StudioNavySurface else StudioNavyDark
                            ),
                            shape = RoundedCornerShape(8.dp),
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = Brush.horizontalGradient(
                                    listOf(
                                        if (isSelected) StudioBlue else StudioNavyBorder,
                                        if (isSelected) StudioRed else StudioNavyBorder
                                    )
                                )
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = res.titleAr,
                                        color = if (isSelected) StudioTextPrimary else StudioTextSecondary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = res.descriptionAr,
                                        color = StudioTextMuted,
                                        fontSize = 10.sp
                                    )
                                }

                                if (res.isHardwareDemanding) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(StudioGold.copy(alpha = 0.2f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text("فائق العتاد", color = StudioGold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 5. Aspect Ratio Selection
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("نسبة الأبعاد والمنصة المستهدفة:", color = StudioGoldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        AspectRatio.values().forEach { ratio ->
                            val isSelected = activeProject.aspectRatio == ratio
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.updateAspectRatio(ratio) },
                                label = { Text(ratio.iconLabel, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = StudioRed,
                                    selectedLabelColor = Color.White,
                                    containerColor = StudioNavyDark,
                                    labelColor = StudioTextSecondary
                                )
                            )
                        }
                    }
                    Text(
                        text = "المنصة المناسبة: ${activeProject.aspectRatio.platformHint}",
                        color = StudioTextSecondary,
                        fontSize = 10.sp
                    )
                }
            }

            // 6. FPS & Bitrate Mode
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("معدل الإطارات (FPS):", color = StudioGoldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ExportFps.values().forEach { fps ->
                            FilterChip(
                                selected = activeProject.exportFps == fps,
                                onClick = { viewModel.updateExportFps(fps) },
                                label = { Text("${fps.fpsValue} fps", fontSize = 10.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = StudioBlue,
                                    selectedLabelColor = Color.White,
                                    containerColor = StudioNavyDark,
                                    labelColor = StudioTextSecondary
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text("نمط معدل البت (Bitrate):", color = StudioGoldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ExportBitrateMode.values().forEach { mode ->
                            FilterChip(
                                selected = activeProject.exportBitrateMode == mode,
                                onClick = { viewModel.updateExportBitrateMode(mode) },
                                label = { Text(mode.titleAr, fontSize = 10.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = StudioBlue,
                                    selectedLabelColor = Color.White,
                                    containerColor = StudioNavyDark,
                                    labelColor = StudioTextSecondary
                                )
                            )
                        }
                    }
                }
            }

            // 7. Big Start Background Export Button
            Button(
                onClick = { viewModel.startBackgroundExport() },
                enabled = exportState.status != ExportStatus.RUNNING,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = StudioRed),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (exportState.status == ExportStatus.RUNNING) "عملية التصدير جارية في الخلفية..." else "بدء التصدير في الخلفية (H.264 MP4)",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
