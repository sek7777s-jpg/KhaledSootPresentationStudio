package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SlideCanvasView
import com.example.ui.components.TextFormattingPanel
import com.example.ui.theme.StudioBlue
import com.example.ui.theme.StudioBlueGlow
import com.example.ui.theme.StudioGoldLight
import com.example.ui.theme.StudioNavyBorder
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.StudioRed
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.viewmodel.StudioViewModel

@Composable
fun TypographyStudioScreen(viewModel: StudioViewModel) {
    val currentProject by viewModel.currentProject.collectAsState()
    val currentSlide = viewModel.getCurrentSlide()

    if (currentProject == null || currentSlide == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("لا يوجد مشروع نشط، يرجى اختيار أو إنشاء مشروع.", color = StudioTextSecondary)
        }
        return
    }

    val proj = currentProject!!

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Header Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(Color(0xFF7209B7), StudioBlue)))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF7209B7).copy(alpha = 0.2f))
                            .border(1.5.dp, Color(0xFF7209B7), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.TextFields, contentDescription = null, tint = StudioBlueGlow, modifier = Modifier.size(24.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("استوديو النصوص والعناوين والخطوط", color = StudioTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Black)
                        Text("الخطوط العربية الحقيقية (كايرو، تجوال، المراعي، أميري)، أحجام دقيقة، وظلال برودكاست", color = StudioTextSecondary, fontSize = 10.sp)
                    }
                }
            }
        }

        // 2. Live Canvas Preview
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyDark),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(StudioNavyBorder, StudioBlue)))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    SlideCanvasView(
                        slide = currentSlide,
                        project = proj,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(210.dp)
                    )
                }
            }
        }

        // 3. Text Formatting Panel
        item {
            TextFormattingPanel(
                textStyle = currentSlide.textStyle,
                onStyleChange = { viewModel.updateSlideTextStyle(it) }
            )
        }

        // 4. Text Shadow & Background Styles
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("تأثيرات الظل والحدود:", color = StudioGoldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("تفعيل ظل النص البرودكاست (Text Shadow)", color = StudioTextPrimary, fontSize = 12.sp)
                        Switch(
                            checked = currentSlide.textStyle.textShadow,
                            onCheckedChange = {
                                viewModel.updateSlideTextStyle(currentSlide.textStyle.copy(textShadow = it))
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = StudioBlue)
                        )
                    }

                    Text("نمط خلفية النص:", color = StudioTextSecondary, fontSize = 11.sp)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            "TRANSPARENT" to "شفافة حرة",
                            "CARD" to "بطاقة مظللة",
                            "STUDIO_BAR" to "شريط برودكاست"
                        ).forEach { (style, label) ->
                            FilterChip(
                                selected = currentSlide.textStyle.textBgStyle == style,
                                onClick = {
                                    viewModel.updateSlideTextStyle(currentSlide.textStyle.copy(textBgStyle = style))
                                },
                                label = { Text(label, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = StudioBlue,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
