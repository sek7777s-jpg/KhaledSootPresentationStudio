package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StudioFontFamily
import com.example.ui.components.SlideCanvasView
import com.example.ui.theme.StudioBlue
import com.example.ui.theme.StudioGold
import com.example.ui.theme.StudioGoldLight
import com.example.ui.theme.StudioNavyBorder
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.viewmodel.StudioTab
import com.example.ui.viewmodel.StudioViewModel

@Composable
fun DocumentaryStudioScreen(viewModel: StudioViewModel) {
    val currentProject by viewModel.currentProject.collectAsState()
    val currentSlide = viewModel.getCurrentSlide()

    if (currentProject == null || currentSlide == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("لا يوجد مشروع نشط، يرجى اختيار أو إنشاء مشروع.", color = StudioTextSecondary)
        }
        return
    }

    val proj = currentProject!!

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Header Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(StudioGold, Color(0xFF3A2E1E))))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(StudioGold.copy(alpha = 0.2f))
                            .border(1.5.dp, StudioGold, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.HistoryEdu, contentDescription = null, tint = StudioGoldLight, modifier = Modifier.size(24.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("استوديو الأفلام الوثائقية – DOCUMENTARY", color = StudioTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Black)
                        Text("سرد تاريخي سينمائي، اقتباسات معبرة، وتنسيق خط أميري كلاسيكي", color = StudioTextSecondary, fontSize = 10.sp)
                    }
                }
            }
        }

        // 2. Cinematic Preview Monitor
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyDark),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(StudioGold, StudioBlue)))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    SlideCanvasView(
                        slide = currentSlide,
                        project = proj,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(210.dp)
                    )
                }
            }
        }

        // 3. Narrative & Quote Text Editing
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("سرد القصة والاقتباس التاريخي:", color = StudioGoldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    OutlinedTextField(
                        value = currentSlide.title,
                        onValueChange = { viewModel.updateCurrentSlide(currentSlide.copy(title = it)) },
                        label = { Text("عنوان الفصل أو المشهد الوثائقي") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = StudioGold,
                            unfocusedBorderColor = StudioNavyBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = StudioTextPrimary
                        )
                    )

                    OutlinedTextField(
                        value = currentSlide.subtitle,
                        onValueChange = { viewModel.updateCurrentSlide(currentSlide.copy(subtitle = it)) },
                        label = { Text("العنوان الفرعي / الحقبة الزمنية") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = StudioGold,
                            unfocusedBorderColor = StudioNavyBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = StudioTextPrimary
                        )
                    )

                    OutlinedTextField(
                        value = currentSlide.bodyText,
                        onValueChange = { viewModel.updateCurrentSlide(currentSlide.copy(bodyText = it)) },
                        label = { Text("النص السردي أو الاقتباس الموثق") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = StudioGold,
                            unfocusedBorderColor = StudioNavyBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = StudioTextPrimary
                        )
                    )

                    // Quote Author Tag
                    OutlinedTextField(
                        value = currentSlide.lowerThirdName,
                        onValueChange = { viewModel.updateCurrentSlide(currentSlide.copy(lowerThirdName = it, showLowerThird = it.isNotEmpty())) },
                        label = { Text("صاحب الشهادة أو الاقتباس / المؤرخ") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = StudioGold,
                            unfocusedBorderColor = StudioNavyBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = StudioTextPrimary
                        )
                    )
                }
            }
        }

        // 4. Documentary Font & Atmosphere Presets
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("طابع الخط والخلفية السينمائية:", color = StudioGoldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = currentSlide.textStyle.fontFamilyId == StudioFontFamily.AMIRI.id,
                            onClick = {
                                viewModel.updateSlideTextStyle(currentSlide.textStyle.copy(fontFamilyId = StudioFontFamily.AMIRI.id))
                            },
                            label = { Text("خط أميري وثائقي") },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = StudioGold, selectedLabelColor = Color.Black)
                        )

                        FilterChip(
                            selected = currentSlide.textStyle.fontFamilyId == StudioFontFamily.CAIRO.id,
                            onClick = {
                                viewModel.updateSlideTextStyle(currentSlide.textStyle.copy(fontFamilyId = StudioFontFamily.CAIRO.id))
                            },
                            label = { Text("خط كايرو حديث") },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = StudioGold, selectedLabelColor = Color.Black)
                        )
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                viewModel.updateCurrentSlide(currentSlide.copy(bgPresetIndex = 4))
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E2018)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("خلفية دافئة كلاسيكية", fontSize = 11.sp, color = StudioGoldLight)
                        }

                        Button(
                            onClick = {
                                viewModel.playSoundEffect("fx_countdown_chime")
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = StudioNavySurface),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.GraphicEq, contentDescription = null, modifier = Modifier.size(14.dp), tint = StudioGoldLight)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("مؤثر وثائقي", fontSize = 11.sp, color = StudioTextPrimary)
                        }
                    }
                }
            }
        }

        // 5. Actions
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { viewModel.selectTab(StudioTab.VIDEO_TIMELINE) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = StudioBlue),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("ترتيب المشاهد والخط الزمني", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { viewModel.selectTab(StudioTab.EXPORT_HUB) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = StudioGold),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تصدير الفيلم", fontSize = 12.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
