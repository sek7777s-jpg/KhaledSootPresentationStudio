package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AboutKhaledSootDialog
import com.example.ui.theme.StudioBlue
import com.example.ui.theme.StudioBlueGlow
import com.example.ui.theme.StudioGold
import com.example.ui.theme.StudioGoldLight
import com.example.ui.theme.StudioNavyBorder
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.StudioRed
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.viewmodel.StudioTab
import com.example.ui.viewmodel.StudioViewModel
import kotlinx.coroutines.launch

@Composable
fun MainStudioScreen(viewModel: StudioViewModel) {
    val selectedTab by viewModel.selectedTab.collectAsState()
    val currentProject by viewModel.currentProject.collectAsState()
    val showAbout by viewModel.showAboutDialog.collectAsState()

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var showNewProjectDialog by remember { mutableStateOf(false) }

    // Handle back button: return to DASHBOARD if on any other tab
    BackHandler(enabled = selectedTab != StudioTab.DASHBOARD) {
        viewModel.selectTab(StudioTab.DASHBOARD)
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            gesturesEnabled = true,
            drawerContent = {
                ModalDrawerSheet(
                    drawerContainerColor = StudioNavyCard,
                    drawerContentColor = StudioTextPrimary,
                    modifier = Modifier.width(320.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Drawer Studio Header
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(StudioNavyDark)
                                    .border(2.dp, StudioRed, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Videocam,
                                    contentDescription = null,
                                    tint = StudioGoldLight,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "استوديو خالد صوت",
                                        color = StudioTextPrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(StudioRed)
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    ) {
                                        Text(text = "3.0", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Text(
                                    text = "إنتاج وتطوير: Khaled Soot",
                                    color = StudioGoldLight,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = StudioNavyBorder)
                        Spacer(modifier = Modifier.height(6.dp))

                        // Group 1: الرئيسية والمشاريع
                        DrawerGroupTitle("الرئيسية والمشاريع")
                        StudioDrawerItem(
                            tab = StudioTab.DASHBOARD,
                            icon = Icons.Default.Dashboard,
                            selected = selectedTab == StudioTab.DASHBOARD,
                            onClick = {
                                viewModel.selectTab(StudioTab.DASHBOARD)
                                scope.launch { drawerState.close() }
                            }
                        )
                        StudioDrawerItem(
                            tab = StudioTab.PROJECTS,
                            icon = Icons.Default.Folder,
                            selected = selectedTab == StudioTab.PROJECTS,
                            onClick = {
                                viewModel.selectTab(StudioTab.PROJECTS)
                                scope.launch { drawerState.close() }
                            }
                        )
                        StudioDrawerItem(
                            tab = StudioTab.NEW_PROJECT,
                            icon = Icons.Default.Add,
                            selected = selectedTab == StudioTab.NEW_PROJECT,
                            onClick = {
                                showNewProjectDialog = true
                                scope.launch { drawerState.close() }
                            }
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        // Group 2: الاستوديوهات الإخبارية والوثائقية
                        DrawerGroupTitle("الاستوديوهات المتخصصة")
                        StudioDrawerItem(
                            tab = StudioTab.BREAKING_NEWS,
                            icon = Icons.Default.Whatshot,
                            selected = selectedTab == StudioTab.BREAKING_NEWS,
                            onClick = {
                                viewModel.selectTab(StudioTab.BREAKING_NEWS)
                                scope.launch { drawerState.close() }
                            }
                        )
                        StudioDrawerItem(
                            tab = StudioTab.NEWS_REPORTS,
                            icon = Icons.Default.LiveTv,
                            selected = selectedTab == StudioTab.NEWS_REPORTS,
                            onClick = {
                                viewModel.selectTab(StudioTab.NEWS_REPORTS)
                                scope.launch { drawerState.close() }
                            }
                        )
                        StudioDrawerItem(
                            tab = StudioTab.DOCUMENTARY,
                            icon = Icons.Default.HistoryEdu,
                            selected = selectedTab == StudioTab.DOCUMENTARY,
                            onClick = {
                                viewModel.selectTab(StudioTab.DOCUMENTARY)
                                scope.launch { drawerState.close() }
                            }
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        // Group 3: المونتاج والتصاميم
                        DrawerGroupTitle("المونتاج والتصميم")
                        StudioDrawerItem(
                            tab = StudioTab.VIDEO_TIMELINE,
                            icon = Icons.Default.Movie,
                            selected = selectedTab == StudioTab.VIDEO_TIMELINE,
                            onClick = {
                                viewModel.selectTab(StudioTab.VIDEO_TIMELINE)
                                scope.launch { drawerState.close() }
                            }
                        )
                        StudioDrawerItem(
                            tab = StudioTab.SLIDE_GRAPHICS,
                            icon = Icons.Default.Slideshow,
                            selected = selectedTab == StudioTab.SLIDE_GRAPHICS,
                            onClick = {
                                viewModel.selectTab(StudioTab.SLIDE_GRAPHICS)
                                scope.launch { drawerState.close() }
                            }
                        )
                        StudioDrawerItem(
                            tab = StudioTab.TYPOGRAPHY_TITLES,
                            icon = Icons.Default.TextFields,
                            selected = selectedTab == StudioTab.TYPOGRAPHY_TITLES,
                            onClick = {
                                viewModel.selectTab(StudioTab.TYPOGRAPHY_TITLES)
                                scope.launch { drawerState.close() }
                            }
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        // Group 4: الصوت والوسائط
                        DrawerGroupTitle("الصوت والمكتبات")
                        StudioDrawerItem(
                            tab = StudioTab.VOICEOVER_AUDIO,
                            icon = Icons.Default.Mic,
                            selected = selectedTab == StudioTab.VOICEOVER_AUDIO,
                            onClick = {
                                viewModel.selectTab(StudioTab.VOICEOVER_AUDIO)
                                scope.launch { drawerState.close() }
                            }
                        )
                        StudioDrawerItem(
                            tab = StudioTab.SOUND_FX_MUSIC,
                            icon = Icons.Default.GraphicEq,
                            selected = selectedTab == StudioTab.SOUND_FX_MUSIC,
                            onClick = {
                                viewModel.selectTab(StudioTab.SOUND_FX_MUSIC)
                                scope.launch { drawerState.close() }
                            }
                        )
                        StudioDrawerItem(
                            tab = StudioTab.MEDIA_LIBRARY,
                            icon = Icons.Default.VideoLibrary,
                            selected = selectedTab == StudioTab.MEDIA_LIBRARY,
                            onClick = {
                                viewModel.selectTab(StudioTab.MEDIA_LIBRARY)
                                scope.launch { drawerState.close() }
                            }
                        )
                        StudioDrawerItem(
                            tab = StudioTab.TEMPLATES_CATALOG,
                            icon = Icons.Default.AutoAwesome,
                            selected = selectedTab == StudioTab.TEMPLATES_CATALOG,
                            onClick = {
                                viewModel.selectTab(StudioTab.TEMPLATES_CATALOG)
                                scope.launch { drawerState.close() }
                            }
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        // Group 5: التصدير والإعدادات
                        DrawerGroupTitle("التصدير والدعم")
                        StudioDrawerItem(
                            tab = StudioTab.EXPORT_HUB,
                            icon = Icons.Default.Download,
                            selected = selectedTab == StudioTab.EXPORT_HUB,
                            onClick = {
                                viewModel.selectTab(StudioTab.EXPORT_HUB)
                                scope.launch { drawerState.close() }
                            }
                        )
                        StudioDrawerItem(
                            tab = StudioTab.SETTINGS_HELP,
                            icon = Icons.Default.Settings,
                            selected = selectedTab == StudioTab.SETTINGS_HELP,
                            onClick = {
                                viewModel.selectTab(StudioTab.SETTINGS_HELP)
                                scope.launch { drawerState.close() }
                            }
                        )

                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }
        ) {
            Scaffold(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.statusBars),
                containerColor = StudioNavyDark,
                topBar = {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
                        shape = RoundedCornerShape(12.dp),
                        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(StudioNavyBorder, StudioNavySurface)))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { scope.launch { drawerState.open() } },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Menu,
                                        contentDescription = "القائمة الرئيسية",
                                        tint = StudioTextPrimary
                                    )
                                }

                                Spacer(modifier = Modifier.width(6.dp))

                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "استوديو خالد صوت",
                                            color = StudioTextPrimary,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(3.dp))
                                                .background(StudioRed)
                                                .padding(horizontal = 4.dp, vertical = 1.dp)
                                        ) {
                                            Text(text = "3.0", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    Text(
                                        text = currentProject?.title ?: "منصة الإنتاج الإعلامي والمونتاج",
                                        color = StudioBlueGlow,
                                        fontSize = 10.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { viewModel.selectTab(StudioTab.EXPORT_HUB) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Download,
                                        contentDescription = "التصدير",
                                        tint = StudioGoldLight,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                IconButton(
                                    onClick = { viewModel.openAboutDialog(true) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = "حول الاستوديو",
                                        tint = StudioBlueGlow,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                },
                bottomBar = {
                    NavigationBar(
                        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars),
                        containerColor = StudioNavyCard,
                        tonalElevation = 8.dp
                    ) {
                        NavigationBarItem(
                            selected = selectedTab == StudioTab.DASHBOARD,
                            onClick = { viewModel.selectTab(StudioTab.DASHBOARD) },
                            icon = { Icon(Icons.Default.Dashboard, contentDescription = null, modifier = Modifier.size(20.dp)) },
                            label = { Text("الرئيسية", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                            colors = navigationBarItemColors()
                        )
                        NavigationBarItem(
                            selected = selectedTab == StudioTab.VIDEO_TIMELINE,
                            onClick = { viewModel.selectTab(StudioTab.VIDEO_TIMELINE) },
                            icon = { Icon(Icons.Default.Movie, contentDescription = null, modifier = Modifier.size(20.dp)) },
                            label = { Text("المونتاج", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                            colors = navigationBarItemColors()
                        )
                        NavigationBarItem(
                            selected = selectedTab == StudioTab.SLIDE_GRAPHICS,
                            onClick = { viewModel.selectTab(StudioTab.SLIDE_GRAPHICS) },
                            icon = { Icon(Icons.Default.Slideshow, contentDescription = null, modifier = Modifier.size(20.dp)) },
                            label = { Text("التصميم", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                            colors = navigationBarItemColors()
                        )
                        NavigationBarItem(
                            selected = selectedTab == StudioTab.VOICEOVER_AUDIO || selectedTab == StudioTab.SOUND_FX_MUSIC,
                            onClick = { viewModel.selectTab(StudioTab.VOICEOVER_AUDIO) },
                            icon = { Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(20.dp)) },
                            label = { Text("الصوت", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                            colors = navigationBarItemColors()
                        )
                        NavigationBarItem(
                            selected = selectedTab == StudioTab.EXPORT_HUB,
                            onClick = { viewModel.selectTab(StudioTab.EXPORT_HUB) },
                            icon = { Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(20.dp)) },
                            label = { Text("التصدير", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                            colors = navigationBarItemColors()
                        )
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    Crossfade(targetState = selectedTab, label = "StudioTabCrossfade") { tab ->
                        when (tab) {
                            StudioTab.DASHBOARD -> DashboardScreen(viewModel = viewModel)
                            StudioTab.PROJECTS -> ProjectsScreen(viewModel = viewModel)
                            StudioTab.NEW_PROJECT -> ProjectsScreen(viewModel = viewModel)
                            StudioTab.BREAKING_NEWS -> BreakingNewsStudioScreen(viewModel = viewModel)
                            StudioTab.NEWS_REPORTS -> TvBroadcastScreen(viewModel = viewModel)
                            StudioTab.DOCUMENTARY -> DocumentaryStudioScreen(viewModel = viewModel)
                            StudioTab.VIDEO_TIMELINE -> VideoTimelineScreen(viewModel = viewModel)
                            StudioTab.SLIDE_GRAPHICS -> SlideEditorScreen(viewModel = viewModel)
                            StudioTab.TYPOGRAPHY_TITLES -> TypographyStudioScreen(viewModel = viewModel)
                            StudioTab.VOICEOVER_AUDIO, StudioTab.SOUND_FX_MUSIC -> AudioStudioScreen(viewModel = viewModel)
                            StudioTab.MEDIA_LIBRARY -> MediaLibraryScreen(viewModel = viewModel)
                            StudioTab.TEMPLATES_CATALOG -> TemplatesCatalogScreen(viewModel = viewModel)
                            StudioTab.EXPORT_HUB -> ExportScreen(viewModel = viewModel)
                            StudioTab.SETTINGS_HELP -> StudioSettingsScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }

        if (showAbout) {
            AboutKhaledSootDialog(onDismiss = { viewModel.openAboutDialog(false) })
        }

        if (showNewProjectDialog) {
            CreateNewProjectDialogV3(
                onDismiss = { showNewProjectDialog = false },
                onCreate = { title, type, ratio, resolution ->
                    viewModel.createNewProject(
                        title = title,
                        type = type,
                        aspectRatio = ratio,
                        resolution = resolution
                    )
                    showNewProjectDialog = false
                }
            )
        }
    }
}

@Composable
private fun navigationBarItemColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = StudioRed,
    selectedTextColor = StudioRed,
    indicatorColor = StudioNavySurface,
    unselectedIconColor = StudioTextMuted,
    unselectedTextColor = StudioTextMuted
)

@Composable
private fun DrawerGroupTitle(title: String) {
    Text(
        text = title,
        color = StudioGoldLight,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
    )
}

@Composable
private fun StudioDrawerItem(
    tab: StudioTab,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    NavigationDrawerItem(
        label = {
            Text(
                text = tab.titleAr,
                fontSize = 12.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
            )
        },
        icon = {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
        },
        selected = selected,
        onClick = onClick,
        colors = NavigationDrawerItemDefaults.colors(
            selectedContainerColor = StudioNavySurface,
            selectedIconColor = StudioRed,
            selectedTextColor = Color.White,
            unselectedContainerColor = Color.Transparent,
            unselectedIconColor = StudioBlueGlow,
            unselectedTextColor = StudioTextSecondary
        ),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.height(44.dp)
    )
}
