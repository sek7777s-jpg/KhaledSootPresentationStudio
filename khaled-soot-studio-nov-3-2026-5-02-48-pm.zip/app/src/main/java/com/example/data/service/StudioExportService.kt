package com.example.data.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.model.ExportResolution
import com.example.data.model.ExportState
import com.example.data.model.ExportStatus
import com.example.data.model.Project
import com.example.data.repository.ProjectRepository
import com.example.data.repository.VideoExporter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

class StudioExportService : Service() {

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.Main + serviceJob)
    private var exportJob: Job? = null
    private var timerJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var videoExporter: VideoExporter

    companion object {
        const val CHANNEL_ID = "khaled_soot_export_channel"
        const val NOTIFICATION_ID = 3001

        const val ACTION_START_EXPORT = "com.example.action.START_EXPORT"
        const val ACTION_CANCEL_EXPORT = "com.example.action.CANCEL_EXPORT"
        const val EXTRA_PROJECT_ID = "extra_project_id"

        private val _exportState = MutableStateFlow(ExportState())
        val exportState: StateFlow<ExportState> = _exportState.asStateFlow()

        @Volatile
        private var isCancellationRequested = false

        fun isCancelled(): Boolean = isCancellationRequested

        fun startExport(context: Context, project: Project) {
            isCancellationRequested = false
            _exportState.value = ExportState(
                status = ExportStatus.RUNNING,
                progress = 0f,
                elapsedSeconds = 0,
                statusMessage = "جاري تهيئة خدمة التصدير في الخلفية...",
                resolution = project.exportResolution
            )

            // Save active project to disk before starting
            CoroutineScope(Dispatchers.IO).launch {
                ProjectRepository(context).saveProject(project)
            }

            val intent = Intent(context, StudioExportService::class.java).apply {
                action = ACTION_START_EXPORT
                putExtra(EXTRA_PROJECT_ID, project.id)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun cancelExport(context: Context) {
            isCancellationRequested = true
            _exportState.value = _exportState.value.copy(
                status = ExportStatus.CANCELLED,
                statusMessage = "تم إلغاء عملية التصدير وحذف الملفات المؤقتة."
            )
            val intent = Intent(context, StudioExportService::class.java).apply {
                action = ACTION_CANCEL_EXPORT
            }
            context.startService(intent)
        }

        fun resetExportState() {
            _exportState.value = ExportState()
            isCancellationRequested = false
        }
    }

    override fun onCreate() {
        super.onCreate()
        videoExporter = VideoExporter(applicationContext)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: return START_NOT_STICKY

        when (action) {
            ACTION_START_EXPORT -> {
                val projectId = intent.getStringExtra(EXTRA_PROJECT_ID) ?: ""
                startForegroundExport(projectId)
            }
            ACTION_CANCEL_EXPORT -> {
                handleCancellation()
            }
        }

        return START_NOT_STICKY
    }

    private fun startForegroundExport(projectId: String) {
        acquireWakeLock()
        val initialNotification = buildNotification(0, 0, "جاري بدء التصدير في الخلفية...")
        startForeground(NOTIFICATION_ID, initialNotification)

        // Elapsed time ticker
        var elapsedSec = 0
        timerJob?.cancel()
        timerJob = serviceScope.launch(Dispatchers.Default) {
            while (isActive && !isCancellationRequested) {
                delay(1000L)
                elapsedSec++
                _exportState.value = _exportState.value.copy(elapsedSeconds = elapsedSec)
            }
        }

        exportJob?.cancel()
        exportJob = serviceScope.launch(Dispatchers.IO) {
            try {
                val repo = ProjectRepository(applicationContext)
                repo.initialize()
                val project = repo.getProjectById(projectId) ?: repo.projects.value.firstOrNull()

                if (project == null) {
                    throw IllegalStateException("لم يتم العثور على بيانات المشروع المحدد للتصدير.")
                }

                _exportState.value = _exportState.value.copy(
                    status = ExportStatus.RUNNING,
                    statusMessage = "بدء تشفير الفيديو بدقة ${project.exportResolution.titleAr}...",
                    resolution = project.exportResolution
                )

                // Run export with cooperative progress updates & cancellation checks
                val exportedFile = videoExporter.exportProjectToMp4Advanced(
                    project = project,
                    onProgress = { progress, message ->
                        val safeProgress = progress.coerceIn(0f, 1f)
                        _exportState.value = _exportState.value.copy(
                            progress = safeProgress,
                            statusMessage = message
                        )
                        updateNotification((safeProgress * 100).toInt(), elapsedSec, message)
                    },
                    isCancelledCheck = { isCancellationRequested }
                )

                if (isCancellationRequested) {
                    handleCancellation()
                    return@launch
                }

                // Strict validation: Verify generated file is complete and playable
                val isValid = verifyExportedVideoFile(exportedFile)
                if (!isValid || exportedFile == null) {
                    throw IllegalStateException("فشل التحقق من سلامة الفيديو النهائي؛ الملف فارغ أو تعذر قراءته.")
                }

                // Retrieve saved MediaStore details from exporter
                val mediaStoreUri = videoExporter.lastExportedUri.value
                val displayPath = videoExporter.lastExportedPathDisplay.value.ifEmpty { exportedFile.absolutePath }

                _exportState.value = _exportState.value.copy(
                    status = ExportStatus.SUCCESS,
                    progress = 1.0f,
                    statusMessage = "تم اكتمال تصدير الفيديو والتحقق من سلامته بنجاح!",
                    outputFile = exportedFile,
                    outputUri = mediaStoreUri,
                    outputDisplayPath = displayPath,
                    outputSizeBytes = exportedFile.length()
                )

                notifySuccessNotification(displayPath)
            } catch (e: Exception) {
                e.printStackTrace()
                if (!isCancellationRequested) {
                    _exportState.value = _exportState.value.copy(
                        status = ExportStatus.ERROR,
                        errorMessage = e.localizedMessage ?: "حدث خطأ غير متوقع أثناء ترميز الفيديو",
                        statusMessage = "تعذر إكمال التصدير."
                    )
                    notifyErrorNotification(e.localizedMessage ?: "خطأ في التصدير")
                }
            } finally {
                timerJob?.cancel()
                releaseWakeLock()
                stopForeground(false)
            }
        }
    }

    private fun handleCancellation() {
        isCancellationRequested = true
        exportJob?.cancel()
        timerJob?.cancel()
        releaseWakeLock()

        _exportState.value = _exportState.value.copy(
            status = ExportStatus.CANCELLED,
            statusMessage = "تم إلغاء التصدير وتنظيف الموارد بنجاح."
        )

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(NOTIFICATION_ID)
        stopForeground(true)
        stopSelf()
    }

    private fun verifyExportedVideoFile(file: File?): Boolean {
        if (file == null || !file.exists() || file.length() < 10_000L) {
            return false
        }
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            val widthStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            val duration = durationStr?.toLongOrNull() ?: 0L
            val width = widthStr?.toIntOrNull() ?: 0
            duration > 500L && width > 0
        } catch (e: Exception) {
            e.printStackTrace()
            false
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "خدمة تصدير استوديو خالد صوت 3.0",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إشعارات تقدم عمليات تصدير الفيديو والتقارير في الخلفية"
                setShowBadge(false)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(progress: Int, elapsedSeconds: Int, status: String): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val cancelIntent = Intent(this, StudioExportService::class.java).apply {
            action = ACTION_CANCEL_EXPORT
        }
        val cancelPendingIntent = PendingIntent.getService(
            this,
            1,
            cancelIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val minutes = elapsedSeconds / 60
        val seconds = elapsedSeconds % 60
        val timeFormatted = String.format("%02d:%02d", minutes, seconds)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("استوديو خالد صوت 3.0: جاري تصدير الفيديو ($progress%)")
            .setContentText("$status | الوقت: $timeFormatted")
            .setProgress(100, progress, false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(contentPendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إلغاء التصدير", cancelPendingIntent)
            .build()
    }

    private fun updateNotification(progress: Int, elapsedSeconds: Int, status: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification(progress, elapsedSeconds, status))
    }

    private fun notifySuccessNotification(displayPath: String) {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("تم اكتمال تصدير الفيديو بنجاح! 🎬")
            .setContentText("تم حفظ الفيديو في معرض الهاتف: $displayPath")
            .setOngoing(false)
            .setAutoCancel(true)
            .setContentIntent(contentPendingIntent)
            .build()

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, notif)
    }

    private fun notifyErrorNotification(errorMsg: String) {
        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("تعذر إكمال تصدير الفيديو")
            .setContentText(errorMsg)
            .setOngoing(false)
            .setAutoCancel(true)
            .build()

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, notif)
    }

    private fun acquireWakeLock() {
        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "KhaledSootStudio:ExportWakeLock")
        }
        wakeLock?.let {
            if (!it.isHeld) {
                it.acquire(30 * 60 * 1000L) // 30 mins max timeout
            }
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let {
            if (it.isHeld) {
                try {
                    it.release()
                } catch (_: Exception) {}
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        releaseWakeLock()
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
