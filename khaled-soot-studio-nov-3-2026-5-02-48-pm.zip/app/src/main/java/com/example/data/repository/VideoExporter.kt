package com.example.data.repository

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.data.model.AspectRatio
import com.example.data.model.ExportBitrateMode
import com.example.data.model.ExportFps
import com.example.data.model.ExportResolution
import com.example.data.model.Project
import com.example.data.model.Slide
import com.example.data.model.StudioFontFamily
import com.example.data.model.TransitionType
import com.example.data.model.VideoDisplayMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer

class VideoExporter(private val context: Context) {

    private val _isExporting = MutableStateFlow(false)
    val isExporting: StateFlow<Boolean> = _isExporting.asStateFlow()

    private val _exportProgress = MutableStateFlow(0f)
    val exportProgress: StateFlow<Float> = _exportProgress.asStateFlow()

    private val _statusMessage = MutableStateFlow("")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private val _lastExportedFile = MutableStateFlow<File?>(null)
    val lastExportedFile: StateFlow<File?> = _lastExportedFile.asStateFlow()

    private val _lastExportedUri = MutableStateFlow<Uri?>(null)
    val lastExportedUri: StateFlow<Uri?> = _lastExportedUri.asStateFlow()

    private val _lastExportedPathDisplay = MutableStateFlow("")
    val lastExportedPathDisplay: StateFlow<String> = _lastExportedPathDisplay.asStateFlow()

    private val _lastExportedSizeBytes = MutableStateFlow(0L)
    val lastExportedSizeBytes: StateFlow<Long> = _lastExportedSizeBytes.asStateFlow()

    private val _exportErrorMessage = MutableStateFlow<String?>(null)
    val exportErrorMessage: StateFlow<String?> = _exportErrorMessage.asStateFlow()

    suspend fun exportProjectToMp4(
        project: Project,
        quality1080p: Boolean = false
    ): File? {
        val targetRes = if (quality1080p) ExportResolution.RES_1080P else project.exportResolution
        val upgradedProject = project.copy(exportResolution = targetRes)
        return exportProjectToMp4Advanced(upgradedProject)
    }

    suspend fun exportProjectToMp4Advanced(
        project: Project,
        onProgress: (Float, String) -> Unit = { _, _ -> },
        isCancelledCheck: () -> Boolean = { false }
    ): File? = withContext(Dispatchers.IO) {
        _isExporting.value = true
        _exportProgress.value = 0f
        _exportErrorMessage.value = null
        val initialMsg = "جاري تهيئة محرك تصدير الفيديو التلفزيوني H.264 بدقة ${project.exportResolution.titleAr}..."
        _statusMessage.value = initialMsg
        onProgress(0f, initialMsg)

        var tempOutputFile: File? = null

        try {
            val exportDir = File(context.filesDir, "exports")
            if (!exportDir.exists()) exportDir.mkdirs()

            val sanitizedTitle = project.title.replace(Regex("[^a-zA-Z0-9ء-ي_]"), "_").take(24)
            tempOutputFile = File(exportDir, "khaled_soot_v3_${sanitizedTitle}_${System.currentTimeMillis()}.mp4")

            // Calculate dimensions based on aspect ratio & resolution
            var (width, height) = project.exportResolution.getDimensions(project.aspectRatio)

            val fps = project.exportFps.fpsValue
            val slides = project.slides.ifEmpty {
                listOf(Slide(title = project.title, subtitle = "استوديو خالد صوت 3.0", durationSeconds = 4))
            }

            var totalFrames = 0
            for (slide in slides) {
                totalFrames += slide.durationSeconds * fps
            }
            totalFrames = totalFrames.coerceAtLeast(fps * 2)

            val startMsg = "بدء تشفير الإطارات وتوليد كودك الفيديو..."
            _statusMessage.value = startMsg
            onProgress(0.02f, startMsg)

            // Encode video frames to MP4 with fallback protection
            val encodeSuccess = try {
                encodeVideoToMp4(project, slides, tempOutputFile, width, height, fps, totalFrames, onProgress, isCancelledCheck)
            } catch (e: Exception) {
                if (project.exportResolution == ExportResolution.RES_4K || project.exportResolution == ExportResolution.RES_2K) {
                    // Fallback to 1080p if hardware codec rejected 4K/2K
                    val fallbackMsg = "العتاد لا يدعم دقة فائقة، جاري التراجع التلقائي إلى 1080p HD لضمان التصدير..."
                    _statusMessage.value = fallbackMsg
                    onProgress(0.05f, fallbackMsg)
                    val (fbW, fbH) = ExportResolution.RES_1080P.getDimensions(project.aspectRatio)
                    encodeVideoToMp4(project, slides, tempOutputFile, fbW, fbH, fps, totalFrames, onProgress, isCancelledCheck)
                } else {
                    throw e
                }
            }

            if (!encodeSuccess || isCancelledCheck()) {
                if (tempOutputFile.exists()) tempOutputFile.delete()
                _statusMessage.value = "تم إلغاء عملية التصدير."
                return@withContext null
            }

            if (!tempOutputFile.exists() || tempOutputFile.length() < 1000) {
                throw IllegalStateException("فشل توليد ملف الفيديو، حجم الملف غير صالح.")
            }

            // Save to Public MediaStore (Movies/KhaledSootStudio)
            val savingMsg = "جاري حفظ الفيديو في معرض الهاتف (Movies/KhaledSootStudio)..."
            _statusMessage.value = savingMsg
            onProgress(0.96f, savingMsg)
            val (mediaStoreUri, publicDisplayPath) = saveVideoToMediaStore(tempOutputFile)

            _exportProgress.value = 1f
            val finishedMsg = "تم اكتمال تصدير الفيديو بنجاح! جاهز للمشاهدة والمشاركة."
            _statusMessage.value = finishedMsg
            onProgress(1f, finishedMsg)

            _lastExportedFile.value = tempOutputFile
            _lastExportedUri.value = mediaStoreUri
            _lastExportedPathDisplay.value = publicDisplayPath
            _lastExportedSizeBytes.value = tempOutputFile.length()

            return@withContext tempOutputFile
        } catch (e: Exception) {
            e.printStackTrace()
            if (tempOutputFile != null && tempOutputFile.exists()) {
                tempOutputFile.delete()
            }
            _exportErrorMessage.value = "فشل التصدير: ${e.localizedMessage ?: "خطأ غير متوقع في ترميز الفيديو"}"
            _statusMessage.value = "تعذر إكمال التصدير. يرجى مراجعة تفاصيل الخطأ."
            _lastExportedFile.value = null
            _lastExportedUri.value = null
            return@withContext null
        } finally {
            _isExporting.value = false
        }
    }

    private fun encodeVideoToMp4(
        project: Project,
        slides: List<Slide>,
        outputFile: File,
        width: Int,
        height: Int,
        fps: Int,
        totalFrames: Int,
        onProgress: (Float, String) -> Unit,
        isCancelledCheck: () -> Boolean
    ): Boolean {
        val mimeType = "video/avc"
        val bitRate = when (project.exportBitrateMode) {
            ExportBitrateMode.HIGH_QUALITY -> if (width >= 1920) 8_000_000 else 4_500_000
            ExportBitrateMode.ECONOMY -> if (width >= 1920) 2_500_000 else 1_600_000
            ExportBitrateMode.AUTO -> if (width >= 1920) 5_000_000 else if (width >= 1280) 3_200_000 else 1_800_000
        }
        val frameDurationUs = 1_000_000L / fps

        val format = MediaFormat.createVideoFormat(mimeType, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar)
            setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }

        val codec = MediaCodec.createEncoderByType(mimeType)
        try {
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        } catch (_: Exception) {
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar)
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        }
        codec.start()

        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var videoTrackIndex = -1
        var muxerStarted = false
        val bufferInfo = MediaCodec.BufferInfo()

        val frameBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val frameCanvas = Canvas(frameBitmap)
        val argbBuffer = IntArray(width * height)
        val yuvBufferSize = width * height * 3 / 2
        val yuvBuffer = ByteArray(yuvBufferSize)

        var globalFrameIndex = 0

        try {
            for (slideIdx in slides.indices) {
                if (isCancelledCheck()) {
                    return false
                }

                val slide = slides[slideIdx]
                val slideFrames = slide.durationSeconds * fps

                val loadedImageBitmap: Bitmap? = if (!slide.imageUri.isNullOrEmpty()) {
                    loadBitmapFromUri(slide.imageUri)
                } else null

                val videoRetriever: android.media.MediaMetadataRetriever? = if (!slide.videoUri.isNullOrEmpty()) {
                    createRetriever(slide.videoUri)
                } else null

                try {
                    for (frameInSlide in 0 until slideFrames) {
                        if (isCancelledCheck()) {
                            return false
                        }

                        val overallProgress = (globalFrameIndex.toFloat() / totalFrames).coerceIn(0f, 0.95f)
                        _exportProgress.value = overallProgress
                        val statusText = "معالجة مشهد ${slideIdx + 1} من ${slides.size} (${(overallProgress * 100).toInt()}%)"
                        _statusMessage.value = statusText
                        if (globalFrameIndex % 5 == 0) {
                            onProgress(overallProgress, statusText)
                        }

                        val videoFrameBitmap: Bitmap? = if (videoRetriever != null) {
                            val startOffsetUs = slide.videoStartOffsetMs * 1000L
                            val frameTimeUs = startOffsetUs + ((frameInSlide * 1_000_000L) / fps)
                            try {
                                videoRetriever.getFrameAtTime(frameTimeUs, android.media.MediaMetadataRetriever.OPTION_CLOSEST)
                            } catch (_: Exception) { null }
                        } else null

                        drawSlideToCanvas(
                            canvas = frameCanvas,
                            project = project,
                            slide = slide,
                            imageBitmap = loadedImageBitmap,
                            videoFrameBitmap = videoFrameBitmap,
                            slideIdx = slideIdx,
                            frameInSlide = frameInSlide,
                            slideFrames = slideFrames,
                            width = width,
                            height = height
                        )

                        frameBitmap.getPixels(argbBuffer, 0, width, 0, 0, width, height)
                        rgbToNv12(argbBuffer, width, height, yuvBuffer)

                        val inputIndex = codec.dequeueInputBuffer(10000L)
                        if (inputIndex >= 0) {
                            val inputBuffer = codec.getInputBuffer(inputIndex)
                            if (inputBuffer != null) {
                                inputBuffer.clear()
                                inputBuffer.put(yuvBuffer)
                                val presentationTimeUs = globalFrameIndex * frameDurationUs
                                codec.queueInputBuffer(inputIndex, 0, yuvBufferSize, presentationTimeUs, 0)
                            }
                        }

                        drainEncoder(codec, muxer, bufferInfo, false, { idx -> videoTrackIndex = idx }, { muxerStarted = true }, muxerStarted)
                        globalFrameIndex++
                    }
                } finally {
                    try {
                        videoRetriever?.release()
                    } catch (_: Exception) {}
                }
            }

            if (isCancelledCheck()) return false

            val eosIndex = codec.dequeueInputBuffer(10000L)
            if (eosIndex >= 0) {
                val inputBuffer = codec.getInputBuffer(eosIndex)
                inputBuffer?.clear()
                val presentationTimeUs = globalFrameIndex * frameDurationUs
                codec.queueInputBuffer(eosIndex, 0, 0, presentationTimeUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            }

            drainEncoder(codec, muxer, bufferInfo, true, { idx -> videoTrackIndex = idx }, { muxerStarted = true }, muxerStarted)
            return true
        } finally {
            try {
                codec.stop()
                codec.release()
            } catch (_: Exception) {}

            try {
                if (muxerStarted) {
                    muxer.stop()
                }
                muxer.release()
            } catch (_: Exception) {}

            try {
                frameBitmap.recycle()
            } catch (_: Exception) {}
        }
    }

    private fun drainEncoder(
        codec: MediaCodec,
        muxer: MediaMuxer,
        bufferInfo: MediaCodec.BufferInfo,
        endOfStream: Boolean,
        onTrackAdded: (Int) -> Unit,
        onMuxerStarted: () -> Unit,
        isMuxerStarted: Boolean
    ) {
        val timeoutUs = 10000L
        var muxerStarted = isMuxerStarted

        while (true) {
            val encoderStatus = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
            if (encoderStatus == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) break
            } else if (encoderStatus == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (muxerStarted) {
                    throw RuntimeException("Format changed after muxer started")
                }
                val newFormat = codec.outputFormat
                val track = muxer.addTrack(newFormat)
                onTrackAdded(track)
                muxer.start()
                muxerStarted = true
                onMuxerStarted()
            } else if (encoderStatus >= 0) {
                val encodedData: ByteBuffer? = codec.getOutputBuffer(encoderStatus)
                if (encodedData != null) {
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                        bufferInfo.size = 0
                    }
                    if (bufferInfo.size != 0 && muxerStarted) {
                        encodedData.position(bufferInfo.offset)
                        encodedData.limit(bufferInfo.offset + bufferInfo.size)
                        muxer.writeSampleData(0, encodedData, bufferInfo)
                    }
                    codec.releaseOutputBuffer(encoderStatus, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        break
                    }
                }
            }
        }
    }

    private fun drawSlideToCanvas(
        canvas: Canvas,
        project: Project,
        slide: Slide,
        imageBitmap: Bitmap?,
        videoFrameBitmap: Bitmap?,
        slideIdx: Int,
        frameInSlide: Int,
        slideFrames: Int,
        width: Int,
        height: Int
    ) {
        val textStyle = slide.textStyle
        val finalTypeface = com.example.ui.theme.getCanvasTypeface(context, textStyle.fontFamilyId, textStyle.isBold)

        // 1. Draw TV Studio Gradient Background
        val (c1, c2) = when (slide.bgPresetIndex % 5) {
            0 -> Pair(Color.parseColor("#070D19"), Color.parseColor("#132238")) // Classic Studio Navy
            1 -> Pair(Color.parseColor("#0F172A"), Color.parseColor("#1E293B")) // Slate Tech Broadcast
            2 -> Pair(Color.parseColor("#1A0A0E"), Color.parseColor("#2D121B")) // Breaking News Crimson Dark
            3 -> Pair(Color.parseColor("#061A14"), Color.parseColor("#0F382B")) // Economic Green Dark
            else -> Pair(Color.parseColor("#1C130E"), Color.parseColor("#2E2018")) // Documentary Warm Vintage
        }

        val bgShader = LinearGradient(0f, 0f, 0f, height.toFloat(), c1, c2, Shader.TileMode.CLAMP)
        val bgPaint = Paint().apply { shader = bgShader }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // 2. Full Background Image or Video (if FULL_BG)
        if (videoFrameBitmap != null && slide.imagePosition == "FULL_BG") {
            drawVideoFrameToCanvas(canvas, videoFrameBitmap, slide, width, height, isFullBg = true)
        } else if (imageBitmap != null && slide.imagePosition == "FULL_BG") {
            val src = Rect(0, 0, imageBitmap.width, imageBitmap.height)
            val dst = Rect(0, 0, width, height)
            val imgPaint = Paint().apply { alpha = 140 }
            canvas.drawBitmap(imageBitmap, src, dst, imgPaint)
        }

        // 3. Grid line accents
        val gridPaint = Paint().apply {
            color = Color.parseColor("#15FFFFFF")
            strokeWidth = 2f
        }
        val stepY = height / 8f
        for (i in 1..7) {
            canvas.drawLine(0f, i * stepY, width.toFloat(), i * stepY, gridPaint)
        }

        // 4. Channel Logo & LIVE badge (Top Bar)
        val topBarH = height * 0.08f
        val logoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FFD166")
            textSize = (topBarH * 0.45f).coerceAtLeast(22f)
            typeface = finalTypeface
            textAlign = Paint.Align.RIGHT
        }
        val logoText = project.broadcastSettings.channelLogoText.ifEmpty { "KHALED SOOT STUDIO" }
        canvas.drawText(logoText, width - (width * 0.05f), topBarH * 0.7f, logoPaint)

        if (slide.showLiveBadge) {
            val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E63946") }
            val bWidth = width * 0.16f
            val bHeight = topBarH * 0.55f
            val bLeft = width * 0.04f
            val bTop = topBarH * 0.25f
            val bRect = RectF(bLeft, bTop, bLeft + bWidth, bTop + bHeight)
            canvas.drawRoundRect(bRect, 8f, 8f, badgePaint)

            val bTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = (bHeight * 0.55f).coerceAtLeast(15f)
                typeface = Typeface.DEFAULT_BOLD
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("● مباشر LIVE", bRect.centerX(), bRect.centerY() + (bTextPaint.textSize * 0.35f), bTextPaint)
        }

        // 5. Video or Image Placement (SPLIT, CENTER, LEFT, RIGHT)
        if (videoFrameBitmap != null && slide.imagePosition != "FULL_BG") {
            drawVideoFrameToCanvas(canvas, videoFrameBitmap, slide, width, height, isFullBg = false)
        } else if (imageBitmap != null && slide.imagePosition != "FULL_BG") {
            val imgRect = when (slide.imagePosition) {
                "CENTER" -> RectF(width * 0.25f, height * 0.35f, width * 0.75f, height * 0.75f)
                "LEFT" -> RectF(width * 0.05f, height * 0.25f, width * 0.40f, height * 0.75f)
                "RIGHT" -> RectF(width * 0.60f, height * 0.25f, width * 0.95f, height * 0.75f)
                else -> RectF(width * 0.05f, height * 0.30f, width * 0.45f, height * 0.75f) // SPLIT
            }
            val borderPaint = Paint().apply {
                color = Color.parseColor("#2E3856")
                style = Paint.Style.STROKE
                strokeWidth = 4f
            }
            canvas.drawRoundRect(imgRect, 16f, 16f, borderPaint)
            val src = Rect(0, 0, imageBitmap.width, imageBitmap.height)
            canvas.drawBitmap(imageBitmap, src, imgRect, null)
        }

        // 6. Slide Text Content with Typography settings
        val contentX = when (textStyle.textAlignment) {
            "CENTER" -> width * 0.5f
            "LEFT" -> width * 0.08f
            else -> width * 0.92f // RIGHT (Default RTL)
        }
        val align = when (textStyle.textAlignment) {
            "CENTER" -> Paint.Align.CENTER
            "LEFT" -> Paint.Align.LEFT
            else -> Paint.Align.RIGHT
        }

        val titleColor = try { Color.parseColor(textStyle.textColorHex) } catch (_: Exception) { Color.WHITE }
        val accentColor = try { Color.parseColor(textStyle.accentColorHex) } catch (_: Exception) { Color.parseColor("#00B4D8") }

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = titleColor
            textSize = (height * (textStyle.titleFontSizeSp / 340f)).coerceIn(16f, 90f)
            typeface = finalTypeface
            textAlign = align
            if (textStyle.textShadow) {
                setShadowLayer(8f, 2f, 2f, Color.BLACK)
            }
        }

        val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            textSize = (height * (textStyle.subtitleFontSizeSp / 340f)).coerceIn(12f, 60f)
            typeface = finalTypeface
            textAlign = align
            if (textStyle.textShadow) {
                setShadowLayer(6f, 1f, 1f, Color.BLACK)
            }
        }

        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E0E6ED")
            textSize = (height * (textStyle.bodyFontSizeSp / 340f)).coerceIn(11f, 48f)
            typeface = finalTypeface
            textAlign = align
        }

        var textY = height * 0.22f

        // Optional Text Background Card
        if (textStyle.textBgStyle == "CARD" || textStyle.textBgStyle == "STUDIO_BAR") {
            val cardPaint = Paint().apply { color = Color.parseColor("#AA0C1425") }
            val cardRect = RectF(width * 0.04f, textY - 20f, width * 0.96f, textY + (height * 0.40f))
            canvas.drawRoundRect(cardRect, 14f, 14f, cardPaint)
        }

        if (slide.title.isNotEmpty()) {
            canvas.drawText(slide.title, contentX, textY, titlePaint)
            textY += titlePaint.textSize * 1.35f
        }

        if (slide.subtitle.isNotEmpty()) {
            canvas.drawText(slide.subtitle, contentX, textY, subtitlePaint)
            textY += subtitlePaint.textSize * 1.4f
        }

        if (slide.bodyText.isNotEmpty()) {
            val lines = wrapText(slide.bodyText, bodyPaint, (width * 0.48f).toInt())
            for (line in lines.take(4)) {
                canvas.drawText(line, contentX, textY, bodyPaint)
                textY += bodyPaint.textSize * 1.35f
            }
        }

        // 7. Stat Card (if enabled)
        if (slide.showStatCard && slide.statValue.isNotEmpty()) {
            val statRect = RectF(width * 0.05f, height * 0.50f, width * 0.45f, height * 0.72f)
            val statBgPaint = Paint().apply { color = Color.parseColor("#1A2536") }
            canvas.drawRoundRect(statRect, 14f, 14f, statBgPaint)

            val valPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#FFD166")
                textSize = (statRect.height() * 0.40f).coerceAtLeast(24f)
                typeface = Typeface.DEFAULT_BOLD
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(slide.statValue, statRect.centerX(), statRect.centerY() + (valPaint.textSize * 0.1f), valPaint)

            val lblPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = (statRect.height() * 0.22f).coerceAtLeast(14f)
                typeface = finalTypeface
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(slide.statLabel, statRect.centerX(), statRect.centerY() + (valPaint.textSize * 0.85f), lblPaint)
        }

        // 8. Breaking News Banner (if enabled)
        if (slide.showBreakingBanner && slide.breakingNewsText.isNotEmpty()) {
            val bTop = height * 0.76f
            val bHeight = height * 0.08f
            val bannerRect = RectF(0f, bTop, width.toFloat(), bTop + bHeight)

            val bannerPaint = Paint().apply { color = Color.parseColor("#E63946") }
            canvas.drawRect(bannerRect, bannerPaint)

            val tagPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#800000")
            }
            val tagRect = RectF(width * 0.82f, bTop, width.toFloat(), bTop + bHeight)
            canvas.drawRect(tagRect, tagPaint)

            val tagTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = (bHeight * 0.48f).coerceAtLeast(16f)
                typeface = Typeface.DEFAULT_BOLD
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("عــاجـل", tagRect.centerX(), tagRect.centerY() + (tagTextPaint.textSize * 0.35f), tagTextPaint)

            val bTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = (bHeight * 0.44f).coerceAtLeast(15f)
                typeface = finalTypeface
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText(slide.breakingNewsText, tagRect.left - 20f, tagRect.centerY() + (bTextPaint.textSize * 0.35f), bTextPaint)
        }

        // 9. TV Lower-Third (if enabled)
        if (slide.showLowerThird && slide.lowerThirdName.isNotEmpty()) {
            val ltTop = height * 0.72f
            val ltHeight = height * 0.10f
            val ltRect = RectF(width * 0.45f, ltTop, width * 0.95f, ltTop + ltHeight)

            val ltBg = Paint().apply { color = Color.parseColor("#EE0B132B") }
            canvas.drawRoundRect(ltRect, 10f, 10f, ltBg)

            val redStripe = RectF(ltRect.right - 8f, ltRect.top, ltRect.right, ltRect.bottom)
            val stripePaint = Paint().apply { color = Color.parseColor("#E63946") }
            canvas.drawRect(redStripe, stripePaint)

            val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = (ltHeight * 0.38f).coerceAtLeast(16f)
                typeface = Typeface.DEFAULT_BOLD
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText(slide.lowerThirdName, ltRect.right - 24f, ltRect.top + (ltHeight * 0.45f), namePaint)

            val rolePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#48CAE4")
                textSize = (ltHeight * 0.28f).coerceAtLeast(13f)
                typeface = finalTypeface
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText(slide.lowerThirdRole, ltRect.right - 24f, ltRect.top + (ltHeight * 0.82f), rolePaint)
        }

        // 10. TV Scrolling Ticker (Bottom Bar)
        if (project.broadcastSettings.showTicker) {
            val tickerH = height * 0.07f
            val tickerTop = height - tickerH
            val tickerRect = RectF(0f, tickerTop, width.toFloat(), height.toFloat())

            val tickerBgPaint = Paint().apply { color = Color.parseColor("#D9020814") }
            canvas.drawRect(tickerRect, tickerBgPaint)

            val labelWidth = width * 0.18f
            val labelRect = RectF(width - labelWidth, tickerTop, width.toFloat(), height.toFloat())
            val labelBgPaint = Paint().apply { color = Color.parseColor("#C1121F") }
            canvas.drawRect(labelRect, labelBgPaint)

            val labelTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = (tickerH * 0.45f).coerceAtLeast(14f)
                typeface = Typeface.DEFAULT_BOLD
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("شريط الأخبار", labelRect.centerX(), labelRect.centerY() + (labelTextPaint.textSize * 0.35f), labelTextPaint)

            val tickerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                val colorHex = project.broadcastSettings.tickerTextColorHex
                color = try { Color.parseColor(colorHex) } catch (_: Exception) { Color.WHITE }
                val sp = project.broadcastSettings.tickerFontSizeSp
                textSize = (tickerH * (sp / 26f)).coerceIn(12f, 36f)
                typeface = com.example.ui.theme.getCanvasTypeface(context, project.broadcastSettings.tickerFontFamilyId, false)
                textAlign = Paint.Align.RIGHT
            }

            val speed = project.broadcastSettings.tickerSpeed
            val globalOffset = ((slideIdx * slideFrames + frameInSlide) * 4f * speed) % (width * 1.5f)
            val tickerTextX = labelRect.left - 20f + globalOffset
            canvas.save()
            canvas.clipRect(0f, tickerTop, labelRect.left, height.toFloat())
            canvas.drawText(project.broadcastSettings.tickerText, tickerTextX, tickerRect.centerY() + (tickerPaint.textSize * 0.35f), tickerPaint)
            canvas.restore()
        }
    }

    private fun drawVideoFrameToCanvas(
        canvas: Canvas,
        frame: Bitmap,
        slide: Slide,
        width: Int,
        height: Int,
        isFullBg: Boolean
    ) {
        val targetRect = if (isFullBg || slide.bodyText.isEmpty()) {
            RectF(0f, 0f, width.toFloat(), height.toFloat())
        } else {
            when (slide.imagePosition) {
                "CENTER" -> RectF(width * 0.15f, height * 0.28f, width * 0.85f, height * 0.76f)
                "LEFT" -> RectF(width * 0.05f, height * 0.25f, width * 0.45f, height * 0.75f)
                "RIGHT" -> RectF(width * 0.55f, height * 0.25f, width * 0.95f, height * 0.75f)
                else -> RectF(width * 0.05f, height * 0.28f, width * 0.48f, height * 0.75f)
            }
        }

        when (slide.videoDisplayMode) {
            VideoDisplayMode.FILL -> {
                val scale = maxOf(targetRect.width() / frame.width.toFloat(), targetRect.height() / frame.height.toFloat())
                val scaledW = frame.width * scale
                val scaledH = frame.height * scale
                val left = targetRect.centerX() - scaledW / 2f
                val top = targetRect.centerY() - scaledH / 2f
                val dst = RectF(left, top, left + scaledW, top + scaledH)
                canvas.save()
                canvas.clipRect(targetRect)
                val paint = if (isFullBg) Paint().apply { alpha = 160 } else null
                canvas.drawBitmap(frame, null, dst, paint)
                canvas.restore()
            }
            VideoDisplayMode.FIT -> {
                val scale = minOf(targetRect.width() / frame.width.toFloat(), targetRect.height() / frame.height.toFloat())
                val scaledW = frame.width * scale
                val scaledH = frame.height * scale
                val left = targetRect.centerX() - scaledW / 2f
                val top = targetRect.centerY() - scaledH / 2f
                val dst = RectF(left, top, left + scaledW, top + scaledH)

                if (!isFullBg) {
                    val bgPaint = Paint().apply { color = Color.parseColor("#080D1A") }
                    canvas.drawRoundRect(targetRect, 16f, 16f, bgPaint)
                }
                canvas.drawBitmap(frame, null, dst, null)
                if (!isFullBg) {
                    val borderPaint = Paint().apply {
                        color = Color.parseColor("#E63946")
                        style = Paint.Style.STROKE
                        strokeWidth = 3.5f
                    }
                    canvas.drawRoundRect(targetRect, 16f, 16f, borderPaint)
                }
            }
            VideoDisplayMode.CENTER -> {
                val scale = minOf(targetRect.width() / frame.width.toFloat(), targetRect.height() / frame.height.toFloat()) * 0.9f
                val scaledW = frame.width * scale
                val scaledH = frame.height * scale
                val left = targetRect.centerX() - scaledW / 2f
                val top = targetRect.centerY() - scaledH / 2f
                val dst = RectF(left, top, left + scaledW, top + scaledH)
                canvas.drawBitmap(frame, null, dst, null)
            }
            VideoDisplayMode.CUSTOM -> {
                val baseScale = minOf(targetRect.width() / frame.width.toFloat(), targetRect.height() / frame.height.toFloat())
                val scale = baseScale * slide.videoZoom.coerceIn(0.5f, 2.5f)
                val scaledW = frame.width * scale
                val scaledH = frame.height * scale
                val panOffsetX = (slide.videoPanX * width) / 100f
                val panOffsetY = (slide.videoPanY * height) / 100f
                val left = targetRect.centerX() - scaledW / 2f + panOffsetX
                val top = targetRect.centerY() - scaledH / 2f + panOffsetY
                val dst = RectF(left, top, left + scaledW, top + scaledH)
                canvas.save()
                canvas.clipRect(targetRect)
                val paint = if (isFullBg) Paint().apply { alpha = 160 } else null
                canvas.drawBitmap(frame, null, dst, paint)
                canvas.restore()
            }
        }
    }

    private fun rgbToNv12(argb: IntArray, width: Int, height: Int, outNv12: ByteArray) {
        val frameSize = width * height
        var yIndex = 0
        var uvIndex = frameSize
        var index = 0

        for (j in 0 until height) {
            for (i in 0 until width) {
                val color = argb[index++]
                val R = (color shr 16) and 0xff
                val G = (color shr 8) and 0xff
                val B = color and 0xff

                val Y = ((66 * R + 129 * G + 25 * B + 128) shr 8) + 16
                val U = ((-38 * R - 74 * G + 112 * B + 128) shr 8) + 128
                val V = ((112 * R - 94 * G - 18 * B + 128) shr 8) + 128

                outNv12[yIndex++] = Y.coerceIn(0, 255).toByte()
                if (j % 2 == 0 && i % 2 == 0) {
                    outNv12[uvIndex++] = U.coerceIn(0, 255).toByte()
                    outNv12[uvIndex++] = V.coerceIn(0, 255).toByte()
                }
            }
        }
    }

    private fun loadBitmapFromUri(uriString: String): Bitmap? {
        return try {
            val uri = Uri.parse(uriString)
            if (uri.scheme == "content") {
                context.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it)
                }
            } else {
                val file = File(uriString)
                if (file.exists()) {
                    BitmapFactory.decodeFile(file.absolutePath)
                } else null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun createRetriever(uriString: String?): android.media.MediaMetadataRetriever? {
        if (uriString.isNullOrEmpty()) return null
        return try {
            android.media.MediaMetadataRetriever().apply {
                if (uriString.startsWith("content://")) {
                    setDataSource(context, Uri.parse(uriString))
                } else {
                    val path = if (uriString.startsWith("file://")) uriString.removePrefix("file://") else uriString
                    setDataSource(path)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun wrapText(text: String, paint: Paint, maxWidth: Int): List<String> {
        val words = text.split(" ")
        val lines = mutableListOf<String>()
        var currentLine = ""

        for (word in words) {
            val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
            if (paint.measureText(testLine) <= maxWidth) {
                currentLine = testLine
            } else {
                if (currentLine.isNotEmpty()) lines.add(currentLine)
                currentLine = word
            }
        }
        if (currentLine.isNotEmpty()) lines.add(currentLine)
        return lines
    }

    private fun saveVideoToMediaStore(sourceFile: File): Pair<Uri?, String> {
        val fileName = sourceFile.name
        val relativePath = "Movies/KhaledSootStudio"

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, relativePath)
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }

                val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(sourceFile).use { input ->
                            input.copyTo(out)
                        }
                    }
                    values.clear()
                    values.put(MediaStore.Video.Media.IS_PENDING, 0)
                    context.contentResolver.update(uri, values, null, null)
                    return Pair(uri, "$relativePath/$fileName")
                }
            } else {
                @Suppress("DEPRECATION")
                val moviesDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "KhaledSootStudio")
                if (!moviesDir.exists()) moviesDir.mkdirs()
                val dest = File(moviesDir, fileName)
                sourceFile.copyTo(dest, overwrite = true)
                val contentUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", dest)
                return Pair(contentUri, dest.absolutePath)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val fallbackUri = try {
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", sourceFile)
        } catch (_: Exception) { null }
        return Pair(fallbackUri, sourceFile.absolutePath)
    }

    fun openExportedVideo() {
        val uri = _lastExportedUri.value ?: run {
            val file = _lastExportedFile.value ?: return
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        }

        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "video/mp4")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun shareExportedVideo() {
        val uri = _lastExportedUri.value ?: run {
            val file = _lastExportedFile.value ?: return
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        }

        try {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "تقرير من استوديو خالد صوت 3.0")
                putExtra(Intent.EXTRA_TEXT, "تم إنتاج هذا التقرير الاحترافي بواسطة: استوديو خالد صوت للإنتاج الإعلامي – Khaled Soot Studio 3.0")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(shareIntent, "مشاركة الفيديو عبر...").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
