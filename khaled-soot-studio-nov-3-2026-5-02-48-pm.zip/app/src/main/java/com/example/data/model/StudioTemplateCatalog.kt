package com.example.data.model

import java.util.UUID

data class StudioTemplateItem(
    val id: String,
    val titleAr: String,
    val descriptionAr: String,
    val category: TemplateCategory,
    val projectType: ProjectType,
    val defaultRatio: AspectRatio,
    val defaultResolution: ExportResolution,
    val defaultMusicPreset: String,
    val defaultSoundFxId: String,
    val slidesCount: Int,
    val badgeAr: String,
    val createProject: (title: String) -> Project
)

object StudioTemplateCatalog {

    val templates: List<StudioTemplateItem> = listOf(
        StudioTemplateItem(
            id = "template_breaking_red",
            titleAr = "عاجل أحمر تلفزيوني",
            descriptionAr = "شريط عاجل متوهج باللون القرمزي مع شارات مراسل ومؤثرات صوتية للأخبار الطارئة",
            category = TemplateCategory.TV_NEWS,
            projectType = ProjectType.BREAKING_NEWS,
            defaultRatio = AspectRatio.RATIO_16_9,
            defaultResolution = ExportResolution.RES_1080P,
            defaultMusicPreset = "BREAKING_NEWS",
            defaultSoundFxId = "fx_breaking_news",
            slidesCount = 3,
            badgeAr = "أخبار طارئة",
            createProject = { title ->
                Project(
                    id = UUID.randomUUID().toString(),
                    title = title.ifEmpty { "عاجل طارئ: تغطية مباشرة وحصرية" },
                    projectType = ProjectType.BREAKING_NEWS,
                    aspectRatio = AspectRatio.RATIO_16_9,
                    exportResolution = ExportResolution.RES_1080P,
                    broadcastSettings = BroadcastSettings(
                        channelLogoText = "KHALED SOOT NEWS",
                        channelSubText = "تغطية عاجلة ومباشرة",
                        tickerText = "عاجل: بدء التغطية الميدانية لأبرز الأحداث والمستجدات المتسارعة...",
                        tickerTextColorHex = "#FFFFFF"
                    ),
                    audioConfig = AudioConfig(
                        selectedMusicPreset = "BREAKING_NEWS",
                        selectedSoundFxId = "fx_breaking_news",
                        musicVolume = 0.45f
                    ),
                    slides = listOf(
                        Slide(
                            title = "عاجل: تطورات متسارعة في الميدان",
                            subtitle = "نقل مباشر من مركز الأحداث الرئيسي",
                            bodyText = "متابعة دقيقة للتفاصيل الأولية والبيانات الرسمية الصادرة للتو.",
                            bgPresetIndex = 2,
                            showBreakingBanner = true,
                            breakingNewsText = "عاجل: صدور البيان الرسمي الأول ومؤتمر صحفي مرتقب",
                            showLiveBadge = true,
                            durationSeconds = 6,
                            transition = TransitionType.FADE,
                            textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.CAIRO.id, isBold = true)
                        ),
                        Slide(
                            title = "مراسلنا من موقع الحدث",
                            subtitle = "إحاطة بالواقع الميداني ورصد لردود الفعل",
                            bodyText = "شاهد عيان يؤكد هدوء الأوضاع بعد الإجراءات السريعة المتخذة.",
                            bgPresetIndex = 2,
                            lowerThirdName = "خالد صوت",
                            lowerThirdRole = "موفد الاستوديو الإخباري",
                            showLowerThird = true,
                            showLiveBadge = true,
                            durationSeconds = 6,
                            transition = TransitionType.SLIDE,
                            textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.ALMARAI.id, isBold = true)
                        ),
                        Slide(
                            title = "ملخص المؤشرات والحقائق الميدانية",
                            subtitle = "إحصائيات أولية حول التغطية",
                            bodyText = "الاستوديو مستمر في تقديم النشرات المتتابعة على مدار الساعة.",
                            bgPresetIndex = 2,
                            showStatCard = true,
                            statValue = "100%",
                            statLabel = "جاهزية فرق التغطية الميدانية",
                            durationSeconds = 5,
                            transition = TransitionType.ZOOM,
                            textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.TAJAWAL.id, isBold = true)
                        )
                    )
                )
            }
        ),
        StudioTemplateItem(
            id = "template_doc_cinematic",
            titleAr = "وثائقي سينمائي وتاريخي",
            descriptionAr = "ألوان داكنة دافئة مع خط أميري وسرد متأنٍ ومقاطع أرشيفية متناسقة",
            category = TemplateCategory.HISTORICAL_DOC,
            projectType = ProjectType.DOCUMENTARY,
            defaultRatio = AspectRatio.RATIO_16_9,
            defaultResolution = ExportResolution.RES_1080P,
            defaultMusicPreset = "DOCUMENTARY",
            defaultSoundFxId = "fx_countdown_chime",
            slidesCount = 3,
            badgeAr = "سرد وثائقي",
            createProject = { title ->
                Project(
                    id = UUID.randomUUID().toString(),
                    title = title.ifEmpty { "وثائقي: صفحات من الذاكرة والزمن" },
                    projectType = ProjectType.DOCUMENTARY,
                    aspectRatio = AspectRatio.RATIO_16_9,
                    exportResolution = ExportResolution.RES_1080P,
                    broadcastSettings = BroadcastSettings(
                        channelLogoText = "KHALED SOOT DOC",
                        channelSubText = "أفلام وتحقيقات وثائقية",
                        tickerText = "سلسلة وثائقية حصرية تسلط الضوء على عمق التجربة الإنسانية والتاريخية...",
                        showTicker = false
                    ),
                    audioConfig = AudioConfig(
                        selectedMusicPreset = "DOCUMENTARY",
                        selectedSoundFxId = "fx_countdown_chime",
                        musicVolume = 0.35f
                    ),
                    slides = listOf(
                        Slide(
                            title = "المقدمة: في ظلال الماضي العريق",
                            subtitle = "مدخل تاريخي وسرد استكشافي",
                            bodyText = "حين تتحدث الشواهد الصامتة، تروي الحكايا ما عجزت عنه الكلمات المنقوشة.",
                            bgPresetIndex = 4,
                            durationSeconds = 7,
                            transition = TransitionType.FADE,
                            textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.AMIRI.id, titleFontSizeSp = 22, isBold = true)
                        ),
                        Slide(
                            title = "شهادة شاهد عيان وباحث متخصص",
                            subtitle = "دراسة موثقة من الأرشيف الوطني",
                            bodyText = "«كانت تلك اللحظة نقطة التحول الكبرى التي غيرت مجرى الأحداث في المنطقة برمتها.»",
                            bgPresetIndex = 4,
                            lowerThirdName = "أ.د. عبد الرحمن القاسمي",
                            lowerThirdRole = "مؤرخ وباحث في الدراسات التاريخية",
                            showLowerThird = true,
                            durationSeconds = 7,
                            transition = TransitionType.FADE,
                            textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.AMIRI.id, titleFontSizeSp = 18, isBold = false)
                        ),
                        Slide(
                            title = "الخاتمة: إرث يتوارثه الأجيال",
                            subtitle = "خلاصة الرحلة الاستكشافية",
                            bodyText = "يبقى الأثر شاهداً على عظمة الإرادة الإنسانية وطموحها الذي لا يتوقف.",
                            bgPresetIndex = 4,
                            durationSeconds = 6,
                            transition = TransitionType.ZOOM,
                            textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.AMIRI.id, titleFontSizeSp = 20, isBold = true)
                        )
                    )
                )
            }
        ),
        StudioTemplateItem(
            id = "template_reels_tiktok",
            titleAr = "ريلز وتيك توك عمودي 9:16",
            descriptionAr = "قالب عمودي سريع ومبهر بصرياً للنشر الفوري على إنستغرام ريلز وتيك توك وشورتس",
            category = TemplateCategory.TV_NEWS,
            projectType = ProjectType.SOCIAL_SHORT,
            defaultRatio = AspectRatio.RATIO_9_16,
            defaultResolution = ExportResolution.RES_720P,
            defaultMusicPreset = "ECONOMIC_BEAT",
            defaultSoundFxId = "fx_transition_whoosh",
            slidesCount = 3,
            badgeAr = "سوشيال ميديا 9:16",
            createProject = { title ->
                Project(
                    id = UUID.randomUUID().toString(),
                    title = title.ifEmpty { "ريلز سريع: 3 نصائح لصناعة المحتوى" },
                    projectType = ProjectType.SOCIAL_SHORT,
                    aspectRatio = AspectRatio.RATIO_9_16,
                    exportResolution = ExportResolution.RES_720P,
                    broadcastSettings = BroadcastSettings(
                        channelLogoText = "KHALED SOOT",
                        channelSubText = "إعلام رقمي",
                        showTicker = false
                    ),
                    slides = listOf(
                        Slide(
                            title = "كيف تصنع فيديو احترافي بهاتفك؟",
                            subtitle = "خطوات ذهبية في 15 ثانية",
                            bodyText = "الخطوة الأولى: اعتمد إضاءة متوازنة وصوتاً نقياً قبل أي شيء.",
                            bgPresetIndex = 1,
                            durationSeconds = 5,
                            transition = TransitionType.SLIDE,
                            textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.CAIRO.id, titleFontSizeSp = 22, isBold = true)
                        ),
                        Slide(
                            title = "العناوين البارزة تصنع الفرق",
                            subtitle = "استخدم خط كايرو أو تجوال",
                            bodyText = "تنسيق النص ووضوحه على شاشات الهواتف يضاعف معدل التفاعل مرتين.",
                            bgPresetIndex = 2,
                            durationSeconds = 5,
                            transition = TransitionType.ZOOM,
                            textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.TAJAWAL.id, titleFontSizeSp = 20, isBold = true)
                        ),
                        Slide(
                            title = "تابعنا للمزيد من الإرشادات 🚀",
                            subtitle = "استوديو خالد صوت للإنتاج الإعلامي",
                            bodyText = "احفظ الفيديو وطبّق الخطوات في مشروعك القادم!",
                            bgPresetIndex = 0,
                            durationSeconds = 4,
                            transition = TransitionType.FADE,
                            textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.CAIRO.id, titleFontSizeSp = 22, isBold = true)
                        )
                    )
                )
            }
        ),
        StudioTemplateItem(
            id = "template_investigative",
            titleAr = "تحقيق استقصائي ومستندات",
            descriptionAr = "قالب درامي متخصص في الوثائق والبيانات وتحليل الأدلة الميدانية",
            category = TemplateCategory.HISTORICAL_DOC,
            projectType = ProjectType.INVESTIGATIVE,
            defaultRatio = AspectRatio.RATIO_16_9,
            defaultResolution = ExportResolution.RES_1080P,
            defaultMusicPreset = "DOCUMENTARY",
            defaultSoundFxId = "fx_dramatic_sting",
            slidesCount = 3,
            badgeAr = "استقصائي",
            createProject = { title ->
                Project(
                    id = UUID.randomUUID().toString(),
                    title = title.ifEmpty { "تحقيق استقصائي: خفايا الملف المفتوح" },
                    projectType = ProjectType.INVESTIGATIVE,
                    aspectRatio = AspectRatio.RATIO_16_9,
                    exportResolution = ExportResolution.RES_1080P,
                    broadcastSettings = BroadcastSettings(
                        channelLogoText = "KHALED SOOT INVESTIGATES",
                        channelSubText = "وحدة التحقيقات الخاصة",
                        tickerText = "تحقيق خاص: رصد الأدلة والوثائق الحصرية وراء الكواليس..."
                    ),
                    slides = listOf(
                        Slide(
                            title = "ملف التحقيق: رصد وتتبع المستندات",
                            subtitle = "أدلة حصرية نكشفها لأول مرة",
                            bodyText = "شهور من التحري والتدقيق الميداني تثمر عن كشف شبكة من المعطيات غير المعلنة.",
                            bgPresetIndex = 0,
                            durationSeconds = 6,
                            transition = TransitionType.FADE,
                            textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.CAIRO.id, isBold = true)
                        ),
                        Slide(
                            title = "مقارنة البيانات والتناقضات",
                            subtitle = "تحليل الأرقام والتواريخ الموثقة",
                            bodyText = "مراجعة السجلات الرسمية كشفت فجوات واضحة بين التقارير الأولية والنتائج النهائية.",
                            bgPresetIndex = 1,
                            showStatCard = true,
                            statValue = "47%",
                            statLabel = "فارق في مؤشرات التدقيق",
                            durationSeconds = 6,
                            transition = TransitionType.SLIDE,
                            textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.ALMARAI.id, isBold = true)
                        ),
                        Slide(
                            title = "الخلاصة والنتائج المنتظرة",
                            subtitle = "رأي الخبراء واستشراف الخطوات القانونية",
                            bodyText = "الملف بات في عهدة الجهات المختصة لاستكمال التحقيقات الميدانية.",
                            bgPresetIndex = 0,
                            durationSeconds = 5,
                            transition = TransitionType.ZOOM,
                            textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.TAJAWAL.id, isBold = true)
                        )
                    )
                )
            }
        ),
        StudioTemplateItem(
            id = "template_economic",
            titleAr = "تقرير اقتصادي ومؤشرات 1:1",
            descriptionAr = "قالب مربع مع بطاقات إحصائية ورسوم بيانية لمنشورات المال والأعمال",
            category = TemplateCategory.ECONOMIC,
            projectType = ProjectType.NEWS_REPORT,
            defaultRatio = AspectRatio.RATIO_1_1,
            defaultResolution = ExportResolution.RES_720P,
            defaultMusicPreset = "ECONOMIC_BEAT",
            defaultSoundFxId = "fx_ticker_pulse",
            slidesCount = 2,
            badgeAr = "اقتصاد وأرقام",
            createProject = { title ->
                Project(
                    id = UUID.randomUUID().toString(),
                    title = title.ifEmpty { "تقرير مالي: حركة الأسواق والمؤشرات" },
                    projectType = ProjectType.NEWS_REPORT,
                    aspectRatio = AspectRatio.RATIO_1_1,
                    exportResolution = ExportResolution.RES_720P,
                    broadcastSettings = BroadcastSettings(
                        channelLogoText = "KHALED SOOT ECONOMY",
                        channelSubText = "نشرة الأسواق المالية",
                        tickerText = "مؤشرات البورصة والنفط والذهب تسجل مستويات قياسية جديدة اليوم..."
                    ),
                    slides = listOf(
                        Slide(
                            title = "صعود قياسي في مؤشرات الاستثمار",
                            subtitle = "تقرير أداء الربع السنوي",
                            bodyText = "ارتفاع تدفقات رؤوس الأموال الأجنبية مدعومة بالنمو القوي في قطاعات التقنية.",
                            bgPresetIndex = 3,
                            showStatCard = true,
                            statValue = "+14.8%",
                            statLabel = "نمو الإيرادات التشغيلية",
                            durationSeconds = 6,
                            transition = TransitionType.FADE,
                            textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.TAJAWAL.id, isBold = true)
                        ),
                        Slide(
                            title = "توقعات الربع القادم وسلاسل الإمداد",
                            subtitle = "قراءة تحليلية لكبار الاقتصاديين",
                            bodyText = "تفاؤل حذر مع استقرار أسعار الطاقة ومعدلات التضخم العالمية.",
                            bgPresetIndex = 3,
                            durationSeconds = 6,
                            transition = TransitionType.SLIDE,
                            textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.CAIRO.id, isBold = true)
                        )
                    )
                )
            }
        ),
        StudioTemplateItem(
            id = "template_social_feed_4_5",
            titleAr = "منشور شبكات التواصل 4:5",
            descriptionAr = "نسبة أبعاد 4:5 المثالية لخلاصات إنستغرام وفيسبوك العمودية لجذب تفاعل المتابعين",
            category = TemplateCategory.TV_NEWS,
            projectType = ProjectType.SOCIAL_SHORT,
            defaultRatio = AspectRatio.RATIO_4_5,
            defaultResolution = ExportResolution.RES_720P,
            defaultMusicPreset = "BREAKING_NEWS",
            defaultSoundFxId = "fx_transition_whoosh",
            slidesCount = 2,
            badgeAr = "خلاصات 4:5",
            createProject = { title ->
                Project(
                    id = UUID.randomUUID().toString(),
                    title = title.ifEmpty { "إنفوجرافيك مرئي: ملخص التقرير الميداني" },
                    projectType = ProjectType.SOCIAL_SHORT,
                    aspectRatio = AspectRatio.RATIO_4_5,
                    exportResolution = ExportResolution.RES_720P,
                    broadcastSettings = BroadcastSettings(
                        channelLogoText = "KHALED SOOT",
                        channelSubText = "منشورات الخلاصة 4:5"
                    ),
                    slides = listOf(
                        Slide(
                            title = "أهم 3 أرقام تلخص الحدث اليوم",
                            subtitle = "قراءة بيانية سريعة وموثوقة",
                            bodyText = "تابع هذا العرض السريع للتعرف على كواليس الأرقام وأبعادها.",
                            bgPresetIndex = 1,
                            durationSeconds = 5,
                            transition = TransitionType.FADE,
                            textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.CAIRO.id, isBold = true)
                        ),
                        Slide(
                            title = "الخلاصة وتوصيات الخبراء",
                            subtitle = "شاركنا رأيك في التعليقات",
                            bodyText = "هل تعتقد أن المؤشرات ستواصل صعودها خلال الأشهر المقبلة؟",
                            bgPresetIndex = 0,
                            durationSeconds = 5,
                            transition = TransitionType.ZOOM,
                            textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.ALMARAI.id, isBold = true)
                        )
                    )
                )
            }
        )
    )
}
