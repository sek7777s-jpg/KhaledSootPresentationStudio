package com.example.data.repository

import android.content.Context
import com.example.data.model.AspectRatio
import com.example.data.model.AudioConfig
import com.example.data.model.BroadcastSettings
import com.example.data.model.ExportBitrateMode
import com.example.data.model.ExportFps
import com.example.data.model.ExportResolution
import com.example.data.model.Project
import com.example.data.model.ProjectType
import com.example.data.model.Slide
import com.example.data.model.StudioFontFamily
import com.example.data.model.TemplateCategory
import com.example.data.model.TextStyleConfig
import com.example.data.model.TransitionType
import com.example.data.model.VideoDisplayMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class ProjectRepository(private val context: Context) {

    private val storageFile = File(context.filesDir, "khaled_soot_projects.json")
    private val _projects = MutableStateFlow<List<Project>>(emptyList())
    val projects: StateFlow<List<Project>> = _projects.asStateFlow()

    suspend fun initialize() {
        withContext(Dispatchers.IO) {
            val list = loadFromDisk()
            if (list.isEmpty()) {
                val samples = createSampleProjects()
                saveToDisk(samples)
                _projects.value = samples
            } else {
                _projects.value = list
            }
        }
    }

    suspend fun saveProject(project: Project) {
        withContext(Dispatchers.IO) {
            val currentList = _projects.value.toMutableList()
            val index = currentList.indexOfFirst { it.id == project.id }
            val updatedProject = project.copy(updatedAt = System.currentTimeMillis())
            if (index >= 0) {
                currentList[index] = updatedProject
            } else {
                currentList.add(0, updatedProject)
            }
            saveToDisk(currentList)
            _projects.value = currentList
        }
    }

    suspend fun deleteProject(projectId: String) {
        withContext(Dispatchers.IO) {
            val currentList = _projects.value.filter { it.id != projectId }
            saveToDisk(currentList)
            _projects.value = currentList
        }
    }

    suspend fun duplicateProject(source: Project): Project {
        return withContext(Dispatchers.IO) {
            val duplicated = source.copy(
                id = UUID.randomUUID().toString(),
                title = "${source.title} (نسخة 3.0)",
                slides = source.slides.map { it.copy(id = UUID.randomUUID().toString()) },
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            saveProject(duplicated)
            duplicated
        }
    }

    fun getProjectById(id: String): Project? {
        return _projects.value.firstOrNull { it.id == id }
    }

    private fun loadFromDisk(): List<Project> {
        return try {
            if (!storageFile.exists()) return emptyList()
            val text = storageFile.readText()
            if (text.isBlank()) return emptyList()
            val jsonArray = JSONArray(text)
            val list = mutableListOf<Project>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(deserializeProject(obj))
            }
            list
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    private fun saveToDisk(list: List<Project>) {
        try {
            val jsonArray = JSONArray()
            for (p in list) {
                jsonArray.put(serializeProject(p))
            }
            storageFile.writeText(jsonArray.toString(2))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun serializeProject(p: Project): JSONObject {
        val root = JSONObject()
        root.put("id", p.id)
        root.put("title", p.title)
        root.put("description", p.description)
        root.put("projectType", p.projectType.name)
        root.put("aspectRatio", p.aspectRatio.name)
        root.put("exportResolution", p.exportResolution.name)
        root.put("exportFps", p.exportFps.name)
        root.put("exportBitrateMode", p.exportBitrateMode.name)
        root.put("createdAt", p.createdAt)
        root.put("updatedAt", p.updatedAt)

        // BroadcastSettings
        val bs = JSONObject()
        bs.put("channelLogoText", p.broadcastSettings.channelLogoText)
        bs.put("channelSubText", p.broadcastSettings.channelSubText)
        bs.put("tickerText", p.broadcastSettings.tickerText)
        bs.put("showTicker", p.broadcastSettings.showTicker)
        bs.put("tickerSpeed", p.broadcastSettings.tickerSpeed.toDouble())
        bs.put("studioLocation", p.broadcastSettings.studioLocation)
        bs.put("presenterName", p.broadcastSettings.presenterName)
        bs.put("tickerTextColorHex", p.broadcastSettings.tickerTextColorHex)
        bs.put("tickerFontSizeSp", p.broadcastSettings.tickerFontSizeSp)
        bs.put("tickerFontFamilyId", p.broadcastSettings.tickerFontFamilyId)
        root.put("broadcastSettings", bs)

        // AudioConfig
        val ac = JSONObject()
        ac.put("voiceoverPath", p.audioConfig.voiceoverPath ?: "")
        ac.put("voiceoverDurationMs", p.audioConfig.voiceoverDurationMs)
        ac.put("selectedMusicPreset", p.audioConfig.selectedMusicPreset)
        ac.put("customAudioPath", p.audioConfig.customAudioPath ?: "")
        ac.put("customAudioName", p.audioConfig.customAudioName ?: "")
        ac.put("voiceVolume", p.audioConfig.voiceVolume.toDouble())
        ac.put("musicVolume", p.audioConfig.musicVolume.toDouble())
        ac.put("soundFxVolume", p.audioConfig.soundFxVolume.toDouble())
        ac.put("selectedSoundFxId", p.audioConfig.selectedSoundFxId ?: "")
        ac.put("audioOffsetSec", p.audioConfig.audioOffsetSec.toDouble())
        ac.put("autoDucking", p.audioConfig.autoDucking)
        root.put("audioConfig", ac)

        // Slides
        val slidesArray = JSONArray()
        for (s in p.slides) {
            val so = JSONObject()
            so.put("id", s.id)
            so.put("title", s.title)
            so.put("subtitle", s.subtitle)
            so.put("bodyText", s.bodyText)
            val bp = JSONArray()
            s.bulletPoints.forEach { bp.put(it) }
            so.put("bulletPoints", bp)
            so.put("templateCategory", s.templateCategory.name)
            so.put("bgPresetIndex", s.bgPresetIndex)
            so.put("imageUri", s.imageUri ?: "")
            so.put("videoUri", s.videoUri ?: "")
            val mediaArr = JSONArray()
            s.mediaList.forEach { mediaArr.put(it) }
            so.put("mediaList", mediaArr)
            so.put("imagePosition", s.imagePosition)
            so.put("videoDisplayMode", s.videoDisplayMode.name)
            so.put("videoZoom", s.videoZoom.toDouble())
            so.put("videoPanX", s.videoPanX.toDouble())
            so.put("videoPanY", s.videoPanY.toDouble())
            so.put("videoVolume", s.videoVolume.toDouble())
            so.put("videoStartOffsetMs", s.videoStartOffsetMs)
            so.put("videoEndOffsetMs", s.videoEndOffsetMs)
            so.put("durationSeconds", s.durationSeconds)
            so.put("transition", s.transition.name)
            so.put("lowerThirdName", s.lowerThirdName)
            so.put("lowerThirdRole", s.lowerThirdRole)
            so.put("showLowerThird", s.showLowerThird)
            so.put("showLiveBadge", s.showLiveBadge)
            so.put("breakingNewsText", s.breakingNewsText)
            so.put("showBreakingBanner", s.showBreakingBanner)
            so.put("statValue", s.statValue)
            so.put("statLabel", s.statLabel)
            so.put("showStatCard", s.showStatCard)

            // TextStyleConfig
            val ts = JSONObject()
            ts.put("fontFamilyId", s.textStyle.fontFamilyId)
            ts.put("titleFontSizeSp", s.textStyle.titleFontSizeSp)
            ts.put("subtitleFontSizeSp", s.textStyle.subtitleFontSizeSp)
            ts.put("bodyFontSizeSp", s.textStyle.bodyFontSizeSp)
            ts.put("isBold", s.textStyle.isBold)
            ts.put("textColorHex", s.textStyle.textColorHex)
            ts.put("accentColorHex", s.textStyle.accentColorHex)
            ts.put("textAlignment", s.textStyle.textAlignment)
            ts.put("textShadow", s.textStyle.textShadow)
            ts.put("textOutline", s.textStyle.textOutline)
            ts.put("textBgStyle", s.textStyle.textBgStyle)
            so.put("textStyle", ts)

            slidesArray.put(so)
        }
        root.put("slides", slidesArray)
        return root
    }

    private fun deserializeProject(root: JSONObject): Project {
        val id = root.optString("id", UUID.randomUUID().toString())
        val title = root.optString("title", "مشروع جديد 3.0")
        val description = root.optString("description", "")
        val projectType = try {
            ProjectType.valueOf(root.optString("projectType", ProjectType.NEWS_REPORT.name))
        } catch (_: Exception) {
            ProjectType.NEWS_REPORT
        }
        val aspectRatio = try {
            AspectRatio.valueOf(root.optString("aspectRatio", AspectRatio.RATIO_16_9.name))
        } catch (_: Exception) {
            AspectRatio.RATIO_16_9
        }
        val exportResolution = try {
            ExportResolution.valueOf(root.optString("exportResolution", ExportResolution.RES_720P.name))
        } catch (_: Exception) {
            ExportResolution.RES_720P
        }
        val exportFps = try {
            ExportFps.valueOf(root.optString("exportFps", ExportFps.FPS_25.name))
        } catch (_: Exception) {
            ExportFps.FPS_25
        }
        val exportBitrateMode = try {
            ExportBitrateMode.valueOf(root.optString("exportBitrateMode", ExportBitrateMode.AUTO.name))
        } catch (_: Exception) {
            ExportBitrateMode.AUTO
        }
        val createdAt = root.optLong("createdAt", System.currentTimeMillis())
        val updatedAt = root.optLong("updatedAt", System.currentTimeMillis())

        val bsObj = root.optJSONObject("broadcastSettings")
        val broadcastSettings = if (bsObj != null) {
            BroadcastSettings(
                channelLogoText = bsObj.optString("channelLogoText", "KHALED SOOT STUDIO"),
                channelSubText = bsObj.optString("channelSubText", "صوت الإنتاج الإعلامي 3.0"),
                tickerText = bsObj.optString("tickerText", "استوديو خالد صوت 3.0: التغطية مستمرة والتصدير في الخلفية بنظام H.264..."),
                showTicker = bsObj.optBoolean("showTicker", true),
                tickerSpeed = bsObj.optDouble("tickerSpeed", 1.0).toFloat(),
                studioLocation = bsObj.optString("studioLocation", "الرياض - الاستوديو الرئيسي"),
                presenterName = bsObj.optString("presenterName", "خالد صوت"),
                tickerTextColorHex = bsObj.optString("tickerTextColorHex", "#F8F9FA"),
                tickerFontSizeSp = bsObj.optInt("tickerFontSizeSp", 11),
                tickerFontFamilyId = bsObj.optString("tickerFontFamilyId", StudioFontFamily.CAIRO.id)
            )
        } else BroadcastSettings()

        val acObj = root.optJSONObject("audioConfig")
        val audioConfig = if (acObj != null) {
            val vPath = acObj.optString("voiceoverPath", "")
            val cPath = acObj.optString("customAudioPath", "")
            val cName = acObj.optString("customAudioName", "")
            val sFxId = acObj.optString("selectedSoundFxId", "fx_breaking_news")
            AudioConfig(
                voiceoverPath = if (vPath.isNotEmpty()) vPath else null,
                voiceoverDurationMs = acObj.optLong("voiceoverDurationMs", 0L),
                selectedMusicPreset = acObj.optString("selectedMusicPreset", "BREAKING_NEWS"),
                customAudioPath = if (cPath.isNotEmpty()) cPath else null,
                customAudioName = if (cName.isNotEmpty()) cName else null,
                voiceVolume = acObj.optDouble("voiceVolume", 1.0).toFloat(),
                musicVolume = acObj.optDouble("musicVolume", 0.45).toFloat(),
                soundFxVolume = acObj.optDouble("soundFxVolume", 0.8).toFloat(),
                selectedSoundFxId = if (sFxId.isNotEmpty()) sFxId else null,
                audioOffsetSec = acObj.optDouble("audioOffsetSec", 0.0).toFloat(),
                autoDucking = acObj.optBoolean("autoDucking", true)
            )
        } else AudioConfig()

        val slides = mutableListOf<Slide>()
        val slidesArray = root.optJSONArray("slides")
        if (slidesArray != null) {
            for (i in 0 until slidesArray.length()) {
                val so = slidesArray.getJSONObject(i)
                val bpList = mutableListOf<String>()
                val bpArray = so.optJSONArray("bulletPoints")
                if (bpArray != null) {
                    for (j in 0 until bpArray.length()) {
                        bpList.add(bpArray.getString(j))
                    }
                }

                val mediaList = mutableListOf<String>()
                val mediaArray = so.optJSONArray("mediaList")
                if (mediaArray != null) {
                    for (j in 0 until mediaArray.length()) {
                        mediaList.add(mediaArray.getString(j))
                    }
                }

                val cat = try {
                    TemplateCategory.valueOf(so.optString("templateCategory", TemplateCategory.TV_NEWS.name))
                } catch (_: Exception) {
                    TemplateCategory.TV_NEWS
                }
                val trans = try {
                    TransitionType.valueOf(so.optString("transition", TransitionType.FADE.name))
                } catch (_: Exception) {
                    TransitionType.FADE
                }
                val imgUri = so.optString("imageUri", "")
                val vidUri = so.optString("videoUri", "")
                val vMode = try {
                    VideoDisplayMode.valueOf(
                        so.optString("videoDisplayMode", VideoDisplayMode.FIT.name)
                    )
                } catch (_: Exception) {
                    VideoDisplayMode.FIT
                }
                val vZoom = so.optDouble("videoZoom", 1.0).toFloat()
                val vPanX = so.optDouble("videoPanX", 0.0).toFloat()
                val vPanY = so.optDouble("videoPanY", 0.0).toFloat()
                val vVolume = so.optDouble("videoVolume", 1.0).toFloat()
                val vStartOffset = so.optLong("videoStartOffsetMs", 0L)
                val vEndOffset = so.optLong("videoEndOffsetMs", 0L)

                val tsObj = so.optJSONObject("textStyle")
                val textStyle = if (tsObj != null) {
                    TextStyleConfig(
                        fontFamilyId = tsObj.optString("fontFamilyId", StudioFontFamily.CAIRO.id),
                        titleFontSizeSp = tsObj.optInt("titleFontSizeSp", 20),
                        subtitleFontSizeSp = tsObj.optInt("subtitleFontSizeSp", 14),
                        bodyFontSizeSp = tsObj.optInt("bodyFontSizeSp", 12),
                        isBold = tsObj.optBoolean("isBold", true),
                        textColorHex = tsObj.optString("textColorHex", "#F8F9FA"),
                        accentColorHex = tsObj.optString("accentColorHex", "#00B4D8"),
                        textAlignment = tsObj.optString("textAlignment", "RIGHT"),
                        textShadow = tsObj.optBoolean("textShadow", true),
                        textOutline = tsObj.optBoolean("textOutline", false),
                        textBgStyle = tsObj.optString("textBgStyle", "TRANSPARENT")
                    )
                } else TextStyleConfig()

                slides.add(
                    Slide(
                        id = so.optString("id", UUID.randomUUID().toString()),
                        title = so.optString("title", ""),
                        subtitle = so.optString("subtitle", ""),
                        bodyText = so.optString("bodyText", ""),
                        bulletPoints = bpList,
                        templateCategory = cat,
                        bgPresetIndex = so.optInt("bgPresetIndex", 0),
                        imageUri = if (imgUri.isNotEmpty()) imgUri else null,
                        videoUri = if (vidUri.isNotEmpty()) vidUri else null,
                        mediaList = mediaList,
                        imagePosition = so.optString("imagePosition", "SPLIT"),
                        videoDisplayMode = vMode,
                        videoZoom = vZoom,
                        videoPanX = vPanX,
                        videoPanY = vPanY,
                        videoVolume = vVolume,
                        videoStartOffsetMs = vStartOffset,
                        videoEndOffsetMs = vEndOffset,
                        durationSeconds = so.optInt("durationSeconds", 5),
                        transition = trans,
                        lowerThirdName = so.optString("lowerThirdName", ""),
                        lowerThirdRole = so.optString("lowerThirdRole", ""),
                        showLowerThird = so.optBoolean("showLowerThird", false),
                        showLiveBadge = so.optBoolean("showLiveBadge", true),
                        breakingNewsText = so.optString("breakingNewsText", ""),
                        showBreakingBanner = so.optBoolean("showBreakingBanner", false),
                        statValue = so.optString("statValue", ""),
                        statLabel = so.optString("statLabel", ""),
                        showStatCard = so.optBoolean("showStatCard", false),
                        textStyle = textStyle
                    )
                )
            }
        }

        return Project(
            id = id,
            title = title,
            description = description,
            projectType = projectType,
            aspectRatio = aspectRatio,
            exportResolution = exportResolution,
            exportFps = exportFps,
            exportBitrateMode = exportBitrateMode,
            slides = slides,
            broadcastSettings = broadcastSettings,
            audioConfig = audioConfig,
            createdAt = createdAt,
            updatedAt = updatedAt
        )
    }

    private fun createSampleProjects(): List<Project> {
        val proj1 = Project(
            id = "proj_tv_broadcast_sample_v3",
            title = "خبر عاجل: إطلاق استوديو خالد صوت 3.0 الاحترافي",
            description = "قالب بث إخباري فوري مع عواجل حمراء وشريط سفلي وتصدير في الخلفية",
            projectType = ProjectType.BREAKING_NEWS,
            aspectRatio = AspectRatio.RATIO_16_9,
            exportResolution = ExportResolution.RES_720P,
            broadcastSettings = BroadcastSettings(
                channelLogoText = "KHALED SOOT NEWS",
                channelSubText = "تغطية مباشرة وحصرية 3.0",
                tickerText = "عاجل: إطلاق استوديو خالد صوت 3.0 بدعم التصدير في الخلفية ومحرر فيديو متكامل وحزم خطوط برودكاست...",
                presenterName = "خالد صوت",
                studioLocation = "الرياض - استوديو الأخبار الرئيسي"
            ),
            audioConfig = AudioConfig(
                selectedMusicPreset = "BREAKING_NEWS",
                selectedSoundFxId = "fx_breaking_news",
                voiceVolume = 1.0f,
                musicVolume = 0.45f
            ),
            slides = listOf(
                Slide(
                    title = "عاجل: انطلاق استوديو خالد صوت 3.0",
                    subtitle = "منصة الإنتاج الإعلامي المتكاملة لصناع التقارير والأفلام",
                    bodyText = "يقدم الإصدار 3.0 قفزة تقنية كبرى في مونتاج الفيديو والتصدير في الخلفية بدون انقطاع مع إطفاء الشاشة.",
                    showBreakingBanner = true,
                    breakingNewsText = "عاجل: تقنية التصدير في الخلفية أصبحت تعمل بسلاسة فائقة",
                    showLiveBadge = true,
                    durationSeconds = 6,
                    transition = TransitionType.FADE,
                    textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.CAIRO.id, isBold = true)
                ),
                Slide(
                    title = "تغطية مباشرة من قلب الحدث",
                    subtitle = "مراسلنا الميداني: تقنيات المونتاج والخطوط العربية الحقيقية",
                    bodyText = "دعم كامل للخطوط الأصلية (Cairo, Tajawal, Almarai, Amiri, Montserrat) ونسب الأبعاد 16:9 و9:16 و1:1 و4:5.",
                    lowerThirdName = "خالد صوت",
                    lowerThirdRole = "رئيس التحرير ومقدم التغطية",
                    showLowerThird = true,
                    showLiveBadge = true,
                    durationSeconds = 6,
                    transition = TransitionType.SLIDE,
                    textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.ALMARAI.id, isBold = true)
                ),
                Slide(
                    title = "إحصائيات إنجاز وتطوير الإصدار 3.0",
                    subtitle = "أرقام قياسية في سرعة التشفير وجودة العرض 4K/1080p",
                    bodyText = "استهلاك أدنى للذاكرة والبطارية مع تشفير H.264 عتادي متطور يضمن استمرار التصدير حتى مع قفل الشاشة.",
                    showStatCard = true,
                    statValue = "100%",
                    statLabel = "تصدير مستقل ومستمر في الخلفية",
                    durationSeconds = 5,
                    transition = TransitionType.ZOOM,
                    textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.TAJAWAL.id, isBold = true)
                )
            )
        )

        val proj2 = Project(
            id = "proj_doc_sample_v3",
            title = "وثائقي: رحلة وتاريخ الإعلام التفاعلي",
            description = "سرد تاريخي سينمائي بألوان داكنة وخط أميري وتنسيق نصوص وثائقية",
            projectType = ProjectType.DOCUMENTARY,
            aspectRatio = AspectRatio.RATIO_16_9,
            exportResolution = ExportResolution.RES_1080P,
            broadcastSettings = BroadcastSettings(
                channelLogoText = "KHALED SOOT DOC",
                channelSubText = "أفلام وتحقيقات وثائقية",
                tickerText = "استوديو الأفلام الوثائقية: أرشيف متجدد وسرد تاريخي عميق...",
                presenterName = "خالد صوت"
            ),
            audioConfig = AudioConfig(
                selectedMusicPreset = "DOCUMENTARY",
                selectedSoundFxId = "fx_countdown_chime",
                voiceVolume = 1.0f,
                musicVolume = 0.35f
            ),
            slides = listOf(
                Slide(
                    title = "بين الأمس واليوم: حكاية الكلمة والصورة",
                    subtitle = "الفصل الأول: ولادة استوديوهات البث التلفزيوني",
                    bodyText = "من كاميرات البث التناظري الضخمة إلى الهاتف الذكي الذي أصبح استوديو بث وإنتاج متكامل بين يديك.",
                    bgPresetIndex = 4,
                    durationSeconds = 6,
                    transition = TransitionType.FADE,
                    textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.AMIRI.id, isBold = true)
                ),
                Slide(
                    title = "شهادات تاريخية وأصوات من الميدان",
                    subtitle = "وثائق وتسجيلات حصرية",
                    bodyText = "«لم يعد الاستوديو مجرد جدران وأضواء، بل رؤية وفكر ينقله صانع المحتوى ببراعة.»",
                    lowerThirdName = "د. فهد المعماري",
                    lowerThirdRole = "مؤرخ إعلامي وباحث وثائقي",
                    showLowerThird = true,
                    bgPresetIndex = 4,
                    durationSeconds = 6,
                    transition = TransitionType.FADE,
                    textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.AMIRI.id, isBold = false)
                )
            )
        )

        val proj3 = Project(
            id = "proj_reels_sample_v3",
            title = "ريلز وتيك توك: 5 نصائح لمنتجي الفيديو",
            description = "فيديو عمودي 9:16 سريع للمنصات الرقمية وشبكات التواصل",
            projectType = ProjectType.SOCIAL_SHORT,
            aspectRatio = AspectRatio.RATIO_9_16,
            exportResolution = ExportResolution.RES_720P,
            broadcastSettings = BroadcastSettings(
                channelLogoText = "KHALED SOOT SHORTS",
                channelSubText = "إعلام رقمي سريع",
                tickerText = "تابعوا يوميات استوديو خالد صوت عبر منصات التواصل...",
                showTicker = false
            ),
            slides = listOf(
                Slide(
                    title = "ابدأ بمقدمة تشد الانتباه في أول 3 ثوانٍ",
                    subtitle = "النصيحة الذهبية لزيادة المشاهدات",
                    bodyText = "استخدم العناوين العريضة ذات الألوان المتباينة وشارات العواجل الجذابة.",
                    bgPresetIndex = 1,
                    durationSeconds = 4,
                    transition = TransitionType.ZOOM,
                    textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.CAIRO.id, isBold = true)
                ),
                Slide(
                    title = "الصوت هو نصف الصورة دائماً",
                    subtitle = "اختر مؤثرات صوتية محكمة التوقيت",
                    bodyText = "تسجيل تعليق صوتي نقي واختيار مقطوعة خلفية متناسقة يمنح الفيديو طابع الاحتراف.",
                    bgPresetIndex = 2,
                    durationSeconds = 4,
                    transition = TransitionType.SLIDE,
                    textStyle = TextStyleConfig(fontFamilyId = StudioFontFamily.TAJAWAL.id, isBold = true)
                )
            )
        )

        return listOf(proj1, proj2, proj3)
    }
}
