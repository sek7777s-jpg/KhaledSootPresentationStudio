package com.example.data.model

import java.io.File
import android.net.Uri
import java.util.UUID

enum class AspectRatio(
    val labelAr: String,
    val ratioFloat: Float,
    val iconLabel: String,
    val platformHint: String
) {
    RATIO_16_9("16:9 شاشة تلفزيون وعرض", 16f / 9f, "16:9", "يوتيوب وشاشات التلفزيون 1080p/720p"),
    RATIO_9_16("9:16 ريلز وتيك توك", 9f / 16f, "9:16", "ريلز إنستغرام، تيك توك، يوتيوب شورتس"),
    RATIO_1_1("1:1 منشورات مربعة", 1f, "1:1", "منشورات فيسبوك وإنستغرام"),
    RATIO_4_5("4:5 منشورات السوشيال ميديا", 4f / 5f, "4:5", "خلاصات إنستغرام وفيسبوك الرأسية")
}

enum class ExportResolution(
    val titleAr: String,
    val baseWidth: Int,
    val baseHeight: Int,
    val descriptionAr: String,
    val isHardwareDemanding: Boolean = false
) {
    RES_480P("480p SD (سريع وخفيف)", 854, 480, "جودة قياسية مناسبة للمعاينة السريعة والمشاركة السريعة", false),
    RES_720P("720p HD (متوازن)", 1280, 720, "دقة تلفزيونية قياسية عالية متوازنة السرعة والجودة", false),
    RES_1080P("1080p Full HD (احترافي)", 1920, 1080, "أعلى جودة موصى بها للبث وقنوات اليوتيوب والشاشات", false),
    RES_2K("2K QHD (فائق)", 2560, 1440, "دقة فائقة الوضوح (تتطلب عتاد معالجة قوي)", true),
    RES_4K("4K Ultra HD (سينمائي)", 3840, 2160, "دقة 4K سينمائية خارقة لأعلى مستويات الإنتاج التلفزيوني", true);

    fun getDimensions(aspectRatio: AspectRatio): Pair<Int, Int> {
        val (w, h) = when (aspectRatio) {
            AspectRatio.RATIO_16_9 -> Pair(baseWidth, baseHeight)
            AspectRatio.RATIO_9_16 -> Pair(baseHeight, baseWidth)
            AspectRatio.RATIO_1_1 -> {
                val size = minOf(baseWidth, baseHeight)
                Pair(size, size)
            }
            AspectRatio.RATIO_4_5 -> {
                val h = baseHeight
                val w = (h * 4) / 5
                Pair(w, h)
            }
        }
        // AVC / H.264 encoders strictly require even dimensions
        val evenW = if (w % 2 != 0) w - 1 else w
        val evenH = if (h % 2 != 0) h - 1 else h
        return Pair(evenW, evenH)
    }
}

enum class ExportFps(val titleAr: String, val fpsValue: Int) {
    FPS_24("24 إطار/ث (طابع سينمائي)", 24),
    FPS_25("25 إطار/ث (بث تلفزيوني PAL)", 25),
    FPS_30("30 إطار/ث (قياسي شاشات)", 30),
    FPS_60("60 إطار/ث (فائق السلاسة)", 60)
}

enum class ExportBitrateMode(val titleAr: String, val descAr: String) {
    AUTO("تلقائي ذكي (موصى به)", "يختار معدل البث الأمثل تلقائياً حسب الدقة"),
    HIGH_QUALITY("جودة بث عليا (High Bitrate)", "أقصى دقة تفاصيل وألوان بأعلى معدل بت"),
    ECONOMY("حجم اقتصادي مضغوط", "ضغط فعال لتوفير مساحة التخزين وسرعة الرفع")
}

enum class ProjectType(
    val titleAr: String,
    val descAr: String,
    val defaultCategory: TemplateCategory,
    val defaultRatio: AspectRatio
) {
    BREAKING_NEWS("خبر عاجل", "عواجل وشارات حمراء عاجلة ونصوص متحركة متدفقة", TemplateCategory.TV_NEWS, AspectRatio.RATIO_16_9),
    NEWS_REPORT("تقرير إخباري", "تقارير مراسلين وشريط سفلي ومعلومات بيانية وإحصائيات", TemplateCategory.TV_NEWS, AspectRatio.RATIO_16_9),
    FIELD_COVERAGE("تغطية ميدانية", "بث خارجي ولقطات حية وشارات مراسل من الموقع", TemplateCategory.TV_NEWS, AspectRatio.RATIO_16_9),
    INVESTIGATIVE("تحقيق استقصائي", "وثائق ومستندات وخرائط وأدلة وسرد تشويقي", TemplateCategory.HISTORICAL_DOC, AspectRatio.RATIO_16_9),
    DOCUMENTARY("فيلم وثائقي", "ألوان سينمائية داكنة واقتباسات وأرشيف تاريخي معبر", TemplateCategory.HISTORICAL_DOC, AspectRatio.RATIO_16_9),
    PRESENTATION("عرض تقديمي", "محاور تدريبية وشرائح تعليمية ونقاط رئيسية منظمة", TemplateCategory.EDUCATIONAL, AspectRatio.RATIO_16_9),
    SOCIAL_SHORT("فيديو قصير للسوشيال ميديا", "ريلز وتيك توك وشورتس عمودي 9:16 سريع وجذاب", TemplateCategory.TV_NEWS, AspectRatio.RATIO_9_16),
    TV_INTRO_OUTRO("مقدمة وخاتمة تلفزيونية", "شارة بداية ونهاية احترافية مع هوية وشعار القناة", TemplateCategory.TV_NEWS, AspectRatio.RATIO_16_9)
}

enum class TransitionType(val titleAr: String) {
    FADE("تلاشي سينمائي"),
    SLIDE("انزلاق تلفزيوني"),
    ZOOM("تكبير ديناميكي"),
    WIPE("مسح استوديو")
}

enum class TemplateCategory(val titleAr: String, val iconDescription: String) {
    TV_NEWS("تقرير إخباري تلفزيوني", "قوالب عواجل وشارات إخبارية"),
    HISTORICAL_DOC("وثائقي وسرد تاريخي", "قوالب سردية وخرائط توضيحية"),
    ECONOMIC("اقتصادي ومؤشرات وأرقام", "نسب بيانية وإحصائيات مالية"),
    EDUCATIONAL("عرض تدريبي وتعليمي", "محاور رئيسية ونقاط استعراض")
}

enum class VideoDisplayMode(
    val id: String,
    val titleAr: String,
    val descAr: String
) {
    FILL("FILL", "ملء الشاشة (Fill / Crop)", "يملأ الشاشة بالكامل مع قص الأطراف عند الحاجة"),
    FIT("FIT", "احتواء كامل (Fit)", "إظهار الفيديو كاملاً دون قص مع خلفية مناسبة"),
    CENTER("CENTER", "توسيط (Center)", "توسيط الفيديو بحجمه المناسب المتناسق"),
    CUSTOM("CUSTOM", "تحكم يدوي (Zoom & Pan)", "تكبير وتصغير وتحريك أفقياً وعمودياً")
}

enum class StudioFontFamily(
    val id: String,
    val titleAr: String,
    val fontResName: String,
    val isArabicNative: Boolean
) {
    CAIRO("CAIRO", "كايرو (Cairo) – خط برودكاست إخباري", "cairo", true),
    TAJAWAL("TAJAWAL", "تجوال (Tajawal) – خط هندسي عصري", "tajawal", true),
    ALMARAI("ALMARAI", "المراعي (Almarai) – خط تلفزيوني وإعلامي", "almarai", true),
    AMIRI("AMIRI", "أميري (Amiri) – خط نسخ وثائقي كلاسيكي", "amiri", true),
    MONTSERRAT("MONTSERRAT", "مونتسيرات (Montserrat) – خط إنجليزي حديث", "montserrat", false),
    SANS_SERIF("SANS_SERIF", "خط النظام الافتراضي (Sans-serif)", "sans", true),
    SERIF("SERIF", "خط النظام الكلاسيكي (Serif)", "serif", true),
    MONOSPACE("MONOSPACE", "خط رقمي برمجي (Monospace)", "mono", false);

    companion object {
        fun fromId(id: String): StudioFontFamily {
            return entries.find { it.id.equals(id, ignoreCase = true) } ?: CAIRO
        }
    }
}

data class TextStyleConfig(
    val fontFamilyId: String = StudioFontFamily.CAIRO.id,
    val titleFontSizeSp: Int = 20,
    val subtitleFontSizeSp: Int = 14,
    val bodyFontSizeSp: Int = 12,
    val isBold: Boolean = true,
    val textColorHex: String = "#F8F9FA",
    val accentColorHex: String = "#00B4D8",
    val textAlignment: String = "RIGHT", // RIGHT, CENTER, LEFT
    val textShadow: Boolean = true,
    val textOutline: Boolean = false,
    val textBgStyle: String = "TRANSPARENT" // TRANSPARENT, CARD, STUDIO_BAR, GRADIENT
)

data class SoundEffectItem(
    val id: String,
    val titleAr: String,
    val categoryAr: String,
    val fileName: String,
    val durationSeconds: Float,
    val descriptionAr: String
)

data class Slide(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val subtitle: String = "",
    val bodyText: String = "",
    val bulletPoints: List<String> = emptyList(),
    val templateCategory: TemplateCategory = TemplateCategory.TV_NEWS,
    val bgPresetIndex: Int = 0,
    val imageUri: String? = null,
    val videoUri: String? = null,
    val mediaList: List<String> = emptyList(),
    val imagePosition: String = "SPLIT", // SPLIT, CENTER, FULL_BG, RIGHT, LEFT
    val videoDisplayMode: VideoDisplayMode = VideoDisplayMode.FIT,
    val videoZoom: Float = 1.0f, // 0.5f to 2.5f
    val videoPanX: Float = 0.0f, // -100f to +100f
    val videoPanY: Float = 0.0f, // -100f to +100f
    val videoVolume: Float = 1.0f, // 0.0f to 1.0f (sound level of imported video)
    val videoStartOffsetMs: Long = 0L, // video trimming start
    val videoEndOffsetMs: Long = 0L, // video trimming end (0 means full duration)
    val durationSeconds: Int = 5,
    val transition: TransitionType = TransitionType.FADE,
    val lowerThirdName: String = "",
    val lowerThirdRole: String = "",
    val showLowerThird: Boolean = false,
    val showLiveBadge: Boolean = true,
    val breakingNewsText: String = "",
    val showBreakingBanner: Boolean = false,
    val statValue: String = "",
    val statLabel: String = "",
    val showStatCard: Boolean = false,
    val textStyle: TextStyleConfig = TextStyleConfig()
)

data class BroadcastSettings(
    val channelLogoText: String = "KHALED SOOT STUDIO",
    val channelSubText: String = "صوت الإنتاج الإعلامي 3.0",
    val tickerText: String = "استوديو خالد صوت 3.0: استمرار البث المباشر لأحدث التقارير الوثائقية والإخبارية والتصدير في الخلفية بتقنية H.264 على مدار الساعة...",
    val showTicker: Boolean = true,
    val tickerSpeed: Float = 1.0f,
    val studioLocation: String = "الرياض - الاستوديو الرئيسي",
    val presenterName: String = "خالد صوت",
    val tickerTextColorHex: String = "#F8F9FA",
    val tickerFontSizeSp: Int = 11,
    val tickerFontFamilyId: String = StudioFontFamily.CAIRO.id
)

data class AudioConfig(
    val voiceoverPath: String? = null,
    val voiceoverDurationMs: Long = 0L,
    val selectedMusicPreset: String = "BREAKING_NEWS", // NONE, BREAKING_NEWS, DOCUMENTARY, ECONOMIC_BEAT, CALM_PIANO, CUSTOM
    val customAudioPath: String? = null,
    val customAudioName: String? = null,
    val voiceVolume: Float = 1.0f,
    val musicVolume: Float = 0.45f,
    val soundFxVolume: Float = 0.8f,
    val selectedSoundFxId: String? = "fx_breaking_news",
    val audioOffsetSec: Float = 0f,
    val autoDucking: Boolean = true
)

enum class ExportStatus {
    IDLE,
    RUNNING,
    SUCCESS,
    ERROR,
    CANCELLED
}

data class ExportState(
    val status: ExportStatus = ExportStatus.IDLE,
    val progress: Float = 0f,
    val elapsedSeconds: Int = 0,
    val statusMessage: String = "",
    val outputFile: File? = null,
    val outputUri: Uri? = null,
    val outputDisplayPath: String = "",
    val outputSizeBytes: Long = 0L,
    val resolution: ExportResolution = ExportResolution.RES_720P,
    val errorMessage: String? = null
)

data class Project(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "مشروع إعلامي جديد 3.0",
    val description: String = "",
    val projectType: ProjectType = ProjectType.NEWS_REPORT,
    val aspectRatio: AspectRatio = AspectRatio.RATIO_16_9,
    val exportResolution: ExportResolution = ExportResolution.RES_720P,
    val exportFps: ExportFps = ExportFps.FPS_25,
    val exportBitrateMode: ExportBitrateMode = ExportBitrateMode.AUTO,
    val slides: List<Slide> = emptyList(),
    val broadcastSettings: BroadcastSettings = BroadcastSettings(),
    val audioConfig: AudioConfig = AudioConfig(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
