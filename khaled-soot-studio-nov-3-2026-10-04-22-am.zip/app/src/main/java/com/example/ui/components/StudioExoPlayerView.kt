package com.example.ui.components

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeMute
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.FitScreen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.data.model.VideoDisplayMode
import com.example.ui.theme.StudioBlue
import com.example.ui.theme.StudioBlueGlow
import com.example.ui.theme.StudioGold
import com.example.ui.theme.StudioGoldLight
import com.example.ui.theme.StudioNavyBorder
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.StudioRed
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import kotlinx.coroutines.delay
import java.io.File

@OptIn(UnstableApi::class)
@Composable
fun StudioExoVideoPlayer(
    videoPathOrUri: String,
    aspectRatio: Float = 16f / 9f,
    displayMode: VideoDisplayMode = VideoDisplayMode.FIT,
    zoom: Float = 1.0f,
    panX: Float = 0f,
    panY: Float = 0f,
    volume: Float = 1.0f,
    onDisplayModeChanged: (VideoDisplayMode) -> Unit = {},
    onZoomChanged: (Float) -> Unit = {},
    onPanChanged: (Float, Float) -> Unit = { _, _ -> },
    onVolumeChanged: (Float) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    var isPlaying by remember { mutableStateOf(false) }
    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var showAdjustControls by remember { mutableStateOf(false) }

    // Resolve uri cleanly
    val mediaUri = remember(videoPathOrUri) {
        if (videoPathOrUri.startsWith("content://")) {
            Uri.parse(videoPathOrUri)
        } else if (videoPathOrUri.startsWith("file://")) {
            Uri.parse(videoPathOrUri)
        } else {
            Uri.fromFile(File(videoPathOrUri))
        }
    }

    val exoPlayer = remember(context) {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ALL
            playWhenReady = true
        }
    }

    // Bind Player lifecycle
    DisposableEffect(exoPlayer) {
        onDispose {
            exoPlayer.stop()
            exoPlayer.release()
        }
    }

    // Update media item when URI changes
    LaunchedEffect(mediaUri) {
        isLoading = true
        errorMessage = null
        try {
            exoPlayer.stop()
            exoPlayer.clearMediaItems()
            val mediaItem = MediaItem.fromUri(mediaUri)
            exoPlayer.setMediaItem(mediaItem)
            exoPlayer.prepare()
            exoPlayer.play()
        } catch (e: Exception) {
            errorMessage = "تعذر تحميل الفيديو: ${e.localizedMessage ?: "تنسيق غير مدعوم"}"
            isLoading = false
        }
    }

    // Update player volume
    LaunchedEffect(volume) {
        exoPlayer.volume = volume.coerceIn(0f, 1f)
    }

    // Track playback state & progress
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_READY -> {
                        isLoading = false
                        durationMs = exoPlayer.duration.coerceAtLeast(0L)
                    }
                    Player.STATE_BUFFERING -> {
                        isLoading = true
                    }
                    Player.STATE_ENDED -> {
                        isPlaying = false
                    }
                    Player.STATE_IDLE -> {}
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                isLoading = false
                errorMessage = "خطأ في مشغل الفيديو: ${error.message ?: "ملف غير صالح"}"
            }
        }

        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
        }
    }

    // Periodic time ticker for scrubber
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            currentPositionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
            durationMs = exoPlayer.duration.coerceAtLeast(0L)
            delay(250)
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, StudioNavyBorder, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {

            // VIDEO DISPLAY AREA with Zoom & Pan Layer
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(aspectRatio)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black)
                    .clipToBounds(),
                contentAlignment = Alignment.Center
            ) {
                if (errorMessage != null) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = "Error",
                            tint = StudioRed,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = errorMessage ?: "خطأ في قراءة ملف الفيديو",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        IconButton(
                            onClick = {
                                errorMessage = null
                                exoPlayer.prepare()
                                exoPlayer.play()
                            },
                            modifier = Modifier.background(StudioNavySurface, CircleShape)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Retry", tint = StudioGold)
                        }
                    }
                } else {
                    // ExoPlayer View
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                if (displayMode == VideoDisplayMode.CUSTOM) {
                                    scaleX = zoom
                                    scaleY = zoom
                                    translationX = panX * 2.5f
                                    translationY = panY * 2.5f
                                }
                            }
                    ) {
                        AndroidView(
                            factory = { ctx ->
                                PlayerView(ctx).apply {
                                    player = exoPlayer
                                    useController = false
                                    resizeMode = when (displayMode) {
                                        VideoDisplayMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                        VideoDisplayMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                                        VideoDisplayMode.CENTER -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                                        VideoDisplayMode.CUSTOM -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                                    }
                                }
                            },
                            update = { view ->
                                view.player = exoPlayer
                                view.resizeMode = when (displayMode) {
                                    VideoDisplayMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                    VideoDisplayMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                                    VideoDisplayMode.CENTER -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                                    VideoDisplayMode.CUSTOM -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    if (isLoading) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.4f)),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = StudioGold, modifier = Modifier.size(32.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // SCRUBBER & TIMECODE
            val currentSec = currentPositionMs / 1000
            val totalSec = durationMs / 1000
            val timeString = String.format("%02d:%02d / %02d:%02d", currentSec / 60, currentSec % 60, totalSec / 60, totalSec % 60)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "معاينة الفيديو المشغل (ExoPlayer)",
                    color = StudioGoldLight,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = timeString,
                    color = StudioBlueGlow,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Slider(
                value = if (durationMs > 0) (currentPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f,
                onValueChange = { frac ->
                    if (durationMs > 0) {
                        val targetMs = (frac * durationMs).toLong()
                        currentPositionMs = targetMs
                        exoPlayer.seekTo(targetMs)
                    }
                },
                colors = SliderDefaults.colors(
                    thumbColor = StudioRed,
                    activeTrackColor = StudioRed,
                    inactiveTrackColor = StudioNavyBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(26.dp)
            )

            // PLAYBACK BUTTONS: Rewind 5s, Play/Pause, Forward 5s, Volume, Adjust Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Controls Group
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Rewind 5s
                    IconButton(
                        onClick = {
                            val target = (exoPlayer.currentPosition - 5000L).coerceAtLeast(0L)
                            exoPlayer.seekTo(target)
                            currentPositionMs = target
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .background(StudioNavySurface, CircleShape)
                    ) {
                        Icon(Icons.Default.FastRewind, contentDescription = "Rewind 5s", tint = StudioTextPrimary, modifier = Modifier.size(18.dp))
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Play / Pause
                    IconButton(
                        onClick = {
                            if (isPlaying) {
                                exoPlayer.pause()
                            } else {
                                exoPlayer.play()
                            }
                        },
                        modifier = Modifier
                            .size(42.dp)
                            .background(if (isPlaying) StudioRed else StudioBlue, CircleShape)
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Forward 5s
                    IconButton(
                        onClick = {
                            val target = (exoPlayer.currentPosition + 5000L).coerceAtMost(durationMs)
                            exoPlayer.seekTo(target)
                            currentPositionMs = target
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .background(StudioNavySurface, CircleShape)
                    ) {
                        Icon(Icons.Default.FastForward, contentDescription = "Forward 5s", tint = StudioTextPrimary, modifier = Modifier.size(18.dp))
                    }
                }

                // Volume & Custom Adjust Buttons
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            val newVol = if (volume > 0f) 0f else 1.0f
                            onVolumeChanged(newVol)
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .background(if (volume > 0f) StudioNavySurface else StudioRed.copy(alpha = 0.2f), CircleShape)
                    ) {
                        Icon(
                            imageVector = if (volume > 0f) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeMute,
                            contentDescription = "Video Volume",
                            tint = if (volume > 0f) StudioBlueGlow else StudioRed,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    IconButton(
                        onClick = { showAdjustControls = !showAdjustControls },
                        modifier = Modifier
                            .size(36.dp)
                            .background(if (showAdjustControls) StudioBlue else StudioNavySurface, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Adjust",
                            tint = if (showAdjustControls) Color.White else StudioTextPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // VOLUME SLIDER IF UNMUTED
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("مستوى صوت الفيديو:", color = StudioTextMuted, fontSize = 10.sp, modifier = Modifier.width(95.dp))
                Slider(
                    value = volume,
                    onValueChange = onVolumeChanged,
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = StudioBlue,
                        activeTrackColor = StudioBlue,
                        inactiveTrackColor = StudioNavyBorder
                    ),
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("${(volume * 100).toInt()}%", color = StudioGoldLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }

            // VIDEO DISPLAY MODE CHIPS: Fill, Fit, Center, Custom
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                VideoDisplayMode.entries.forEach { mode ->
                    val isSelected = displayMode == mode
                    FilterChip(
                        selected = isSelected,
                        onClick = { onDisplayModeChanged(mode) },
                        label = {
                            Text(
                                text = when (mode) {
                                    VideoDisplayMode.FILL -> "Fill ملء"
                                    VideoDisplayMode.FIT -> "Fit احتواء"
                                    VideoDisplayMode.CENTER -> "Center توسيط"
                                    VideoDisplayMode.CUSTOM -> "Zoom تكبير"
                                },
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = StudioBlue,
                            selectedLabelColor = Color.White,
                            containerColor = StudioNavySurface,
                            labelColor = StudioTextSecondary
                        )
                    )
                }
            }

            // ZOOM & PAN DETAILED CONTROLS (when CUSTOM or showAdjustControls)
            if (showAdjustControls || displayMode == VideoDisplayMode.CUSTOM) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                        .background(StudioNavySurface, RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Text("التحكم اليدوي بأبعاد المقطع (Zoom & Position):", color = StudioGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                    // Zoom slider
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("التكبير (Zoom):", color = StudioTextSecondary, fontSize = 10.sp, modifier = Modifier.width(75.dp))
                        Slider(
                            value = zoom,
                            onValueChange = onZoomChanged,
                            valueRange = 0.5f..2.5f,
                            colors = SliderDefaults.colors(thumbColor = StudioGold, activeTrackColor = StudioGold),
                            modifier = Modifier.weight(1f)
                        )
                        Text(String.format("%.1fx", zoom), color = StudioGoldLight, fontSize = 10.sp, modifier = Modifier.width(36.dp))
                    }

                    // Pan X
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("إزاحة X (أفقي):", color = StudioTextSecondary, fontSize = 10.sp, modifier = Modifier.width(75.dp))
                        Slider(
                            value = panX,
                            onValueChange = { onPanChanged(it, panY) },
                            valueRange = -50f..50f,
                            colors = SliderDefaults.colors(thumbColor = StudioBlueGlow, activeTrackColor = StudioBlueGlow),
                            modifier = Modifier.weight(1f)
                        )
                        Text("${panX.toInt()}", color = StudioBlueGlow, fontSize = 10.sp, modifier = Modifier.width(36.dp))
                    }

                    // Pan Y
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("إزاحة Y (عمودي):", color = StudioTextSecondary, fontSize = 10.sp, modifier = Modifier.width(75.dp))
                        Slider(
                            value = panY,
                            onValueChange = { onPanChanged(panX, it) },
                            valueRange = -50f..50f,
                            colors = SliderDefaults.colors(thumbColor = StudioBlueGlow, activeTrackColor = StudioBlueGlow),
                            modifier = Modifier.weight(1f)
                        )
                        Text("${panY.toInt()}", color = StudioBlueGlow, fontSize = 10.sp, modifier = Modifier.width(36.dp))
                    }
                }
            }
        }
    }
}
