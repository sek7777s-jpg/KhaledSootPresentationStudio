package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.FormatAlignLeft
import androidx.compose.material.icons.automirrored.filled.FormatAlignRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StudioFontFamily
import com.example.data.model.TextStyleConfig
import com.example.ui.theme.StudioBlue
import com.example.ui.theme.StudioBlueGlow
import com.example.ui.theme.StudioGold
import com.example.ui.theme.StudioGoldLight
import com.example.ui.theme.StudioNavyBorder
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.StudioRed
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.getComposeFontFamily

enum class TargetTextElement(val titleAr: String) {
    TITLE("العنوان الرئيسي"),
    SUBTITLE("العنوان الفرعي"),
    BODY("النص والبنود")
}

@Composable
fun TextFormattingPanel(
    textStyle: TextStyleConfig,
    onStyleChange: (TextStyleConfig) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTarget by remember { mutableStateOf(TargetTextElement.TITLE) }

    val presetSizes = listOf(12, 14, 16, 18, 20, 24, 28, 32, 36, 40, 48, 60, 72)

    val currentFontSize = when (selectedTarget) {
        TargetTextElement.TITLE -> textStyle.titleFontSizeSp
        TargetTextElement.SUBTITLE -> textStyle.subtitleFontSizeSp
        TargetTextElement.BODY -> textStyle.bodyFontSizeSp
    }

    fun updateFontSize(newSize: Int) {
        val clamped = newSize.coerceIn(10, 72)
        val updated = when (selectedTarget) {
            TargetTextElement.TITLE -> textStyle.copy(titleFontSizeSp = clamped)
            TargetTextElement.SUBTITLE -> textStyle.copy(subtitleFontSizeSp = clamped)
            TargetTextElement.BODY -> textStyle.copy(bodyFontSizeSp = clamped)
        }
        onStyleChange(updated)
    }

    val colorPresets = listOf(
        Pair("#F8F9FA", "أبيض ناصع"),
        Pair("#FFD166", "ذهبي استوديو"),
        Pair("#00B4D8", "أزرق سماوي"),
        Pair("#E63946", "أحمر عاجل"),
        Pair("#06D6A0", "أخضر اقتصادي"),
        Pair("#CBD5E1", "فضي كلاسيكي")
    )

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Card(
            modifier = modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = StudioNavyCard),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, StudioNavyBorder)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.TextFields,
                            contentDescription = "Text Settings",
                            tint = StudioGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "لوحة التحكم بالنصوص والخطوط الاحترافية (Typography)",
                            color = StudioGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Target Element Tabs: Title, Subtitle, Body
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    TargetTextElement.entries.forEach { target ->
                        val isSelected = selectedTarget == target
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedTarget = target },
                            label = {
                                Text(
                                    text = target.titleAr,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StudioBlue,
                                selectedLabelColor = Color.White,
                                containerColor = StudioNavySurface,
                                labelColor = StudioTextSecondary
                            )
                        )
                    }
                }

                // 1. FONT SIZE CONTROLS (Presets, Buttons, Input, Slider)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(StudioNavySurface, RoundedCornerShape(8.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.FormatSize, contentDescription = "Font Size", tint = StudioBlueGlow, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("حجم خط ${selectedTarget.titleAr}:", color = StudioTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        // Manual number input with +/- buttons
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Minus button
                            IconButton(
                                onClick = { updateFontSize(currentFontSize - 1) },
                                modifier = Modifier
                                    .size(30.dp)
                                    .background(StudioNavyDark, CircleShape)
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = Color.White, modifier = Modifier.size(14.dp))
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            // Manual Text Field
                            var inputVal by remember(currentFontSize) { mutableStateOf(currentFontSize.toString()) }
                            OutlinedTextField(
                                value = inputVal,
                                onValueChange = { newVal ->
                                    val filtered = newVal.filter { it.isDigit() }.take(2)
                                    inputVal = filtered
                                    filtered.toIntOrNull()?.let { updateFontSize(it) }
                                },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                textStyle = androidx.compose.ui.text.TextStyle(
                                    color = StudioGoldLight,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Center
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = StudioGold,
                                    unfocusedBorderColor = StudioNavyBorder,
                                    focusedContainerColor = StudioNavyDark,
                                    unfocusedContainerColor = StudioNavyDark
                                ),
                                modifier = Modifier
                                    .width(52.dp)
                                    .height(34.dp)
                            )

                            Spacer(modifier = Modifier.width(6.dp))

                            // Plus button
                            IconButton(
                                onClick = { updateFontSize(currentFontSize + 1) },
                                modifier = Modifier
                                    .size(30.dp)
                                    .background(StudioNavyDark, CircleShape)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Increase", tint = Color.White, modifier = Modifier.size(14.dp))
                            }
                        }
                    }

                    // Preset Sizes Row (12, 14, 16, 18, 20, 24, 28, 32, 36, 40, 48, 60, 72)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        presetSizes.forEach { sz ->
                            val isPresetSelected = currentFontSize == sz
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isPresetSelected) StudioGold else StudioNavyDark)
                                    .border(1.dp, if (isPresetSelected) StudioGold else StudioNavyBorder, RoundedCornerShape(6.dp))
                                    .clickable { updateFontSize(sz) }
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$sz",
                                    color = if (isPresetSelected) Color.Black else StudioTextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = if (isPresetSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }

                    // Continuous Slider (10 to 72)
                    Slider(
                        value = currentFontSize.toFloat(),
                        onValueChange = { updateFontSize(it.toInt()) },
                        valueRange = 10f..72f,
                        colors = SliderDefaults.colors(
                            thumbColor = StudioGold,
                            activeTrackColor = StudioGold,
                            inactiveTrackColor = StudioNavyBorder
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // 2. FONT FAMILY SELECTION (Cairo, Tajawal, Almarai, Amiri, Montserrat, System)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("اختر نوع الخط المطبق (عربي / إنجليزي):", color = StudioTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StudioFontFamily.entries.forEach { fontItem ->
                            val isSelected = textStyle.fontFamilyId.equals(fontItem.id, ignoreCase = true)
                            val composeFont = getComposeFontFamily(fontItem.id)

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) StudioBlue.copy(alpha = 0.25f) else StudioNavySurface)
                                    .border(
                                        width = if (isSelected) 1.5.dp else 1.dp,
                                        color = if (isSelected) StudioBlueGlow else StudioNavyBorder,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .clickable {
                                        onStyleChange(textStyle.copy(fontFamilyId = fontItem.id))
                                    }
                                    .padding(horizontal = 10.dp, vertical = 8.dp)
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = fontItem.titleAr.substringBefore(" –"),
                                        color = if (isSelected) StudioGoldLight else StudioTextPrimary,
                                        fontSize = 12.sp,
                                        fontFamily = composeFont,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = if (fontItem.isArabicNative) "استوديو خالد صوت" else "Khaled Soot TV",
                                        color = StudioTextMuted,
                                        fontSize = 10.sp,
                                        fontFamily = composeFont
                                    )
                                }
                            }
                        }
                    }
                }

                // 3. STYLE & ALIGNMENT CONTROLS
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Bold Toggle
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (textStyle.isBold) StudioBlue else StudioNavySurface)
                            .clickable { onStyleChange(textStyle.copy(isBold = !textStyle.isBold)) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.FormatBold, contentDescription = "Bold", tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("عريض (Bold)", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Alignment Buttons (Right, Center, Left)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("RIGHT", "CENTER", "LEFT").forEach { align ->
                            val isSelected = textStyle.textAlignment == align
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSelected) StudioBlue else StudioNavySurface)
                                    .border(1.dp, if (isSelected) StudioBlueGlow else StudioNavyBorder, RoundedCornerShape(6.dp))
                                    .clickable { onStyleChange(textStyle.copy(textAlignment = align)) },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when (align) {
                                        "CENTER" -> Icons.Default.FormatAlignCenter
                                        "LEFT" -> Icons.AutoMirrored.Filled.FormatAlignLeft
                                        else -> Icons.AutoMirrored.Filled.FormatAlignRight
                                    },
                                    contentDescription = align,
                                    tint = if (isSelected) Color.White else StudioTextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                // 4. COLOR PALETTE
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("ألوان الخط التلفزيوني:", color = StudioTextSecondary, fontSize = 11.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        colorPresets.forEach { (hex, _) ->
                            val isSelected = textStyle.textColorHex.equals(hex, ignoreCase = true)
                            val parsedColor = try { Color(android.graphics.Color.parseColor(hex)) } catch (_: Exception) { Color.White }
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(parsedColor)
                                    .border(
                                        width = if (isSelected) 2.5.dp else 1.dp,
                                        color = if (isSelected) StudioGold else Color.DarkGray,
                                        shape = CircleShape
                                    )
                                    .clickable { onStyleChange(textStyle.copy(textColorHex = hex)) },
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Selected",
                                        tint = if (hex == "#F8F9FA" || hex == "#FFD166") Color.Black else Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // 5. LIVE PREVIEW CARD
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(StudioNavyDark)
                        .border(1.dp, StudioNavyBorder, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    val previewFont = getComposeFontFamily(textStyle.fontFamilyId)
                    val previewColor = try { Color(android.graphics.Color.parseColor(textStyle.textColorHex)) } catch (_: Exception) { Color.White }
                    val previewAlign = when (textStyle.textAlignment) {
                        "CENTER" -> TextAlign.Center
                        "LEFT" -> TextAlign.Left
                        else -> TextAlign.Right
                    }

                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "معاينة مباشرة للتنسيق:",
                            color = StudioGold,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "استوديو خالد صوت: التغطية التلفزيونية والتقارير الوثائقية",
                            color = previewColor,
                            fontSize = textStyle.titleFontSizeSp.coerceIn(12, 32).sp,
                            fontFamily = previewFont,
                            fontWeight = if (textStyle.isBold) FontWeight.Bold else FontWeight.Normal,
                            textAlign = previewAlign,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}
