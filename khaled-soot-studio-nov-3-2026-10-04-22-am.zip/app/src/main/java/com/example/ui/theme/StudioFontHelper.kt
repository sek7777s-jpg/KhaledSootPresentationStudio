package com.example.ui.theme

import android.content.Context
import android.graphics.Typeface
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.data.model.StudioFontFamily

val CairoFontFamily = FontFamily(Font(R.font.cairo, FontWeight.Normal))
val TajawalFontFamily = FontFamily(Font(R.font.tajawal, FontWeight.Normal))
val AlmaraiFontFamily = FontFamily(Font(R.font.almarai, FontWeight.Normal))
val AmiriFontFamily = FontFamily(Font(R.font.amiri, FontWeight.Normal))
val MontserratFontFamily = FontFamily(Font(R.font.montserrat, FontWeight.Normal))

fun getComposeFontFamily(fontId: String): FontFamily {
    return when (fontId.uppercase()) {
        "CAIRO" -> CairoFontFamily
        "TAJAWAL" -> TajawalFontFamily
        "ALMARAI" -> AlmaraiFontFamily
        "AMIRI" -> AmiriFontFamily
        "MONTSERRAT" -> MontserratFontFamily
        "SERIF" -> FontFamily.Serif
        "MONOSPACE" -> FontFamily.Monospace
        "SANS_SERIF" -> FontFamily.SansSerif
        else -> CairoFontFamily
    }
}

fun getCanvasTypeface(context: Context, fontId: String, isBold: Boolean): Typeface {
    val baseTypeface: Typeface = when (fontId.uppercase()) {
        "CAIRO" -> try {
            ResourcesCompat.getFont(context, R.font.cairo)
        } catch (_: Exception) { null }
        "TAJAWAL" -> try {
            ResourcesCompat.getFont(context, R.font.tajawal)
        } catch (_: Exception) { null }
        "ALMARAI" -> try {
            ResourcesCompat.getFont(context, R.font.almarai)
        } catch (_: Exception) { null }
        "AMIRI" -> try {
            ResourcesCompat.getFont(context, R.font.amiri)
        } catch (_: Exception) { null }
        "MONTSERRAT" -> try {
            ResourcesCompat.getFont(context, R.font.montserrat)
        } catch (_: Exception) { null }
        "SERIF" -> Typeface.SERIF
        "MONOSPACE" -> Typeface.MONOSPACE
        "SANS_SERIF" -> Typeface.SANS_SERIF
        else -> null
    } ?: Typeface.SANS_SERIF

    return if (isBold) {
        Typeface.create(baseTypeface, Typeface.BOLD)
    } else {
        baseTypeface
    }
}
