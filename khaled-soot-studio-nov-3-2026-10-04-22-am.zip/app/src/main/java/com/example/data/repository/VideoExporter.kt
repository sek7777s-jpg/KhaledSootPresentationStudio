package com.example.data.repository

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.data.model.AspectRatio
import com.example.data.model.Project
import com.example.data.model.Slide
import com.example.data.model.StudioFontFamily
import com.example.data.model.TransitionType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer

class VideoExporter(private val context: Context) {

    private val _isExporting = MutableStateFlow(false)
    val isExporting: StateFlow<Boolean> = _isExporting.asStateFlow()

    private val _exportProgress = MutableStateFlow(0f)
    val exportProgress: StateFlow<Float> = _exportProgress.asStateFlow()

    private val _statusMessage = MutableStateFlow("")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private val _lastExportedFile = MutableStateFlow<File?>(null)
    val lastExportedFile: StateFlow<File?> = _lastExportedFile.asStateFlow()

    private val _lastExportedUri = MutableStateFlow<Uri?>(null)
    val lastExportedUri: StateFlow<Uri?> = _lastExportedUri.asStateFlow()

    private val _lastExportedPathDisplay = MutableStateFlow("")
    val lastExportedPathDisplay: StateFlow<String> = _lastExportedPathDisplay.asStateFlow()

    private val _lastExportedSizeBytes = MutableStateFlow(0L)
    val lastExportedSizeBytes: StateFlow<Long> = _lastExportedSizeBytes.asStateFlow()

    private val _exportErrorMessage = MutableStateFlow<String?>(null)
    val exportErrorMessage: StateFlow<String?> = _exportErrorMessage.asStateFlow()

    suspend fun exportProjectToMp4(
        project: Project,
        quality1080p: Boolean = false
    ): File? = withContext(Dispatchers.IO) {
        _isExporting.value = true
        _exportProgress.value = 0f
        _exportErrorMessage.value = null
        _statusMessage.value = "جاري تهيئة محرك تصدير الفيديو التلفزيوني H.264..."

        try {
            val exportDir = File(context.filesDir, "exports")
            if (!exportDir.exists()) exportDir.mkdirs()

            val sanitizedTitle = project.title.replace(Regex("[^a-zA-Z0-9ء-ي_]"), "_").take(24)
            val tempOutputFile = File(exportDir, "khaled_soot_v2_${sanitizedTitle}_${System.currentTimeMillis()}.mp4")

            // Resolutions: Ensure even dimensions required by AVC/H.264
            val (width, height) = when (project.aspectRatio) {
                AspectRatio.RATIO_16_9 -> if (quality1080p) Pair(1920, 1080) else Pair(1280, 720)
                AspectRatio.RATIO_9_16 -> if (quality1080p) Pair(1080, 1920) else Pair(720, 1280)
                AspectRatio.RATIO_1_1 -> if (quality1080p) Pair(1080, 1080) else Pair(720, 720)
            }

            val fps = 25
            val slides = project.slides.ifEmpty {
                listOf(Slide(title = project.title, subtitle = "استوديو خالد صوت 2.0", durationSeconds = 4))
            }

            var totalFrames = 0
            for (slide in slides) {
                totalFrames += slide.durationSeconds * fps
            }
            totalFrames = totalFrames.coerceAtLeast(fps * 2)

            _statusMessage.value = "بدء تشفير الإطارات وتوليد كودك الفيديو..."
            encodeVideoToMp4(project, slides, tempOutputFile, width, height, fps, totalFrames)

            if (!tempOutputFile.exists() || tempOutputFile.length() < 1000) {
                throw IllegalStateException("فشل توليد ملف الفيديو، حجم الملف غير صالح.")
            }

            // Save to Public MediaStore (Movies/KhaledSootStudio)
            _statusMessage.value = "جاري حفظ الفيديو في معرض الهاتف (Movies/KhaledSootStudio)..."
            val (mediaStoreUri, publicDisplayPath) = saveVideoToMediaStore(tempOutputFile)

            _exportProgress.value = 1f
            _statusMessage.value = "تم اكتمال تصدير الفيديو بنجاح! جاهز للمشاهدة والمشاركة."
            _lastExportedFile.value = tempOutputFile
            _lastExportedUri.value = mediaStoreUri
            _lastExportedPathDisplay.value = publicDisplayPath
            _lastExportedSizeBytes.value = tempOutputFile.length()

            return@withContext tempOutputFile
        } catch (e: Exception) {
            e.printStackTrace()
            _exportErrorMessage.value = "فشل التصدير: ${e.localizedMessage ?: "خطأ غير متوقع في ترميز الفيديو"}"
            _statusMessage.value = "تعذر إكمال التصدير. يرجى مراجعة تفاصيل الخطأ."
            _lastExportedFile.value = null
            _lastExportedUri.value = null
            return@withContext null
        } finally {
            _isExporting.value = false
        }
    }

    private fun encodeVideoToMp4(
        project: Project,
        slides: List<Slide>,
        outputFile: File,
        width: Int,
        height: Int,
        fps: Int,
        totalFrames: Int
    ) {
        val mimeType = "video/avc"
        val bitRate = if (width >= 1280) 4_500_000 else 2_200_000
        val frameDurationUs = 1_000_000L / fps

        // Choose supported color format: preferably COLOR_FormatYUV420SemiPlanar or COLOR_FormatYUV420Flexible
        val format = MediaFormat.createVideoFormat(mimeType, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar)
            setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }

        val codec = MediaCodec.createEncoderByType(mimeType)
        try {
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        } catch (_: Exception) {
            // Fallback to Planar if SemiPlanar unsupported
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar)
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        }
        codec.start()

        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var videoTrackIndex = -1
        var muxerStarted = false
        val bufferInfo = MediaCodec.BufferInfo()

        // Bitmap & YUV byte buffers for software rendering
        val frameBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val frameCanvas = Canvas(frameBitmap)
        val argbBuffer = IntArray(width * height)
        val yuvBufferSize = width * height * 3 / 2
        val yuvBuffer = ByteArray(yuvBufferSize)

        var globalFrameIndex = 0

        for (slideIdx in slides.indices) {
            val slide = slides[slideIdx]
            val slideFrames = slide.durationSeconds * fps

            // Load slide image if available
            val loadedImageBitmap: Bitmap? = if (!slide.imageUri.isNullOrEmpty()) {
                loadBitmapFromUri(slide.imageUri)
            } else null

            // Initialize Video Frame Extractor if slide has videoUri
            val videoRetriever: android.media.MediaMetadataRetriever? = if (!slide.videoUri.isNullOrEmpty()) {
                createRetriever(slide.videoUri)
            } else null

            try {
                for (frameInSlide in 0 until slideFrames) {
                    val overallProgress = globalFrameIndex.toFloat() / totalFrames
                    _exportProgress.value = overallProgress
                    _statusMessage.value = "معالجة مشهد ${slideIdx + 1} من ${slides.size} (${(overallProgress * 100).toInt()}%)"

                    // Extract exact video frame at presentation timestamp
                    val videoFrameBitmap: Bitmap? = if (videoRetriever != null) {
                        val frameTimeUs = (frameInSlide * 1_000_000L) / fps
                        try {
                            videoRetriever.getFrameAtTime(frameTimeUs, android.media.MediaMetadataRetriever.OPTION_CLOSEST)
                        } catch (_: Exception) { null }
                    } else null

                    // Draw slide frame with all custom typography, video motion, and TV graphics
                    drawSlideToCanvas(
                        canvas = frameCanvas,
                        project = project,
                        slide = slide,
                        imageBitmap = loadedImageBitmap,
                        videoFrameBitmap = videoFrameBitmap,
                        slideIdx = slideIdx,
                        frameInSlide = frameInSlide,
                        slideFrames = slideFrames,
                        width = width,
                        height = height
                    )

                    // Convert Bitmap to NV12 YUV
                    frameBitmap.getPixels(argbBuffer, 0, width, 0, 0, width, height)
                    rgbToNv12(argbBuffer, width, height, yuvBuffer)

                    // Feed to MediaCodec input buffer
                    val inputIndex = codec.dequeueInputBuffer(10000L)
                    if (inputIndex >= 0) {
                        val inputBuffer = codec.getInputBuffer(inputIndex)
                        if (inputBuffer != null) {
                            inputBuffer.clear()
                            inputBuffer.put(yuvBuffer)
                            val presentationTimeUs = globalFrameIndex * frameDurationUs
                            codec.queueInputBuffer(inputIndex, 0, yuvBufferSize, presentationTimeUs, 0)
                        }
                    }

                    // Drain output from MediaCodec
                    drainEncoder(codec, muxer, bufferInfo, false, { idx -> videoTrackIndex = idx }, { muxerStarted = true }, muxerStarted)
                    globalFrameIndex++
                }
            } finally {
                try {
                    videoRetriever?.release()
                } catch (_: Exception) {}
            }
        }

        // Signal End of Stream
        val eosIndex = codec.dequeueInputBuffer(10000L)
        if (eosIndex >= 0) {
            val inputBuffer = codec.getInputBuffer(eosIndex)
            inputBuffer?.clear()
            val presentationTimeUs = globalFrameIndex * frameDurationUs
            codec.queueInputBuffer(eosIndex, 0, 0, presentationTimeUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
        }

        drainEncoder(codec, muxer, bufferInfo, true, { idx -> videoTrackIndex = idx }, { muxerStarted = true }, muxerStarted)

        try {
            codec.stop()
            codec.release()
        } catch (_: Exception) {}

        try {
            if (muxerStarted) {
                muxer.stop()
            }
            muxer.release()
        } catch (_: Exception) {}

        frameBitmap.recycle()
    }

    private fun drainEncoder(
        codec: MediaCodec,
        muxer: MediaMuxer,
        bufferInfo: MediaCodec.BufferInfo,
        endOfStream: Boolean,
        onTrackAdded: (Int) -> Unit,
        onMuxerStarted: () -> Unit,
        isMuxerStarted: Boolean
    ) {
        val timeoutUs = 10000L
        var muxerStarted = isMuxerStarted

        while (true) {
            val encoderStatus = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
            if (encoderStatus == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) break
            } else if (encoderStatus == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (muxerStarted) {
                    throw RuntimeException("Format changed after muxer started")
                }
                val newFormat = codec.outputFormat
                val track = muxer.addTrack(newFormat)
                onTrackAdded(track)
                muxer.start()
                muxerStarted = true
                onMuxerStarted()
            } else if (encoderStatus >= 0) {
                val encodedData: ByteBuffer? = codec.getOutputBuffer(encoderStatus)
                if (encodedData != null) {
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                        bufferInfo.size = 0
                    }
                    if (bufferInfo.size != 0 && muxerStarted) {
                        encodedData.position(bufferInfo.offset)
                        encodedData.limit(bufferInfo.offset + bufferInfo.size)
                        muxer.writeSampleData(0, encodedData, bufferInfo)
                    }
                    codec.releaseOutputBuffer(encoderStatus, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        break
                    }
                }
            }
        }
    }

    private fun drawSlideToCanvas(
        canvas: Canvas,
        project: Project,
        slide: Slide,
        imageBitmap: Bitmap?,
        videoFrameBitmap: Bitmap?,
        slideIdx: Int,
        frameInSlide: Int,
        slideFrames: Int,
        width: Int,
        height: Int
    ) {
        val textStyle = slide.textStyle
        val finalTypeface = com.example.ui.theme.getCanvasTypeface(context, textStyle.fontFamilyId, textStyle.isBold)

        // 1. Draw TV Studio Gradient Background
        val (c1, c2) = when (slide.bgPresetIndex % 5) {
            0 -> Pair(Color.parseColor("#070D19"), Color.parseColor("#132238")) // Classic Studio Navy
            1 -> Pair(Color.parseColor("#0F172A"), Color.parseColor("#1E293B")) // Slate Tech Broadcast
            2 -> Pair(Color.parseColor("#1A0A0E"), Color.parseColor("#2D121B")) // Breaking News Crimson Dark
            3 -> Pair(Color.parseColor("#061A14"), Color.parseColor("#0F382B")) // Economic Green Dark
            else -> Pair(Color.parseColor("#1C130E"), Color.parseColor("#2E2018")) // Documentary Warm Vintage
        }

        val bgShader = LinearGradient(0f, 0f, 0f, height.toFloat(), c1, c2, Shader.TileMode.CLAMP)
        val bgPaint = Paint().apply { shader = bgShader }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // 2. Full Background Image or Video (if FULL_BG)
        if (videoFrameBitmap != null && slide.imagePosition == "FULL_BG") {
            drawVideoFrameToCanvas(canvas, videoFrameBitmap, slide, width, height, isFullBg = true)
        } else if (imageBitmap != null && slide.imagePosition == "FULL_BG") {
            val src = Rect(0, 0, imageBitmap.width, imageBitmap.height)
            val dst = Rect(0, 0, width, height)
            val imgPaint = Paint().apply { alpha = 140 } // Subtle dim for readability
            canvas.drawBitmap(imageBitmap, src, dst, imgPaint)
        }

        // 3. Grid line accents
        val gridPaint = Paint().apply {
            color = Color.parseColor("#15FFFFFF")
            strokeWidth = 2f
        }
        val stepY = height / 8f
        for (i in 1..7) {
            canvas.drawLine(0f, i * stepY, width.toFloat(), i * stepY, gridPaint)
        }

        // 4. Channel Logo & LIVE badge (Top Bar)
        val topBarH = height * 0.08f
        val logoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FFD166")
            textSize = (topBarH * 0.45f).coerceAtLeast(24f)
            typeface = finalTypeface
            textAlign = Paint.Align.RIGHT
        }
        val logoText = project.broadcastSettings.channelLogoText.ifEmpty { "KHALED SOOT TV" }
        canvas.drawText(logoText, width - (width * 0.05f), topBarH * 0.7f, logoPaint)

        if (slide.showLiveBadge) {
            val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E63946") }
            val bWidth = width * 0.14f
            val bHeight = topBarH * 0.55f
            val bLeft = width * 0.04f
            val bTop = topBarH * 0.25f
            val bRect = RectF(bLeft, bTop, bLeft + bWidth, bTop + bHeight)
            canvas.drawRoundRect(bRect, 8f, 8f, badgePaint)

            val bTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = (bHeight * 0.55f).coerceAtLeast(16f)
                typeface = Typeface.DEFAULT_BOLD
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("● مباشر LIVE", bRect.centerX(), bRect.centerY() + (bTextPaint.textSize * 0.35f), bTextPaint)
        }

        // 5. Video or Image Placement (SPLIT, CENTER, LEFT, RIGHT)
        if (videoFrameBitmap != null && slide.imagePosition != "FULL_BG") {
            drawVideoFrameToCanvas(canvas, videoFrameBitmap, slide, width, height, isFullBg = false)
        } else if (imageBitmap != null && slide.imagePosition != "FULL_BG") {
            val imgRect = when (slide.imagePosition) {
                "CENTER" -> RectF(width * 0.25f, height * 0.35f, width * 0.75f, height * 0.75f)
                "LEFT" -> RectF(width * 0.05f, height * 0.25f, width * 0.40f, height * 0.75f)
                "RIGHT" -> RectF(width * 0.60f, height * 0.25f, width * 0.95f, height * 0.75f)
                else -> RectF(width * 0.05f, height * 0.30f, width * 0.45f, height * 0.75f) // SPLIT
            }
            val borderPaint = Paint().apply {
                color = Color.parseColor("#2E3856")
                style = Paint.Style.STROKE
                strokeWidth = 4f
            }
            canvas.drawRoundRect(imgRect, 16f, 16f, borderPaint)
            val src = Rect(0, 0, imageBitmap.width, imageBitmap.height)
            canvas.drawBitmap(imageBitmap, src, imgRect, null)
        }

        // 6. Slide Text Content with Typography settings
        val contentX = when (textStyle.textAlignment) {
            "CENTER" -> width * 0.5f
            "LEFT" -> width * 0.08f
            else -> width * 0.92f // RIGHT (Default RTL)
        }
        val align = when (textStyle.textAlignment) {
            "CENTER" -> Paint.Align.CENTER
            "LEFT" -> Paint.Align.LEFT
            else -> Paint.Align.RIGHT
        }

        val titleColor = try { Color.parseColor(textStyle.textColorHex) } catch (_: Exception) { Color.WHITE }
        val accentColor = try { Color.parseColor(textStyle.accentColorHex) } catch (_: Exception) { Color.parseColor("#00B4D8") }

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = titleColor
            textSize = (height * (textStyle.titleFontSizeSp / 340f)).coerceIn(16f, 90f)
            typeface = finalTypeface
            textAlign = align
        }

        val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            textSize = (height * (textStyle.subtitleFontSizeSp / 340f)).coerceIn(12f, 60f)
            typeface = finalTypeface
            textAlign = align
        }

        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#CBD5E1")
            textSize = (height * (textStyle.bodyFontSizeSp / 340f)).coerceIn(10f, 48f)
            typeface = finalTypeface
            textAlign = align
        }

        var currentY = height * 0.24f

        if (slide.title.isNotEmpty()) {
            canvas.drawText(slide.title, contentX, currentY, titlePaint)
            currentY += titlePaint.textSize * 1.5f
        }

        if (slide.subtitle.isNotEmpty()) {
            canvas.drawText(slide.subtitle, contentX, currentY, subtitlePaint)
            currentY += subtitlePaint.textSize * 1.5f
        }

        if (slide.bodyText.isNotEmpty() && slide.imagePosition != "FULL_BG") {
            canvas.drawText(slide.bodyText, contentX, currentY, bodyPaint)
            currentY += bodyPaint.textSize * 1.5f
        }

        for (bp in slide.bulletPoints.take(3)) {
            val bulletText = "• $bp"
            canvas.drawText(bulletText, contentX, currentY, bodyPaint)
            currentY += bodyPaint.textSize * 1.4f
        }

        // 7. Stat Card (if showStatCard)
        if (slide.showStatCard && slide.statValue.isNotEmpty() && imageBitmap == null) {
            val scLeft = width * 0.06f
            val scTop = height * 0.35f
            val scWidth = width * 0.30f
            val scHeight = height * 0.26f
            val scRect = RectF(scLeft, scTop, scLeft + scWidth, scTop + scHeight)

            val cardBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#CC162540") }
            val cardStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#00B4D8")
                style = Paint.Style.STROKE
                strokeWidth = 3f
            }
            canvas.drawRoundRect(scRect, 16f, 16f, cardBg)
            canvas.drawRoundRect(scRect, 16f, 16f, cardStroke)

            val valPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#FFD166")
                textSize = (scHeight * 0.38f).coerceAtLeast(28f)
                typeface = Typeface.DEFAULT_BOLD
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(slide.statValue, scRect.centerX(), scRect.centerY(), valPaint)

            val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = (scHeight * 0.18f).coerceAtLeast(14f)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(slide.statLabel, scRect.centerX(), scRect.centerY() + (valPaint.textSize * 0.7f), labelPaint)
        }

        // 8. Lower Third
        if (slide.showLowerThird && slide.lowerThirdName.isNotEmpty()) {
            val ltHeight = height * 0.10f
            val ltBottom = height * 0.88f
            val ltTop = ltBottom - ltHeight
            val ltWidth = width * 0.55f
            val ltRight = width * 0.95f
            val ltLeft = ltRight - ltWidth

            val ltBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E6070D19") }
            val ltBar = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E63946") }
            val ltRect = RectF(ltLeft, ltTop, ltRight, ltBottom)
            canvas.drawRoundRect(ltRect, 8f, 8f, ltBg)
            canvas.drawRect(ltRight - 14f, ltTop, ltRight, ltBottom, ltBar)

            val ltNamePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = (ltHeight * 0.38f).coerceAtLeast(20f)
                typeface = Typeface.DEFAULT_BOLD
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText(slide.lowerThirdName, ltRight - 30f, ltTop + (ltHeight * 0.45f), ltNamePaint)

            val ltRolePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#90E0EF")
                textSize = (ltHeight * 0.28f).coerceAtLeast(15f)
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText(slide.lowerThirdRole, ltRight - 30f, ltTop + (ltHeight * 0.85f), ltRolePaint)
        }

        // 9. Breaking News Red Banner
        if (slide.showBreakingBanner && slide.breakingNewsText.isNotEmpty()) {
            val bnHeight = height * 0.07f
            val bnTop = height * 0.84f
            val bnPaint = Paint().apply { color = Color.parseColor("#D90429") }
            canvas.drawRect(0f, bnTop, width.toFloat(), bnTop + bnHeight, bnPaint)

            val bnTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = (bnHeight * 0.52f).coerceAtLeast(18f)
                typeface = Typeface.DEFAULT_BOLD
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText(slide.breakingNewsText, width - (width * 0.05f), bnTop + (bnHeight * 0.68f), bnTextPaint)
        }

        // 10. Moving Ticker (شريط إخباري متحرك أسفل الشاشة)
        if (project.broadcastSettings.showTicker) {
            val tickerHeight = height * 0.065f
            val tickerTop = height - tickerHeight

            val tickerBgPaint = Paint().apply { color = Color.parseColor("#FF070D19") }
            canvas.drawRect(0f, tickerTop, width.toFloat(), height.toFloat(), tickerBgPaint)

            val tickerBorderPaint = Paint().apply {
                color = Color.parseColor("#2E3856")
                strokeWidth = 2f
            }
            canvas.drawLine(0f, tickerTop, width.toFloat(), tickerTop, tickerBorderPaint)

            val badgePaint = Paint().apply { color = Color.parseColor("#E63946") }
            val tickerBadgeWidth = width * 0.16f
            canvas.drawRect(width - tickerBadgeWidth, tickerTop, width.toFloat(), height.toFloat(), badgePaint)

            val badgeTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = (tickerHeight * 0.52f).coerceAtLeast(16f)
                typeface = Typeface.DEFAULT_BOLD
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("عاجل", width - (tickerBadgeWidth / 2f), tickerTop + (tickerHeight * 0.68f), badgeTextPaint)

            val tickerText = project.broadcastSettings.tickerText
            val tColor = try { Color.parseColor(project.broadcastSettings.tickerTextColorHex) } catch (_: Exception) { Color.WHITE }
            val tPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = tColor
                textSize = (tickerHeight * (project.broadcastSettings.tickerFontSizeSp / 22f)).coerceIn(16f, 32f)
                typeface = finalTypeface
                textAlign = Paint.Align.RIGHT
            }

            val textWidth = tPaint.measureText(tickerText)
            val moveSpeed = 4.5f * project.broadcastSettings.tickerSpeed
            val animOffset = (frameInSlide * moveSpeed) % (textWidth + width)
            val textX = (width - tickerBadgeWidth - 20f) + animOffset - textWidth
            canvas.drawText(tickerText, textX.coerceAtLeast(-textWidth), tickerTop + (tickerHeight * 0.68f), tPaint)
        }
    }

    private fun rgbToNv12(argb: IntArray, width: Int, height: Int, outNv12: ByteArray) {
        val frameSize = width * height
        var yIndex = 0
        var uvIndex = frameSize
        var index = 0

        for (j in 0 until height) {
            for (i in 0 until width) {
                val color = argb[index++]
                val R = (color shr 16) and 0xff
                val G = (color shr 8) and 0xff
                val B = color and 0xff

                val Y = ((66 * R + 129 * G + 25 * B + 128) shr 8) + 16
                val U = ((-38 * R - 74 * G + 112 * B + 128) shr 8) + 128
                val V = ((112 * R - 94 * G - 18 * B + 128) shr 8) + 128

                outNv12[yIndex++] = Y.coerceIn(0, 255).toByte()
                if (j % 2 == 0 && i % 2 == 0) {
                    outNv12[uvIndex++] = U.coerceIn(0, 255).toByte()
                    outNv12[uvIndex++] = V.coerceIn(0, 255).toByte()
                }
            }
        }
    }

    private fun loadBitmapFromUri(uriString: String): Bitmap? {
        return try {
            val uri = Uri.parse(uriString)
            if (uri.scheme == "content") {
                context.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it)
                }
            } else {
                val file = File(uriString)
                if (file.exists()) {
                    BitmapFactory.decodeFile(file.absolutePath)
                } else null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun createRetriever(uriString: String?): android.media.MediaMetadataRetriever? {
        if (uriString.isNullOrEmpty()) return null
        return try {
            android.media.MediaMetadataRetriever().apply {
                if (uriString.startsWith("content://")) {
                    setDataSource(context, Uri.parse(uriString))
                } else {
                    val path = if (uriString.startsWith("file://")) uriString.removePrefix("file://") else uriString
                    setDataSource(path)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun drawVideoFrameToCanvas(
        canvas: Canvas,
        frame: Bitmap,
        slide: Slide,
        width: Int,
        height: Int,
        isFullBg: Boolean
    ) {
        val targetRect = if (isFullBg || slide.bodyText.isEmpty()) {
            RectF(0f, 0f, width.toFloat(), height.toFloat())
        } else {
            when (slide.imagePosition) {
                "CENTER" -> RectF(width * 0.15f, height * 0.28f, width * 0.85f, height * 0.76f)
                "LEFT" -> RectF(width * 0.05f, height * 0.25f, width * 0.45f, height * 0.75f)
                "RIGHT" -> RectF(width * 0.55f, height * 0.25f, width * 0.95f, height * 0.75f)
                else -> RectF(width * 0.05f, height * 0.28f, width * 0.48f, height * 0.75f)
            }
        }

        when (slide.videoDisplayMode) {
            com.example.data.model.VideoDisplayMode.FILL -> {
                val scale = maxOf(targetRect.width() / frame.width.toFloat(), targetRect.height() / frame.height.toFloat())
                val scaledW = frame.width * scale
                val scaledH = frame.height * scale
                val left = targetRect.centerX() - scaledW / 2f
                val top = targetRect.centerY() - scaledH / 2f
                val dst = RectF(left, top, left + scaledW, top + scaledH)
                canvas.save()
                canvas.clipRect(targetRect)
                val paint = if (isFullBg) Paint().apply { alpha = 160 } else null
                canvas.drawBitmap(frame, null, dst, paint)
                canvas.restore()
            }
            com.example.data.model.VideoDisplayMode.FIT -> {
                val scale = minOf(targetRect.width() / frame.width.toFloat(), targetRect.height() / frame.height.toFloat())
                val scaledW = frame.width * scale
                val scaledH = frame.height * scale
                val left = targetRect.centerX() - scaledW / 2f
                val top = targetRect.centerY() - scaledH / 2f
                val dst = RectF(left, top, left + scaledW, top + scaledH)

                if (!isFullBg) {
                    val bgPaint = Paint().apply { color = Color.parseColor("#080D1A") }
                    canvas.drawRoundRect(targetRect, 16f, 16f, bgPaint)
                }
                canvas.drawBitmap(frame, null, dst, null)
                if (!isFullBg) {
                    val borderPaint = Paint().apply {
                        color = Color.parseColor("#E63946")
                        style = Paint.Style.STROKE
                        strokeWidth = 3.5f
                    }
                    canvas.drawRoundRect(targetRect, 16f, 16f, borderPaint)
                }
            }
            com.example.data.model.VideoDisplayMode.CENTER -> {
                val scale = minOf(targetRect.width() / frame.width.toFloat(), targetRect.height() / frame.height.toFloat()) * 0.9f
                val scaledW = frame.width * scale
                val scaledH = frame.height * scale
                val left = targetRect.centerX() - scaledW / 2f
                val top = targetRect.centerY() - scaledH / 2f
                val dst = RectF(left, top, left + scaledW, top + scaledH)
                canvas.drawBitmap(frame, null, dst, null)
            }
            com.example.data.model.VideoDisplayMode.CUSTOM -> {
                val baseScale = minOf(targetRect.width() / frame.width.toFloat(), targetRect.height() / frame.height.toFloat())
                val scale = baseScale * slide.videoZoom.coerceIn(0.5f, 2.5f)
                val scaledW = frame.width * scale
                val scaledH = frame.height * scale
                val panOffsetX = (slide.videoPanX * width) / 100f
                val panOffsetY = (slide.videoPanY * height) / 100f
                val left = targetRect.centerX() - scaledW / 2f + panOffsetX
                val top = targetRect.centerY() - scaledH / 2f + panOffsetY
                val dst = RectF(left, top, left + scaledW, top + scaledH)
                canvas.save()
                canvas.clipRect(targetRect)
                val paint = if (isFullBg) Paint().apply { alpha = 160 } else null
                canvas.drawBitmap(frame, null, dst, paint)
                canvas.restore()
            }
        }
    }

    private fun saveVideoToMediaStore(sourceFile: File): Pair<Uri?, String> {
        val fileName = sourceFile.name
        val relativePath = "Movies/KhaledSootStudio"

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, relativePath)
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }

                val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(sourceFile).use { input ->
                            input.copyTo(out)
                        }
                    }
                    values.clear()
                    values.put(MediaStore.Video.Media.IS_PENDING, 0)
                    context.contentResolver.update(uri, values, null, null)
                    return Pair(uri, "$relativePath/$fileName")
                }
            } else {
                // Pre-Android 10
                @Suppress("DEPRECATION")
                val moviesDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "KhaledSootStudio")
                if (!moviesDir.exists()) moviesDir.mkdirs()
                val dest = File(moviesDir, fileName)
                sourceFile.copyTo(dest, overwrite = true)
                val contentUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", dest)
                return Pair(contentUri, dest.absolutePath)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Internal fallback URI
        val fallbackUri = try {
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", sourceFile)
        } catch (_: Exception) { null }
        return Pair(fallbackUri, sourceFile.absolutePath)
    }

    fun openExportedVideo() {
        val uri = _lastExportedUri.value ?: run {
            val file = _lastExportedFile.value ?: return
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        }

        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "video/mp4")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun shareExportedVideo() {
        val uri = _lastExportedUri.value ?: run {
            val file = _lastExportedFile.value ?: return
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        }

        try {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "تقرير من استوديو خالد صوت 2.1")
                putExtra(Intent.EXTRA_TEXT, "تم إنتاج هذا التقرير الاحترافي بواسطة: استوديو خالد صوت للعروض والتقارير – Khaled Soot Presentation Studio 2.1")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(shareIntent, "مشاركة الفيديو عبر...").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
