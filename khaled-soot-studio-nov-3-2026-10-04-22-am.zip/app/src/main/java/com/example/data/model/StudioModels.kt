package com.example.data.model

import java.util.UUID

enum class AspectRatio(
    val labelAr: String,
    val ratioFloat: Float,
    val iconLabel: String,
    val platformHint: String
) {
    RATIO_16_9("16:9 شاشة تلفزيون وعرض", 16f / 9f, "16:9", "يوتيوب وشاشات التلفزيون 1080p/720p"),
    RATIO_9_16("9:16 ريلز وتيك توك", 9f / 16f, "9:16", "ريلز إنستغرام، تيك توك، يوتيوب شورتس"),
    RATIO_1_1("1:1 منشورات مربعة", 1f, "1:1", "منشورات فيسبوك وإنستغرام")
}

enum class TransitionType(val titleAr: String) {
    FADE("تلاشي سينمائي"),
    SLIDE("انزلاق تلفزيوني"),
    ZOOM("تكبير ديناميكي"),
    WIPE("مسح استوديو")
}

enum class TemplateCategory(val titleAr: String, val iconDescription: String) {
    TV_NEWS("تقرير إخباري تلفزيوني", "قوالب عواجل وشارات إخبارية"),
    HISTORICAL_DOC("وثائقي وسرد تاريخي", "قوالب سردية وخرائط توضيحية"),
    ECONOMIC("اقتصادي ومؤشرات وأرقام", "نسب بيانية وإحصائيات مالية"),
    EDUCATIONAL("عرض تدريبي وتعليمي", "محاور رئيسية ونقاط استعراض")
}

enum class VideoDisplayMode(
    val id: String,
    val titleAr: String,
    val descAr: String
) {
    FILL("FILL", "ملء الشاشة (Fill / Crop)", "يملأ الشاشة بالكامل مع قص الأطراف عند الحاجة"),
    FIT("FIT", "احتواء كامل (Fit)", "إظهار الفيديو كاملاً دون قص مع خلفية مناسبة"),
    CENTER("CENTER", "توسيط (Center)", "توسيط الفيديو بحجمه المناسب المتناسق"),
    CUSTOM("CUSTOM", "تحكم يدوي (Zoom & Pan)", "تكبير وتصغير وتحريك أفقياً وعمودياً")
}

enum class StudioFontFamily(
    val id: String,
    val titleAr: String,
    val fontResName: String,
    val isArabicNative: Boolean
) {
    CAIRO("CAIRO", "كايرو (Cairo) – خط برودكاست إخباري", "cairo", true),
    TAJAWAL("TAJAWAL", "تجوال (Tajawal) – خط هندسي عصري", "tajawal", true),
    ALMARAI("ALMARAI", "المراعي (Almarai) – خط تلفزيوني وإعلامي", "almarai", true),
    AMIRI("AMIRI", "أميري (Amiri) – خط نسخ وثائقي كلاسيكي", "amiri", true),
    MONTSERRAT("MONTSERRAT", "مونتسيرات (Montserrat) – خط إنجليزي حديث", "montserrat", false),
    SANS_SERIF("SANS_SERIF", "خط النظام الافتراضي (Sans-serif)", "sans", true),
    SERIF("SERIF", "خط النظام الكلاسيكي (Serif)", "serif", true),
    MONOSPACE("MONOSPACE", "خط رقمي برمجي (Monospace)", "mono", false);

    companion object {
        fun fromId(id: String): StudioFontFamily {
            return entries.find { it.id.equals(id, ignoreCase = true) } ?: CAIRO
        }
    }
}

data class TextStyleConfig(
    val fontFamilyId: String = StudioFontFamily.CAIRO.id,
    val titleFontSizeSp: Int = 20,
    val subtitleFontSizeSp: Int = 14,
    val bodyFontSizeSp: Int = 12,
    val isBold: Boolean = true,
    val textColorHex: String = "#F8F9FA",
    val accentColorHex: String = "#00B4D8",
    val textAlignment: String = "RIGHT" // RIGHT, CENTER, LEFT
)

data class SoundEffectItem(
    val id: String,
    val titleAr: String,
    val categoryAr: String,
    val fileName: String,
    val durationSeconds: Float,
    val descriptionAr: String
)

data class Slide(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val subtitle: String = "",
    val bodyText: String = "",
    val bulletPoints: List<String> = emptyList(),
    val templateCategory: TemplateCategory = TemplateCategory.TV_NEWS,
    val bgPresetIndex: Int = 0,
    val imageUri: String? = null,
    val videoUri: String? = null,
    val mediaList: List<String> = emptyList(),
    val imagePosition: String = "SPLIT", // SPLIT, CENTER, FULL_BG, RIGHT, LEFT
    val videoDisplayMode: VideoDisplayMode = VideoDisplayMode.FIT,
    val videoZoom: Float = 1.0f, // 0.5f to 2.5f
    val videoPanX: Float = 0.0f, // -100f to +100f
    val videoPanY: Float = 0.0f, // -100f to +100f
    val videoVolume: Float = 1.0f, // 0.0f to 1.0f (sound level of imported video)
    val durationSeconds: Int = 5,
    val transition: TransitionType = TransitionType.FADE,
    val lowerThirdName: String = "",
    val lowerThirdRole: String = "",
    val showLowerThird: Boolean = false,
    val showLiveBadge: Boolean = true,
    val breakingNewsText: String = "",
    val showBreakingBanner: Boolean = false,
    val statValue: String = "",
    val statLabel: String = "",
    val showStatCard: Boolean = false,
    val textStyle: TextStyleConfig = TextStyleConfig()
)

data class BroadcastSettings(
    val channelLogoText: String = "KHALED SOOT TV",
    val channelSubText: String = "صوت الخبر والتحليل",
    val tickerText: String = "استوديو خالد صوت 2.1: استمرار البث المباشر لأحدث التقارير الوثائقية والتحليلات المتخصصة على مدار الساعة...",
    val showTicker: Boolean = true,
    val tickerSpeed: Float = 1.0f,
    val studioLocation: String = "الرياض - الاستوديو الرئيسي",
    val presenterName: String = "خالد صوت",
    val tickerTextColorHex: String = "#F8F9FA",
    val tickerFontSizeSp: Int = 11,
    val tickerFontFamilyId: String = StudioFontFamily.CAIRO.id
)

data class AudioConfig(
    val voiceoverPath: String? = null,
    val voiceoverDurationMs: Long = 0L,
    val selectedMusicPreset: String = "BREAKING_NEWS", // NONE, BREAKING_NEWS, DOCUMENTARY, ECONOMIC_BEAT, CALM_PIANO, CUSTOM
    val customAudioPath: String? = null,
    val customAudioName: String? = null,
    val voiceVolume: Float = 1.0f,
    val musicVolume: Float = 0.45f,
    val soundFxVolume: Float = 0.8f,
    val selectedSoundFxId: String? = "fx_breaking_news",
    val audioOffsetSec: Float = 0f,
    val autoDucking: Boolean = true
)

data class Project(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "مشروع تقرير جديد 2.1",
    val description: String = "",
    val aspectRatio: AspectRatio = AspectRatio.RATIO_16_9,
    val slides: List<Slide> = emptyList(),
    val broadcastSettings: BroadcastSettings = BroadcastSettings(),
    val audioConfig: AudioConfig = AudioConfig(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
