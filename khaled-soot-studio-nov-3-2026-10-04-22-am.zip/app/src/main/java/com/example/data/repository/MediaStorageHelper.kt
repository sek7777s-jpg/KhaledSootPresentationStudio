package com.example.data.repository

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class MediaStorageHelper(private val context: Context) {

    private val videosDir = File(context.filesDir, "imported_videos").apply { mkdirs() }
    private val imagesDir = File(context.filesDir, "imported_images").apply { mkdirs() }

    suspend fun copyUriToLocalVideo(uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val extension = getExtension(uri) ?: "mp4"
            val targetFile = File(videosDir, "video_${System.currentTimeMillis()}.$extension")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(targetFile).use { output ->
                    input.copyTo(output)
                }
            }
            if (targetFile.exists() && targetFile.length() > 0) {
                targetFile.absolutePath
            } else {
                null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    suspend fun copyUriToLocalImage(uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val extension = getExtension(uri) ?: "jpg"
            val targetFile = File(imagesDir, "img_${System.currentTimeMillis()}.$extension")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(targetFile).use { output ->
                    input.copyTo(output)
                }
            }
            if (targetFile.exists() && targetFile.length() > 0) {
                targetFile.absolutePath
            } else {
                null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun getVideoDurationSeconds(filePathOrUri: String): Int {
        val retriever = MediaMetadataRetriever()
        return try {
            if (filePathOrUri.startsWith("content://")) {
                retriever.setDataSource(context, Uri.parse(filePathOrUri))
            } else {
                val cleanPath = if (filePathOrUri.startsWith("file://")) {
                    filePathOrUri.removePrefix("file://")
                } else {
                    filePathOrUri
                }
                retriever.setDataSource(cleanPath)
            }
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            val durationMs = durationStr?.toLongOrNull() ?: 5000L
            (durationMs / 1000).toInt().coerceIn(2, 120)
        } catch (e: Exception) {
            e.printStackTrace()
            5
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }
    }

    private fun getExtension(uri: Uri): String? {
        val path = uri.path ?: return null
        val dotIdx = path.lastIndexOf('.')
        return if (dotIdx != -1 && dotIdx < path.length - 1) {
            path.substring(dotIdx + 1).take(4).lowercase()
        } else {
            val type = context.contentResolver.getType(uri)
            when (type) {
                "video/mp4" -> "mp4"
                "video/3gpp" -> "3gp"
                "video/webm" -> "webm"
                "image/png" -> "png"
                "image/jpeg" -> "jpg"
                "image/webp" -> "webp"
                else -> null
            }
        }
    }
}
