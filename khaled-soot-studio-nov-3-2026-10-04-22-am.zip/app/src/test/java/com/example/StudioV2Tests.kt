package com.example

import com.example.data.model.AspectRatio
import com.example.data.model.AudioConfig
import com.example.data.model.Project
import com.example.data.model.Slide
import com.example.data.model.StudioFontFamily
import com.example.data.model.TextStyleConfig
import com.example.data.repository.SoundFxManager
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File

class StudioV2Tests {

    private lateinit var tempDir: File
    private lateinit var soundFxManager: SoundFxManager

    @Before
    fun setup() {
        tempDir = File(System.getProperty("java.io.tmpdir"), "studio_v2_test_${System.currentTimeMillis()}")
        tempDir.mkdirs()
        soundFxManager = SoundFxManager(tempDir)
    }

    @Test
    fun test1_insertImageAndMediaList() {
        val slide = Slide(
            id = "test_slide_1",
            title = "مشهد وسائط",
            imageUri = "content://media/external/images/media/101",
            mediaList = listOf(
                "content://media/external/images/media/101",
                "content://media/external/images/media/102"
            ),
            imagePosition = "FULL_BG"
        )

        assertEquals("content://media/external/images/media/101", slide.imageUri)
        assertEquals(2, slide.mediaList.size)
        assertEquals("FULL_BG", slide.imagePosition)

        // Test removing a media item and fallback
        val updatedMediaList = slide.mediaList.filter { it != "content://media/external/images/media/101" }
        val updatedSlide = slide.copy(
            mediaList = updatedMediaList,
            imageUri = updatedMediaList.firstOrNull()
        )
        assertEquals(1, updatedSlide.mediaList.size)
        assertEquals("content://media/external/images/media/102", updatedSlide.imageUri)
    }

    @Test
    fun test2_insertVideoBRoll() {
        val slideWithVideo = Slide(
            id = "test_slide_video",
            title = "مشهد فيديو B-Roll",
            videoUri = "content://media/external/video/media/501",
            mediaList = listOf("content://media/external/video/media/501")
        )

        assertEquals("content://media/external/video/media/501", slideWithVideo.videoUri)
        assertTrue(slideWithVideo.mediaList.contains("content://media/external/video/media/501"))
    }

    @Test
    fun test3_typographyAndStyling() {
        val customStyle = TextStyleConfig(
            fontFamilyId = StudioFontFamily.CAIRO.id,
            titleFontSizeSp = 24,
            subtitleFontSizeSp = 14,
            bodyFontSizeSp = 12,
            isBold = true,
            textColorHex = "#FFD166",
            accentColorHex = "#00B4D8",
            textAlignment = "CENTER"
        )

        val slide = Slide(
            title = "عنوان كوفي تلفزيوني",
            textStyle = customStyle
        )

        assertEquals(StudioFontFamily.CAIRO.id, slide.textStyle.fontFamilyId)
        assertEquals(24, slide.textStyle.titleFontSizeSp)
        assertTrue(slide.textStyle.isBold)
        assertEquals("#FFD166", slide.textStyle.textColorHex)
        assertEquals("CENTER", slide.textStyle.textAlignment)
    }

    @Test
    fun test4_soundEffectsLibraryInitialization() = runBlocking {
        soundFxManager.initialize()

        val effects = soundFxManager.availableEffects
        assertEquals(7, effects.size)

        // Verify all 7 sound effect WAV files exist and have valid WAV audio headers
        for (effect in effects) {
            val file = soundFxManager.getSoundEffectFile(effect.id)
            assertNotNull("Sound effect file should exist for ${effect.id}", file)
            assertTrue("File ${effect.fileName} should exist", file!!.exists())
            assertTrue("File ${effect.fileName} should not be empty", file.length() > 1000)

            // Check RIFF and WAVE header bytes
            val bytes = file.readBytes()
            val headerRiff = String(bytes.sliceArray(0..3))
            val headerWave = String(bytes.sliceArray(8..11))
            assertEquals("RIFF", headerRiff)
            assertEquals("WAVE", headerWave)
        }
    }

    @Test
    fun test5_audioStudioImportAndDucking() {
        val audioConfig = AudioConfig(
            customAudioPath = "/path/to/custom_audio.mp3",
            customAudioName = "report_voiceover.mp3",
            selectedMusicPreset = "CUSTOM",
            voiceVolume = 0.9f,
            musicVolume = 0.35f,
            soundFxVolume = 0.8f,
            autoDucking = true
        )

        assertEquals("CUSTOM", audioConfig.selectedMusicPreset)
        assertEquals("report_voiceover.mp3", audioConfig.customAudioName)
        assertTrue(audioConfig.autoDucking)
        assertEquals(0.9f, audioConfig.voiceVolume, 0.01f)
    }

    @Test
    fun test6_exportValidationAndAspectRatio() {
        val project169 = Project(
            title = "تقرير تجريبي 16:9",
            aspectRatio = AspectRatio.RATIO_16_9,
            slides = listOf(Slide(title = "مشهد 1", durationSeconds = 3))
        )
        assertEquals(16f / 9f, project169.aspectRatio.ratioFloat, 0.01f)

        val project916 = Project(
            title = "تقرير ريلز 9:16",
            aspectRatio = AspectRatio.RATIO_9_16,
            slides = listOf(Slide(title = "مشهد ريلز", durationSeconds = 4))
        )
        assertEquals(9f / 16f, project916.aspectRatio.ratioFloat, 0.01f)

        val project11 = Project(
            title = "منشور مربع 1:1",
            aspectRatio = AspectRatio.RATIO_1_1,
            slides = listOf(Slide(title = "مشهد مربع", durationSeconds = 5))
        )
        assertEquals(1.0f, project11.aspectRatio.ratioFloat, 0.01f)
    }
}
