package com.example

import com.example.data.model.AspectRatio
import com.example.data.model.AudioConfig
import com.example.data.model.BroadcastSettings
import com.example.data.model.Project
import com.example.data.model.Slide
import com.example.data.model.StudioFontFamily
import com.example.data.model.TemplateCategory
import com.example.data.model.TextStyleConfig
import com.example.data.model.VideoDisplayMode
import com.example.data.repository.SoundFxManager
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.io.FileOutputStream

class StudioV21Tests {

    private lateinit var tempDir: File
    private lateinit var soundFxManager: SoundFxManager

    @Before
    fun setup() {
        tempDir = File(System.getProperty("java.io.tmpdir"), "studio_v21_test_${System.currentTimeMillis()}")
        tempDir.mkdirs()
        soundFxManager = SoundFxManager(tempDir)
    }

    @Test
    fun test1_videoDisplayModesAndCustomAdjustments() {
        val slide = Slide(
            id = "test_slide_v21_1",
            title = "مشهد فيديو B-Roll تجريبي",
            videoUri = "/data/user/0/com.aistudio.khaledstudio/files/imported_videos/sample.mp4",
            videoDisplayMode = VideoDisplayMode.FILL,
            videoZoom = 1.4f,
            videoPanX = 12.0f,
            videoPanY = -8.0f,
            videoVolume = 0.85f
        )

        assertEquals(VideoDisplayMode.FILL, slide.videoDisplayMode)
        assertEquals(1.4f, slide.videoZoom, 0.01f)
        assertEquals(12.0f, slide.videoPanX, 0.01f)
        assertEquals(-8.0f, slide.videoPanY, 0.01f)
        assertEquals(0.85f, slide.videoVolume, 0.01f)

        // Test changing mode to FIT and CENTER
        val fitSlide = slide.copy(videoDisplayMode = VideoDisplayMode.FIT)
        assertEquals(VideoDisplayMode.FIT, fitSlide.videoDisplayMode)

        val centerSlide = slide.copy(videoDisplayMode = VideoDisplayMode.CENTER)
        assertEquals(VideoDisplayMode.CENTER, centerSlide.videoDisplayMode)

        val customSlide = slide.copy(videoDisplayMode = VideoDisplayMode.CUSTOM, videoZoom = 2.0f)
        assertEquals(VideoDisplayMode.CUSTOM, customSlide.videoDisplayMode)
        assertEquals(2.0f, customSlide.videoZoom, 0.01f)
    }

    @Test
    fun test2_installedFontsAndTypographyPresets() {
        // Verify all bundled and supported font families
        val cairoFont = StudioFontFamily.CAIRO
        assertEquals("CAIRO", cairoFont.id)
        assertEquals("cairo", cairoFont.fontResName)
        assertTrue(cairoFont.isArabicNative)

        val tajawalFont = StudioFontFamily.TAJAWAL
        assertEquals("TAJAWAL", tajawalFont.id)
        assertTrue(tajawalFont.isArabicNative)

        val almaraiFont = StudioFontFamily.ALMARAI
        assertEquals("ALMARAI", almaraiFont.id)
        assertTrue(almaraiFont.isArabicNative)

        val amiriFont = StudioFontFamily.AMIRI
        assertEquals("AMIRI", amiriFont.id)
        assertTrue(amiriFont.isArabicNative)

        val montserratFont = StudioFontFamily.MONTSERRAT
        assertEquals("MONTSERRAT", montserratFont.id)

        // Verify fallback lookup
        val resolved = StudioFontFamily.fromId("tajawal")
        assertEquals(StudioFontFamily.TAJAWAL, resolved)
    }

    @Test
    fun test3_fontSizesManualInputAndClamping() {
        val baseConfig = TextStyleConfig(
            fontFamilyId = StudioFontFamily.CAIRO.id,
            titleFontSizeSp = 20,
            subtitleFontSizeSp = 14,
            bodyFontSizeSp = 12
        )

        // Test preset sizing
        val presetSizes = listOf(12, 14, 16, 18, 20, 24, 28, 32, 36, 40, 48, 60, 72)
        assertTrue(presetSizes.contains(20))
        assertTrue(presetSizes.contains(72))

        // Test manual custom size and clamping to 10..72
        val customLarge = baseConfig.copy(titleFontSizeSp = 64.coerceIn(10, 72))
        assertEquals(64, customLarge.titleFontSizeSp)

        val clampedSmall = baseConfig.copy(titleFontSizeSp = 4.coerceIn(10, 72))
        assertEquals(10, clampedSmall.titleFontSizeSp)

        val clampedLarge = baseConfig.copy(titleFontSizeSp = 100.coerceIn(10, 72))
        assertEquals(72, clampedLarge.titleFontSizeSp)
    }

    @Test
    fun test4_soundEffectsLibraryInitialization() = runBlocking {
        soundFxManager.initialize()

        val effects = soundFxManager.availableEffects
        assertEquals(7, effects.size)

        // Verify all 7 sound effect WAV files exist and have valid WAV audio headers
        for (effect in effects) {
            val file = soundFxManager.getSoundEffectFile(effect.id)
            assertNotNull("Sound effect file should exist for ${effect.id}", file)
            assertTrue("File ${effect.fileName} should exist", file!!.exists())
            assertTrue("File ${effect.fileName} should not be empty", file.length() > 1000)

            // Check RIFF and WAVE header bytes
            val bytes = file.readBytes()
            val headerRiff = String(bytes.sliceArray(0..3))
            val headerWave = String(bytes.sliceArray(8..11))
            assertEquals("RIFF", headerRiff)
            assertEquals("WAVE", headerWave)
        }
    }

    @Test
    fun test5_projectFullRoundTripStateValidation() {
        val originalSlide = Slide(
            id = "slide_trip_1",
            title = "تقرير رئيسي متطور 2.1",
            subtitle = "نشرة استوديو خالد صوت الإخبارية",
            videoUri = "/data/user/0/test_video.mp4",
            videoDisplayMode = VideoDisplayMode.FILL,
            videoZoom = 1.35f,
            videoPanX = 5.0f,
            videoPanY = -10.0f,
            videoVolume = 0.90f,
            textStyle = TextStyleConfig(
                fontFamilyId = StudioFontFamily.CAIRO.id,
                titleFontSizeSp = 28,
                subtitleFontSizeSp = 18,
                bodyFontSizeSp = 14,
                isBold = true,
                textColorHex = "#FFD166",
                textAlignment = "CENTER"
            )
        )

        val project = Project(
            id = "proj_round_trip",
            title = "مشروع النسخة 2.1",
            aspectRatio = AspectRatio.RATIO_16_9,
            slides = listOf(originalSlide),
            broadcastSettings = BroadcastSettings(
                channelLogoText = "KHALED SOOT 2.1",
                tickerText = "عاجل | استوديو خالد صوت 2.1 مدمج بالكامل",
                tickerFontSizeSp = 12,
                tickerFontFamilyId = StudioFontFamily.CAIRO.id
            )
        )

        assertEquals("proj_round_trip", project.id)
        assertEquals(1, project.slides.size)
        val s = project.slides.first()
        assertEquals(VideoDisplayMode.FILL, s.videoDisplayMode)
        assertEquals(1.35f, s.videoZoom, 0.01f)
        assertEquals(5.0f, s.videoPanX, 0.01f)
        assertEquals(-10.0f, s.videoPanY, 0.01f)
        assertEquals(0.90f, s.videoVolume, 0.01f)
        assertEquals(StudioFontFamily.CAIRO.id, s.textStyle.fontFamilyId)
        assertEquals(28, s.textStyle.titleFontSizeSp)
        assertTrue(s.textStyle.isBold)

        // Test mutating video display mode & pan
        val updatedSlide = s.copy(
            videoDisplayMode = VideoDisplayMode.CUSTOM,
            videoZoom = 2.2f,
            videoPanX = 20f
        )
        assertEquals(VideoDisplayMode.CUSTOM, updatedSlide.videoDisplayMode)
        assertEquals(2.2f, updatedSlide.videoZoom, 0.01f)
        assertEquals(20f, updatedSlide.videoPanX, 0.01f)
    }

    @Test
    fun test6_aspectRatioCalculations() {
        assertEquals(16f / 9f, AspectRatio.RATIO_16_9.ratioFloat, 0.01f)
        assertEquals(9f / 16f, AspectRatio.RATIO_9_16.ratioFloat, 0.01f)
        assertEquals(1.0f, AspectRatio.RATIO_1_1.ratioFloat, 0.01f)
    }
}
